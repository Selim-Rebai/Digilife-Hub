package com.digilifehub.digilife_hub

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
