// lib/injection_container.dart

import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:local_auth/local_auth.dart';
import 'package:http/http.dart' as http;

// Auth imports
import 'package:digilife_hub/domain/repositories/auth_repository.dart';
import 'package:digilife_hub/data/repositories/firebase_auth_repository.dart';
import 'package:digilife_hub/domain/usecases/auth/auth_usecases.dart';
import 'package:digilife_hub/presentation/blocs/auth/auth_bloc.dart';

// Subscription imports
import 'package:digilife_hub/domain/repositories/subscription_repository.dart';
import 'package:digilife_hub/data/repositories/firestore_subscription_repository.dart';
import 'package:digilife_hub/domain/usecases/subscription/subscription_usecases.dart';
import 'package:digilife_hub/presentation/blocs/subscription/subscription_bloc.dart';

// Subscription Detection imports
import 'package:digilife_hub/features/subscription_detection/data/datasources/csv_datasource.dart';
import 'package:digilife_hub/features/subscription_detection/data/datasources/email_datasource.dart';
import 'package:digilife_hub/features/subscription_detection/data/datasources/subscription_template_datasource.dart';
import 'package:digilife_hub/features/subscription_detection/data/repositories/subscription_detection_repository_impl.dart';
import 'package:digilife_hub/features/subscription_detection/domain/repositories/subscription_detection_repository.dart';
import 'package:digilife_hub/features/subscription_detection/domain/usecases/detect_from_csv_usecase.dart';
import 'package:digilife_hub/features/subscription_detection/domain/usecases/detect_from_emails_usecase.dart';
import 'package:digilife_hub/features/subscription_detection/domain/usecases/get_subscription_templates_usecase.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/bloc/subscription_detection_bloc.dart';

final GetIt sl = GetIt.instance;

Future<void> init() async {
  print("DEBUG: Injection - Initialisation des dépendances");
  //! External
  final sharedPreferences = await SharedPreferences.getInstance();
  sl.registerLazySingleton(() => sharedPreferences);
  sl.registerLazySingleton(() => const FlutterSecureStorage());
  sl.registerLazySingleton(() => FirebaseAuth.instance);
  sl.registerLazySingleton(() => FirebaseFirestore.instance);
  sl.registerLazySingleton(() => GoogleSignIn());
  sl.registerLazySingleton(() => LocalAuthentication());
  sl.registerLazySingleton(() => http.Client());

  //! Core
  // Ajoutez ici les services core comme la connectivité, la localisation, etc.

  //! Features - Auth
  // Repository
  sl.registerLazySingleton<AuthRepository>(
        () {
      print("DEBUG: Injection - Création de AuthRepository");
      return FirebaseAuthRepository(
        firebaseAuth: sl(),
        googleSignIn: sl(),
        secureStorage: sl(),
        localAuth: sl(),
        prefs: sl(),
      );
    },
  );

  // UseCases
  sl.registerLazySingleton(() => SignInWithEmailPasswordUseCase(sl()));
  sl.registerLazySingleton(() => RegisterWithEmailPasswordUseCase(sl()));
  sl.registerLazySingleton(() => SignInWithGoogleUseCase(sl()));
  sl.registerLazySingleton(() => SignOutUseCase(sl()));
  sl.registerLazySingleton(() => ResetPasswordUseCase(sl()));
  sl.registerLazySingleton(() => EnableBiometricAuthUseCase(sl()));
  sl.registerLazySingleton(() => SignInWithBiometricUseCase(sl()));
  sl.registerLazySingleton(() => IsBiometricAvailableUseCase(sl()));

  // Blocs
  sl.registerFactory(() {
    print("DEBUG: Injection - Création de AuthBloc");
    return AuthBloc(authRepository: sl());
  });

  //! Features - Abonnements
  // Repository
  sl.registerLazySingleton<SubscriptionRepository>(
        () {
      print("DEBUG: Injection - Création de SubscriptionRepository");
      return FirestoreSubscriptionRepository(
        firestore: sl(),
        auth: sl(),
      );
    },
  );

  // UseCases
  sl.registerLazySingleton(() => GetAllSubscriptionsUseCase(sl()));
  sl.registerLazySingleton(() => AddSubscriptionUseCase(sl()));
  sl.registerLazySingleton(() => UpdateSubscriptionUseCase(sl()));
  sl.registerLazySingleton(() => DeleteSubscriptionUseCase(sl()));
  sl.registerLazySingleton(() => CalculateTotalMonthlyCostUseCase(sl()));
  sl.registerLazySingleton(() => CalculateTotalAnnualCostUseCase(sl()));

  // Blocs
  sl.registerFactory(
        () {
      print("DEBUG: Injection - Création de SubscriptionBloc");
      return SubscriptionBloc(
        getAllSubscriptionsUseCase: sl(),
        addSubscriptionUseCase: sl(),
        updateSubscriptionUseCase: sl(),
        deleteSubscriptionUseCase: sl(),
        calculateTotalMonthlyCostUseCase: sl(),
        calculateTotalAnnualCostUseCase: sl(),
      );
    },
  );

  //! Features - Détection d'abonnements
  // Data sources
  sl.registerLazySingleton<EmailDataSource>(
        () {
      print("DEBUG: Injection - Création de EmailDataSource");
      return GmailDataSource(client: sl());
    },
  );
  sl.registerLazySingleton<CsvDataSource>(
        () {
      print("DEBUG: Injection - Création de CsvDataSource");
      return CsvDataSourceImpl();
    },
  );
  sl.registerLazySingleton<SubscriptionTemplateDataSource>(
        () {
      print("DEBUG: Injection - Création de SubscriptionTemplateDataSource");
      return LocalSubscriptionTemplateDataSource();
    },
  );

  // Repository
  sl.registerLazySingleton<SubscriptionDetectionRepository>(
        () {
      print("DEBUG: Injection - Création de SubscriptionDetectionRepository");
      return SubscriptionDetectionRepositoryImpl(
        emailDataSource: sl(),
        csvDataSource: sl(),
        templateDataSource: sl(),
      );
    },
  );

  // Use cases
  sl.registerLazySingleton(() {
    print("DEBUG: Injection - Création de DetectFromEmailsUseCase");
    return DetectFromEmailsUseCase(sl());
  });
  sl.registerLazySingleton(() {
    print("DEBUG: Injection - Création de DetectFromCsvUseCase");
    return DetectFromCsvUseCase(sl());
  });
  sl.registerLazySingleton(() {
    print("DEBUG: Injection - Création de GetSubscriptionTemplatesUseCase");
    return GetSubscriptionTemplatesUseCase(sl());
  });

  // Bloc
  sl.registerFactory(
        () {
      print("DEBUG: Injection - Création de SubscriptionDetectionBloc");
      return SubscriptionDetectionBloc(
        detectFromEmailsUseCase: sl(),
        detectFromCsvUseCase: sl(),
        getSubscriptionTemplatesUseCase: sl(),
        addSubscriptionUseCase: sl(),
      );
    },
  );

  print("DEBUG: Injection - Toutes les dépendances ont été initialisées");
}