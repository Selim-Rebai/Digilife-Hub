import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:dartz/dartz.dart';

import 'package:digilife_hub/core/errors/auth_failures.dart';
import 'package:digilife_hub/domain/entities/user.dart';
import 'package:digilife_hub/domain/repositories/auth_repository.dart';
import 'package:digilife_hub/domain/usecases/auth/auth_usecases.dart';
import 'package:digilife_hub/presentation/blocs/auth/auth_event.dart';
import 'package:digilife_hub/presentation/blocs/auth/auth_state.dart';

import '../../../core/errors/failures.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository authRepository;
  late StreamSubscription<User?> _authStateSubscription;

  AuthBloc({required this.authRepository}) : super(AuthInitialState()) {
    on<AuthCheckStatusEvent>(_onAuthCheckStatus);
    on<AuthLoginEvent>(_onAuthLogin);
    on<AuthRegisterEvent>(_onAuthRegister);
    on<AuthGoogleLoginEvent>(_onAuthGoogleLogin);
    on<AuthAppleLoginEvent>(_onAuthAppleLogin);
    on<AuthLogoutEvent>(_onAuthLogout);
    on<AuthResetPasswordEvent>(_onAuthResetPassword);
    on<AuthCheckBiometricAvailabilityEvent>(_onAuthCheckBiometricAvailability);
    on<AuthEnableBiometricEvent>(_onAuthEnableBiometric);
    on<AuthBiometricLoginEvent>(_onAuthBiometricLogin);

    // S'abonner aux changements d'état d'authentification
    _authStateSubscription = authRepository.user.listen((user) {
      if (user != null) {
        add(AuthCheckStatusEvent());
      } else {
        add(AuthCheckStatusEvent());
      }
    });
  }

  // Gérer la vérification de l'état d'authentification
  Future<void> _onAuthCheckStatus(
      AuthCheckStatusEvent event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoadingState());

    final isSignedIn = await authRepository.isSignedIn();

    if (isSignedIn) {
      final user = await authRepository.user.first;
      if (user != null) {
        emit(AuthenticatedState(user: user));
      } else {
        emit(UnauthenticatedState());
      }
    } else {
      emit(UnauthenticatedState());
    }
  }

  // Gérer la connexion avec email et mot de passe
  Future<void> _onAuthLogin(
      AuthLoginEvent event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoadingState());

    final signInUseCase = SignInWithEmailPasswordUseCase(authRepository);
    final result = await signInUseCase(
      SignInParams(email: event.email, password: event.password),
    );

    _emitResultState(emit, result);
  }

  // Gérer l'inscription
  Future<void> _onAuthRegister(
      AuthRegisterEvent event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoadingState());

    final registerUseCase = RegisterWithEmailPasswordUseCase(authRepository);
    final result = await registerUseCase(
      RegisterParams(
        email: event.email,
        password: event.password,
        displayName: event.displayName,
      ),
    );

    _emitResultState(emit, result);
  }

  // Gérer la connexion Google
  Future<void> _onAuthGoogleLogin(
      AuthGoogleLoginEvent event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoadingState());

    final googleSignInUseCase = SignInWithGoogleUseCase(authRepository);
    final result = await googleSignInUseCase();

    _emitResultState(emit, result);
  }

  // Gérer la connexion Apple
  Future<void> _onAuthAppleLogin(
      AuthAppleLoginEvent event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoadingState());

    final result = await authRepository.signInWithApple();
    _emitResultState(emit, result);
  }

  // Gérer la déconnexion
  Future<void> _onAuthLogout(
      AuthLogoutEvent event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoadingState());

    final signOutUseCase = SignOutUseCase(authRepository);
    final result = await signOutUseCase();

    result.fold(
          (failure) => emit(AuthErrorState(failure: failure)),
          (_) => emit(UnauthenticatedState()),
    );
  }

  // Gérer la réinitialisation du mot de passe
  Future<void> _onAuthResetPassword(
      AuthResetPasswordEvent event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoadingState());

    final resetPasswordUseCase = ResetPasswordUseCase(authRepository);
    final result = await resetPasswordUseCase(
      ResetPasswordParams(email: event.email),
    );

    result.fold(
          (failure) => emit(AuthErrorState(failure: failure)),
          (_) => emit(AuthPasswordResetSentState(email: event.email)),
    );
  }

  // Vérifier la disponibilité de la biométrie
  Future<void> _onAuthCheckBiometricAvailability(
      AuthCheckBiometricAvailabilityEvent event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoadingState());

    final biometricAvailableUseCase = IsBiometricAvailableUseCase(authRepository);
    final isAvailable = await biometricAvailableUseCase();

    emit(AuthBiometricState(
      isAvailable: isAvailable,
      isEnabled: false, // Par défaut, on suppose que ce n'est pas activé
    ));
  }

  // Activer l'authentification biométrique
  Future<void> _onAuthEnableBiometric(
      AuthEnableBiometricEvent event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoadingState());

    final enableBiometricUseCase = EnableBiometricAuthUseCase(authRepository);
    final result = await enableBiometricUseCase();

    result.fold(
          (failure) => emit(AuthErrorState(failure: failure)),
          (isEnabled) => emit(AuthBiometricEnabledState()),
    );
  }

  // Connexion avec biométrie
  Future<void> _onAuthBiometricLogin(
      AuthBiometricLoginEvent event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoadingState());

    final biometricLoginUseCase = SignInWithBiometricUseCase(authRepository);
    final result = await biometricLoginUseCase();

    _emitResultState(emit, result);
  }

  // Méthode utilitaire pour émettre l'état en fonction du résultat
  void _emitResultState(
      Emitter<AuthState> emit,
      Either<Failure, dynamic> result,
      ) {
    result.fold(
          (failure) => emit(AuthErrorState(failure: failure)),
          (data) {
        if (data is User) {
          emit(AuthenticatedState(user: data));
        } else {
          // Cas particulier pour les autres résultats
          emit(UnauthenticatedState());
        }
      },
    );
  }

  @override
  Future<void> close() {
    _authStateSubscription.cancel();
    return super.close();
  }
}