import 'package:equatable/equatable.dart';

abstract class AuthEvent extends Equatable {
  const AuthEvent();

  @override
  List<Object?> get props => [];
}

// Vérification de l'état d'authentification actuel
class AuthCheckStatusEvent extends AuthEvent {}

// Événement de connexion avec email et mot de passe
class AuthLoginEvent extends AuthEvent {
  final String email;
  final String password;

  const AuthLoginEvent({required this.email, required this.password});

  @override
  List<Object> get props => [email, password];
}

// Événement d'inscription
class AuthRegisterEvent extends AuthEvent {
  final String email;
  final String password;
  final String? displayName;

  const AuthRegisterEvent({
    required this.email,
    required this.password,
    this.displayName,
  });

  @override
  List<Object?> get props => [email, password, displayName];
}

// Événement de connexion Google
class AuthGoogleLoginEvent extends AuthEvent {}

// Événement de connexion Apple
class AuthAppleLoginEvent extends AuthEvent {}

// Événement de déconnexion
class AuthLogoutEvent extends AuthEvent {}

// Événement de réinitialisation de mot de passe
class AuthResetPasswordEvent extends AuthEvent {
  final String email;

  const AuthResetPasswordEvent({required this.email});

  @override
  List<Object> get props => [email];
}

// Événement pour vérifier la disponibilité de la biométrie
class AuthCheckBiometricAvailabilityEvent extends AuthEvent {}

// Événement pour activer l'authentification biométrique
class AuthEnableBiometricEvent extends AuthEvent {}

// Événement pour la connexion biométrique
class AuthBiometricLoginEvent extends AuthEvent {}