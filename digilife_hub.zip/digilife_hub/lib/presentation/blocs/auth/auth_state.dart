import 'package:equatable/equatable.dart';
import 'package:digilife_hub/domain/entities/user.dart';
import 'package:digilife_hub/core/errors/auth_failures.dart';

import '../../../core/errors/failures.dart';

abstract class AuthState extends Equatable {
  const AuthState();

  @override
  List<Object?> get props => [];
}

// État initial
class AuthInitialState extends AuthState {}

// État en cours de chargement
class AuthLoadingState extends AuthState {}

// État authentifié
class AuthenticatedState extends AuthState {
  final User user;

  const AuthenticatedState({required this.user});

  @override
  List<Object> get props => [user];
}

// État non authentifié
class UnauthenticatedState extends AuthState {}

// État d'erreur
class AuthErrorState extends AuthState {
  final Failure failure;

  const AuthErrorState({required this.failure});

  @override
  List<Object> get props => [failure];
}

// État de succès de réinitialisation de mot de passe
class AuthPasswordResetSentState extends AuthState {
  final String email;

  const AuthPasswordResetSentState({required this.email});

  @override
  List<Object> get props => [email];
}

// État de biométrie
class AuthBiometricState extends AuthState {
  final bool isAvailable;
  final bool isEnabled;

  const AuthBiometricState({
    required this.isAvailable,
    required this.isEnabled,
  });

  @override
  List<Object> get props => [isAvailable, isEnabled];
}

// État de succès d'activation de la biométrie
class AuthBiometricEnabledState extends AuthState {}