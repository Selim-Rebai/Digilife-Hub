// lib/presentation/blocs/subscription/subscription_state.dart

import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';

abstract class SubscriptionState extends Equatable {
  const SubscriptionState();

  @override
  List<Object?> get props => [];
}

// État initial
class SubscriptionInitialState extends SubscriptionState {}

// État de chargement
class SubscriptionLoadingState extends SubscriptionState {}

// État lorsque les abonnements sont chargés avec succès
class SubscriptionsLoadedState extends SubscriptionState {
  final List<Subscription> subscriptions;
  final double totalMonthlyCost;
  final double totalAnnualCost;
  final SubscriptionCategory? activeFilter;
  final String? searchQuery;

  const SubscriptionsLoadedState({
    required this.subscriptions,
    required this.totalMonthlyCost,
    required this.totalAnnualCost,
    this.activeFilter,
    this.searchQuery,
  });

  @override
  List<Object?> get props => [
    subscriptions,
    totalMonthlyCost,
    totalAnnualCost,
    activeFilter,
    searchQuery,
  ];

  // Crée une copie avec des valeurs optionnellement modifiées
  SubscriptionsLoadedState copyWith({
    List<Subscription>? subscriptions,
    double? totalMonthlyCost,
    double? totalAnnualCost,
    SubscriptionCategory? activeFilter,
    String? searchQuery,
    bool clearFilter = false,
    bool clearSearch = false,
  }) {
    return SubscriptionsLoadedState(
      subscriptions: subscriptions ?? this.subscriptions,
      totalMonthlyCost: totalMonthlyCost ?? this.totalMonthlyCost,
      totalAnnualCost: totalAnnualCost ?? this.totalAnnualCost,
      activeFilter: clearFilter ? null : activeFilter ?? this.activeFilter,
      searchQuery: clearSearch ? null : searchQuery ?? this.searchQuery,
    );
  }
}

// État lorsqu'une action sur un abonnement a réussi
class SubscriptionActionSuccessState extends SubscriptionState {
  final String message;

  const SubscriptionActionSuccessState({required this.message});

  @override
  List<Object> get props => [message];
}

// État d'erreur
class SubscriptionErrorState extends SubscriptionState {
  final Failure failure;

  const SubscriptionErrorState({required this.failure});

  @override
  List<Object> get props => [failure];

  String? get message => null;
}