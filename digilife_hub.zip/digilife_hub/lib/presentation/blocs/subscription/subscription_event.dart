// lib/presentation/blocs/subscription/subscription_event.dart

import 'package:equatable/equatable.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';

abstract class SubscriptionEvent extends Equatable {
  const SubscriptionEvent();

  @override
  List<Object?> get props => [];
}

// Événement pour charger tous les abonnements
class LoadSubscriptionsEvent extends SubscriptionEvent {}

// Événement pour ajouter un nouvel abonnement
class AddSubscriptionEvent extends SubscriptionEvent {
  final Subscription subscription;

  const AddSubscriptionEvent({required this.subscription});

  @override
  List<Object> get props => [subscription];
}

// Événement pour mettre à jour un abonnement existant
class UpdateSubscriptionEvent extends SubscriptionEvent {
  final Subscription subscription;

  const UpdateSubscriptionEvent({required this.subscription});

  @override
  List<Object> get props => [subscription];
}

// Événement pour supprimer un abonnement
class DeleteSubscriptionEvent extends SubscriptionEvent {
  final String id;

  const DeleteSubscriptionEvent({required this.id});

  @override
  List<Object> get props => [id];
}

// Événement pour filtrer les abonnements par catégorie
class FilterSubscriptionsByCategoryEvent extends SubscriptionEvent {
  final SubscriptionCategory? category;

  const FilterSubscriptionsByCategoryEvent({this.category});

  @override
  List<Object?> get props => [category];
}

// Événement pour rechercher des abonnements
class SearchSubscriptionsEvent extends SubscriptionEvent {
  final String query;

  const SearchSubscriptionsEvent({required this.query});

  @override
  List<Object> get props => [query];
}

// Événement pour rafraîchir les données
class RefreshSubscriptionsEvent extends SubscriptionEvent {}