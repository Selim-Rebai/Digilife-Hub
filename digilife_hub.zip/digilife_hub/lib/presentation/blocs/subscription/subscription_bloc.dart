// lib/presentation/blocs/subscription/subscription_bloc.dart

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:digilife_hub/domain/usecases/subscription/subscription_usecases.dart';
import 'package:digilife_hub/presentation/blocs/subscription/subscription_event.dart';
import 'package:digilife_hub/presentation/blocs/subscription/subscription_state.dart';

class SubscriptionBloc extends Bloc<SubscriptionEvent, SubscriptionState> {
  final GetAllSubscriptionsUseCase getAllSubscriptionsUseCase;
  final AddSubscriptionUseCase addSubscriptionUseCase;
  final UpdateSubscriptionUseCase updateSubscriptionUseCase;
  final DeleteSubscriptionUseCase deleteSubscriptionUseCase;
  final CalculateTotalMonthlyCostUseCase calculateTotalMonthlyCostUseCase;
  final CalculateTotalAnnualCostUseCase calculateTotalAnnualCostUseCase;

  SubscriptionBloc({
    required this.getAllSubscriptionsUseCase,
    required this.addSubscriptionUseCase,
    required this.updateSubscriptionUseCase,
    required this.deleteSubscriptionUseCase,
    required this.calculateTotalMonthlyCostUseCase,
    required this.calculateTotalAnnualCostUseCase,
  }) : super(SubscriptionInitialState()) {
    on<LoadSubscriptionsEvent>(_onLoadSubscriptions);
    on<AddSubscriptionEvent>(_onAddSubscription);
    on<UpdateSubscriptionEvent>(_onUpdateSubscription);
    on<DeleteSubscriptionEvent>(_onDeleteSubscription);
    on<FilterSubscriptionsByCategoryEvent>(_onFilterSubscriptionsByCategory);
    on<SearchSubscriptionsEvent>(_onSearchSubscriptions);
    on<RefreshSubscriptionsEvent>(_onRefreshSubscriptions);
  }

  Future<void> _onLoadSubscriptions(
      LoadSubscriptionsEvent event,
      Emitter<SubscriptionState> emit,
      ) async {
    emit(SubscriptionLoadingState());

    final subscriptionsResult = await getAllSubscriptionsUseCase();
    final monthlyCostResult = await calculateTotalMonthlyCostUseCase();
    final annualCostResult = await calculateTotalAnnualCostUseCase();

    // Fusion des résultats
    subscriptionsResult.fold(
          (failure) => emit(SubscriptionErrorState(failure: failure)),
          (subscriptions) {
        monthlyCostResult.fold(
              (failure) => emit(SubscriptionErrorState(failure: failure)),
              (monthlyCost) {
            annualCostResult.fold(
                  (failure) => emit(SubscriptionErrorState(failure: failure)),
                  (annualCost) {
                emit(SubscriptionsLoadedState(
                  subscriptions: subscriptions,
                  totalMonthlyCost: monthlyCost,
                  totalAnnualCost: annualCost,
                ));
              },
            );
          },
        );
      },
    );
  }

  Future<void> _onAddSubscription(
      AddSubscriptionEvent event,
      Emitter<SubscriptionState> emit,
      ) async {
    emit(SubscriptionLoadingState());

    final result = await addSubscriptionUseCase(
      AddSubscriptionParams(subscription: event.subscription),
    );

    result.fold(
          (failure) => emit(SubscriptionErrorState(failure: failure)),
          (subscription) {
        // Émettre uniquement l'état de succès sans charger immédiatement les abonnements
        emit(const SubscriptionActionSuccessState(
          message: 'Abonnement ajouté avec succès',
        ));
        // La page appelante sera responsable de charger les abonnements après navigation
      },
    );
  }

  Future<void> _onUpdateSubscription(
      UpdateSubscriptionEvent event,
      Emitter<SubscriptionState> emit,
      ) async {
    emit(SubscriptionLoadingState());

    final result = await updateSubscriptionUseCase(
      UpdateSubscriptionParams(subscription: event.subscription),
    );

    result.fold(
          (failure) => emit(SubscriptionErrorState(failure: failure)),
          (subscription) {
        emit(const SubscriptionActionSuccessState(
          message: 'Abonnement mis à jour avec succès',
        ));
        // La page appelante sera responsable de charger les abonnements après navigation
      },
    );
  }

  Future<void> _onDeleteSubscription(
      DeleteSubscriptionEvent event,
      Emitter<SubscriptionState> emit,
      ) async {
    emit(SubscriptionLoadingState());

    final result = await deleteSubscriptionUseCase(
      DeleteSubscriptionParams(id: event.id),
    );

    result.fold(
          (failure) => emit(SubscriptionErrorState(failure: failure)),
          (_) {
        emit(const SubscriptionActionSuccessState(
          message: 'Abonnement supprimé avec succès',
        ));
        add(LoadSubscriptionsEvent());
      },
    );
  }

  Future<void> _onFilterSubscriptionsByCategory(
      FilterSubscriptionsByCategoryEvent event,
      Emitter<SubscriptionState> emit,
      ) async {
    final currentState = state;
    if (currentState is SubscriptionsLoadedState) {
      // Si le filtre est le même que celui déjà actif, le supprimer
      if (currentState.activeFilter == event.category) {
        add(LoadSubscriptionsEvent());
      } else {
        // Sinon, appliquer le nouveau filtre
        final allSubscriptions = await getAllSubscriptionsUseCase();

        allSubscriptions.fold(
              (failure) => emit(SubscriptionErrorState(failure: failure)),
              (subscriptions) {
            final filteredSubscriptions = event.category != null
                ? subscriptions
                .where((sub) => sub.category == event.category)
                .toList()
                : subscriptions;

            emit(currentState.copyWith(
              subscriptions: filteredSubscriptions,
              activeFilter: event.category,
            ));
          },
        );
      }
    } else {
      // Si nous ne sommes pas dans un état chargé, charger les abonnements d'abord
      add(LoadSubscriptionsEvent());
    }
  }

  Future<void> _onSearchSubscriptions(
      SearchSubscriptionsEvent event,
      Emitter<SubscriptionState> emit,
      ) async {
    final currentState = state;
    if (currentState is SubscriptionsLoadedState) {
      // Si la recherche est vide, charger tous les abonnements
      if (event.query.isEmpty) {
        add(LoadSubscriptionsEvent());
      } else {
        // Sinon, effectuer la recherche
        final allSubscriptions = await getAllSubscriptionsUseCase();

        allSubscriptions.fold(
              (failure) => emit(SubscriptionErrorState(failure: failure)),
              (subscriptions) {
            final searchResults = subscriptions
                .where((sub) =>
            sub.name.toLowerCase().contains(event.query.toLowerCase()) ||
                (sub.description?.toLowerCase().contains(event.query.toLowerCase()) ?? false))
                .toList();

            emit(currentState.copyWith(
              subscriptions: searchResults,
              searchQuery: event.query,
            ));
          },
        );
      }
    } else {
      // Si nous ne sommes pas dans un état chargé, charger les abonnements d'abord
      add(LoadSubscriptionsEvent());
    }
  }

  Future<void> _onRefreshSubscriptions(
      RefreshSubscriptionsEvent event,
      Emitter<SubscriptionState> emit,
      ) async {
    add(LoadSubscriptionsEvent());
  }
}