// lib/presentation/app.dart

import 'package:digilife_hub/presentation/pages/subscription/subscription_detail_page.dart';
import 'package:digilife_hub/presentation/pages/subscription/subscription_form_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:digilife_hub/core/constants/app_theme.dart';
import 'package:digilife_hub/core/constants/routes.dart';
import 'package:digilife_hub/presentation/blocs/auth/auth_bloc.dart';
import 'package:digilife_hub/presentation/blocs/auth/auth_event.dart';
import 'package:digilife_hub/presentation/blocs/auth/auth_state.dart';
import 'package:digilife_hub/presentation/blocs/subscription/subscription_bloc_exports.dart';
import 'package:digilife_hub/presentation/navigation/main_navigation.dart';
import 'package:digilife_hub/presentation/pages/auth/login_page.dart';
import 'package:digilife_hub/presentation/pages/auth/register_page.dart';
import 'package:digilife_hub/presentation/pages/auth/forgot_password_page.dart';
import 'package:digilife_hub/presentation/pages/home/home_page.dart';
import 'package:digilife_hub/presentation/pages/subscription/subscription_dashboard_page.dart';
import 'package:digilife_hub/presentation/pages/calendar/calendar_page.dart';
import 'package:digilife_hub/presentation/pages/profile/profile_page.dart';
import 'package:digilife_hub/presentation/pages/splash/splash_page.dart';
import 'package:digilife_hub/injection_container.dart' as di;
import 'package:digilife_hub/features/subscription_detection/presentation/pages/subscription_detection_page.dart';

import '../domain/entities/subscription.dart';
import '../features/subscription_detection/presentation/bloc/subscription_detection_bloc.dart';

class DigiLifeHubApp extends StatelessWidget {
  const DigiLifeHubApp({super.key});

  @override
  Widget build(BuildContext context) {
    print("DEBUG: DigiLifeHubApp - build");

    // Initialiser Intl pour le français
    Intl.defaultLocale = 'fr_FR';

    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(
          create: (context) {
            print("DEBUG: DigiLifeHubApp - Création de AuthBloc");
            return di.sl<AuthBloc>()..add(AuthCheckStatusEvent());
          },
        ),
        BlocProvider<SubscriptionBloc>(
          create: (context) {
            print("DEBUG: DigiLifeHubApp - Création de SubscriptionBloc");
            return di.sl<SubscriptionBloc>();
          },
        ),
      ],
      child: MaterialApp(
        title: 'DigiLife Hub',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: const [
          Locale('fr', 'FR'),
          Locale('fr'),
        ],
        // Utilisation de home pour le routage conditionnel
        home: BlocBuilder<AuthBloc, AuthState>(
          builder: (context, state) {
            print("DEBUG: DigiLifeHubApp - AuthBloc état: ${state.runtimeType}");

            if (state is AuthInitialState) {
              return const SplashPage();
            } else if (state is AuthenticatedState) {
              return const MainNavigation(); // Navigation principale avec barre en bas
            } else {
              return const LoginPage(); // Page de connexion sans barre en bas
            }
          },
        ),
        // Définir toutes les routes
        routes: {
          // Routes d'authentification
          Routes.login: (context) => const LoginPage(),
          Routes.register: (context) => const RegisterPage(),
          Routes.forgotPassword: (context) => const ForgotPasswordPage(),

          // Routes principales
          Routes.home: (context) => const MainNavigation(),
          Routes.dashboard: (context) => const SubscriptionDashboardPage(),
          Routes.subscriptions: (context) => const SubscriptionDashboardPage(),
          Routes.addSubscription: (context) => const SubscriptionFormPage(),

          // Détection d'abonnements
          Routes.detectSubscriptions: (context) {
            print("DEBUG: DigiLifeHubApp - Navigation vers SubscriptionDetectionPage via routes");
            return BlocProvider(
              create: (context) {
                print("DEBUG: DigiLifeHubApp - Création de SubscriptionDetectionBloc pour la route");
                return di.sl<SubscriptionDetectionBloc>();
              },
              child: const SubscriptionDetectionPage(),
            );
          },

          // Autres pages de l'application
          Routes.profile: (context) => const ProfilePage(),
        },
        // Gestionnaire pour les routes qui nécessitent des arguments
        onGenerateRoute: (settings) {
          print("DEBUG: DigiLifeHubApp - onGenerateRoute appelé pour ${settings.name}");

          if (settings.name == Routes.subscriptionDetail) {
            // Conversion explicite de l'argument Object? vers Subscription
            final subscription = settings.arguments as Subscription;
            print("DEBUG: DigiLifeHubApp - Navigation vers SubscriptionDetailPage avec ID: ${subscription.id}");
            return MaterialPageRoute(
              builder: (context) => SubscriptionDetailPage(subscription: subscription),
            );
          }
          if (settings.name == Routes.updateSubscription) {
            // Conversion explicite de l'argument Object? vers Subscription
            final subscription = settings.arguments as Subscription;
            print("DEBUG: DigiLifeHubApp - Navigation vers SubscriptionFormPage (édition) avec ID: ${subscription.id}");
            return MaterialPageRoute(
              builder: (context) => SubscriptionFormPage(
                subscription: subscription,
                isEditing: true,
              ),
            );
          }
          if (settings.name == Routes.detectSubscriptions) {
            print("DEBUG: DigiLifeHubApp - Navigation vers SubscriptionDetectionPage via onGenerateRoute");
            return MaterialPageRoute(
              builder: (context) => BlocProvider(
                create: (context) {
                  print("DEBUG: DigiLifeHubApp - Création de SubscriptionDetectionBloc dans onGenerateRoute");
                  return di.sl<SubscriptionDetectionBloc>();
                },
                child: const SubscriptionDetectionPage(),
              ),
            );
          }

          // Gérer les autres routes dynamiques ici si nécessaire
          print("DEBUG: DigiLifeHubApp - Route non gérée par onGenerateRoute: ${settings.name}");
          return null;
        },
        // Gestionnaire pour les routes inconnues (facultatif mais utile)
        onUnknownRoute: (settings) {
          print("DEBUG: DigiLifeHubApp - onUnknownRoute appelé pour ${settings.name}");
          // Rediriger vers une page par défaut en cas de route inconnue
          return MaterialPageRoute(
            builder: (context) => const MainNavigation(),
          );
        },
      ),
    );
  }
}