// lib/presentation/pages/calendar/calendar_page.dart

import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/presentation/blocs/subscription/subscription_bloc_exports.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CalendarPage extends StatefulWidget {
  const CalendarPage({super.key});

  @override
  State<CalendarPage> createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  // Map pour stocker les événements par jour
  Map<DateTime, List<dynamic>> _events = {};

  @override
  void initState() {
    super.initState();
    _selectedDay = _focusedDay;
    // Charger les abonnements
    context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
  }

  // Fonction pour obtenir les événements d'un jour spécifique
  List<dynamic> _getEventsForDay(DateTime day) {
    return _events[DateTime(day.year, day.month, day.day)] ?? [];
  }

  // Charger les événements depuis les abonnements
  void _loadEvents(List<Subscription> subscriptions) {
    Map<DateTime, List<dynamic>> events = {};

    for (var subscription in subscriptions) {
      // Vérifier les paiements à venir
      final nextPayment = subscription.nextPaymentDate;
      final normalizedDate = DateTime(nextPayment.year, nextPayment.month, nextPayment.day);

      if (events[normalizedDate] == null) {
        events[normalizedDate] = [];
      }

      events[normalizedDate]!.add({
        'type': 'payment',
        'subscription': subscription,
        'time': '10:00', // Heure fictive pour l'exemple
      });
    }

    // Ajouter des événements supplémentaires pour l'exemple
    final tomorrow = DateTime.now().add(const Duration(days: 1));
    final normalizedTomorrow = DateTime(tomorrow.year, tomorrow.month, tomorrow.day);

    if (events[normalizedTomorrow] == null) {
      events[normalizedTomorrow] = [];
    }

    setState(() {
      _events = events;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'DigiLife Hub',
              style: TextStyle(
                color: Color(0xFF4527A0),
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            Text(
              'Gérez vos abonnements facilement',
              style: TextStyle(
                color: Color(0xFF9E9E9E),
                fontSize: 12,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined, color: Color(0xFF7B1FA2)),
            onPressed: () {
              // Action de notification
            },
          ),
          CircleAvatar(
            radius: 16,
            backgroundColor: Colors.blue,
            child: Icon(
              Icons.person,
              color: Colors.white,
              size: 20,
            ),
          ),
          SizedBox(width: 16),
        ],
      ),
      body: BlocConsumer<SubscriptionBloc, SubscriptionState>(
        listener: (context, state) {
          if (state is SubscriptionsLoadedState) {
            _loadEvents(state.subscriptions);
          }
        },
        builder: (context, state) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // En-tête Calendrier avec options de vue
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Calendrier',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    // Options de vue (Mois, Semaine, Jour)
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        children: [
                          _buildViewOption('Mois', _calendarFormat == CalendarFormat.month),
                          _buildViewOption('Semaine', _calendarFormat == CalendarFormat.week),
                          _buildViewOption('Jour', _calendarFormat == CalendarFormat.twoWeeks),
                          IconButton(
                            icon: Icon(Icons.more_horiz, size: 18),
                            onPressed: () {
                              // Options supplémentaires
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Titre du mois et navigation
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      DateFormat('MMMM yyyy', 'fr_FR').format(_focusedDay),
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF4527A0),
                      ),
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.chevron_left),
                          onPressed: () {
                            setState(() {
                              _focusedDay = DateTime(_focusedDay.year, _focusedDay.month - 1, 1);
                            });
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.chevron_right),
                          onPressed: () {
                            setState(() {
                              _focusedDay = DateTime(_focusedDay.year, _focusedDay.month + 1, 1);
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 8),

                // Calendrier
                TableCalendar(
                  firstDay: DateTime.utc(2020, 1, 1),
                  lastDay: DateTime.utc(2030, 12, 31),
                  focusedDay: _focusedDay,
                  calendarFormat: _calendarFormat,
                  selectedDayPredicate: (day) {
                    return isSameDay(_selectedDay, day);
                  },
                  onDaySelected: (selectedDay, focusedDay) {
                    setState(() {
                      _selectedDay = selectedDay;
                      _focusedDay = focusedDay;
                    });
                  },
                  onFormatChanged: (format) {
                    setState(() {
                      _calendarFormat = format;
                    });
                  },
                  onPageChanged: (focusedDay) {
                    _focusedDay = focusedDay;
                  },
                  eventLoader: _getEventsForDay,
                  calendarStyle: CalendarStyle(
                    markersMaxCount: 3,
                    markerDecoration: BoxDecoration(
                      color: Color(0xFF4527A0),
                      shape: BoxShape.circle,
                    ),
                    todayDecoration: BoxDecoration(
                      color: Color(0xFFE1E1FC),
                      shape: BoxShape.circle,
                    ),
                    todayTextStyle: TextStyle(
                      color: Color(0xFF4527A0),
                      fontWeight: FontWeight.bold,
                    ),
                    selectedDecoration: BoxDecoration(
                      color: Color(0xFF4527A0),
                      shape: BoxShape.circle,
                    ),
                  ),
                  headerVisible: false, // Nous avons notre propre en-tête
                  daysOfWeekStyle: DaysOfWeekStyle(
                    weekdayStyle: TextStyle(color: Colors.black87),
                    weekendStyle: TextStyle(color: Colors.red[400]),
                  ),
                ),
                const SizedBox(height: 16),

                // Liste des événements pour le jour sélectionné
                if (_selectedDay != null)
                  _buildEventsList(_getEventsForDay(_selectedDay!)),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color(0xFF4527A0),
        child: const Icon(Icons.add),
        onPressed: () {
          // Ajouter un nouvel événement
        },
      ),
    );
  }

  Widget _buildViewOption(String title, bool isSelected) {
    return GestureDetector(
      onTap: () {
        setState(() {
          if (title == 'Mois') {
            _calendarFormat = CalendarFormat.month;
          } else if (title == 'Semaine') {
            _calendarFormat = CalendarFormat.week;
          } else if (title == 'Jour') {
            _calendarFormat = CalendarFormat.twoWeeks; // Utilisons twoWeeks pour simuler la vue journalière
          }
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? Color(0xFF4527A0) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          title,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.black87,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildEventsList(List<dynamic> events) {
    if (events.isEmpty) {
      return const Center(
        child: Text(
          'Aucun événement pour ce jour',
          style: TextStyle(color: Colors.grey),
        ),
      );
    }

    // Formater la date pour l'affichage
    String dateText;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final tomorrow = DateTime(now.year, now.month, now.day + 1);

    if (_selectedDay != null) {
      if (isSameDay(_selectedDay!, today)) {
        dateText = 'Aujourd\'hui - ${DateFormat('d MMMM', 'fr_FR').format(_selectedDay!)}';
      } else if (isSameDay(_selectedDay!, tomorrow)) {
        dateText = 'Demain - ${DateFormat('d MMMM', 'fr_FR').format(_selectedDay!)}';
      } else {
        dateText = DateFormat('EEEE d MMMM', 'fr_FR').format(_selectedDay!);
      }
    } else {
      dateText = '';
    }

    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                dateText,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF4527A0),
                ),
              ),
              Text(
                '${events.length} événement${events.length > 1 ? 's' : ''}',
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF4527A0),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView.builder(
              itemCount: events.length,
              itemBuilder: (context, index) {
                final event = events[index];

                if (event['type'] == 'payment') {
                  final subscription = event['subscription'] as Subscription;
                  return _buildPaymentEventCard(
                    title: subscription.name,
                    amount: subscription.amount,
                    time: event['time'],
                  );
                } else if (event['type'] == 'lesson') {
                  return _buildLessonEventCard(
                    title: event['title'],
                    subtitle: event['subtitle'],
                    time: event['time'],
                  );
                }

                // Par défaut, un événement générique
                return _buildGenericEventCard(
                  title: 'Événement',
                  subtitle: 'Détails de l\'événement',
                  time: '12:00',
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentEventCard({
    required String title,
    required double amount,
    required String time,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Colors.green[100],
          child: Icon(Icons.attach_money, color: Colors.green),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text('Paiement - ${amount.toStringAsFixed(2)} €'),
        trailing: Text(
          time,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _buildLessonEventCard({
    required String title,
    required String subtitle,
    required String time,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Colors.amber[100],
          child: Icon(Icons.music_note, color: Colors.amber),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(subtitle),
        trailing: Text(
          time,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _buildGenericEventCard({
    required String title,
    required String subtitle,
    required String time,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Colors.blue[100],
          child: Icon(Icons.event, color: Colors.blue),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(subtitle),
        trailing: Text(
          time,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}