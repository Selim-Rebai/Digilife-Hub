// lib/presentation/pages/home/home_page.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:digilife_hub/core/constants/routes.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:digilife_hub/presentation/blocs/auth/auth_bloc.dart';
import 'package:digilife_hub/presentation/blocs/auth/auth_event.dart';
import 'package:digilife_hub/presentation/blocs/subscription/subscription_bloc_exports.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    // Charger les abonnements au démarrage
    context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
    print("DEBUG: HomePage initState - LoadSubscriptionsEvent ajouté");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'DigiLife Hub',
              style: TextStyle(
                color: Color(0xFF4527A0), // Couleur violette foncée
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            Text(
              'Gérez vos abonnements facilement',
              style: TextStyle(
                color: Color(0xFF9E9E9E), // Gris
                fontSize: 12,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined, color: Color(0xFF7B1FA2)),
            onPressed: () {
              print("DEBUG: Icône de notification pressée");
              // Action de notification
            },
          ),
          const CircleAvatar(
            radius: 16,
            backgroundColor: Colors.blue,
            child: Icon(
              Icons.person,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 16), // Espacement à droite
        ],
      ),
      body: BlocBuilder<SubscriptionBloc, SubscriptionState>(
        builder: (context, state) {
          print("DEBUG: HomePage BlocBuilder - état actuel: ${state.runtimeType}");

          if (state is SubscriptionLoadingState) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          } else if (state is SubscriptionsLoadedState) {
            return _buildHomeContent(context, state);
          } else if (state is SubscriptionErrorState) {
            print("DEBUG: HomePage - État d'erreur: ${state.failure.message}");
            // Gestion des erreurs
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.error_outline,
                    color: Colors.red,
                    size: 60,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Une erreur est survenue',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    state.message ?? state.failure.message,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton.icon(
                    onPressed: () {
                      print("DEBUG: HomePage - Tentative de rechargement après erreur");
                      context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
                    },
                    icon: const Icon(Icons.refresh),
                    label: const Text('Réessayer'),
                  ),
                ],
              ),
            );
          } else {
            print("DEBUG: HomePage - État initial ou non géré");
            return Center(
              child: ElevatedButton(
                onPressed: () {
                  print("DEBUG: HomePage - Chargement initial des abonnements");
                  context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
                },
                child: const Text('Charger les abonnements'),
              ),
            );
          }
        },
      ),
    );
  }

  Widget _buildHomeContent(BuildContext context, SubscriptionsLoadedState state) {
    print("DEBUG: Construction du contenu HomePage avec ${state.subscriptions.length} abonnements");

    return RefreshIndicator(
      onRefresh: () async {
        print("DEBUG: HomePage - Pull-to-refresh activé");
        context.read<SubscriptionBloc>().add(RefreshSubscriptionsEvent());
      },
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSummaryCard(context, state),
            const SizedBox(height: 16),

            // Ajouter ici la nouvelle carte de détection
            _buildDetectionPromotionCard(context),
            const SizedBox(height: 16),

            _buildCategoriesSection(context, state),
            const SizedBox(height: 24),
            _buildUpcomingPaymentsSection(context, state),
            const SizedBox(height: 24),
            _buildOptimizationCard(context, state),
          ],
        ),
      ),
    );
  }

  // Méthode pour aider à optimiser les performances
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Préchargement des images pour améliorer les performances
    precacheImage(NetworkImage('https://example.com/placeholder.png'), context);
  }

  Widget _buildSummaryCard(BuildContext context, SubscriptionsLoadedState state) {
    final currencyFormat = NumberFormat.currency(locale: 'fr_FR', symbol: '€');

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            // Section gauche - Montant total
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Total mensuel',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    currencyFormat.format(state.totalMonthlyCost),
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                  Text(
                    '${state.subscriptions.length} abonnement${state.subscriptions.length > 1 ? 's' : ''} actif${state.subscriptions.length > 1 ? 's' : ''}',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),

            // Section droite - Graphique cercle
            const SizedBox(
              width: 80,
              height: 80,
              child: CustomPaint(
                painter: CirclePercentPainter(
                  percentage: 0.8, // 80%
                  activeColor: Colors.deepPurple,
                  backgroundColor: Color(0xFFEEEAFF),
                ),
                child: Center(
                  child: Text(
                    '80%',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.deepPurple,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoriesSection(BuildContext context, SubscriptionsLoadedState state) {
    final currencyFormat = NumberFormat.currency(locale: 'fr_FR', symbol: '€');

    // Regrouper les abonnements par catégorie et calculer les totaux
    final Map<SubscriptionCategory, double> categoryTotals = {};
    for (final subscription in state.subscriptions) {
      categoryTotals[subscription.category] =
          (categoryTotals[subscription.category] ?? 0) + subscription.monthlyCost;
    }

    // Définir les couleurs et icônes pour chaque catégorie
    final Map<SubscriptionCategory, Color> categoryColors = {
      SubscriptionCategory.streaming: Colors.purple,
      SubscriptionCategory.software: Colors.blue,
      SubscriptionCategory.gaming: Colors.green,
      SubscriptionCategory.news: Colors.orange,
      SubscriptionCategory.other: Colors.amber,
    };

    final Map<SubscriptionCategory, IconData> categoryIcons = {
      SubscriptionCategory.streaming: Icons.tv,
      SubscriptionCategory.software: Icons.cloud_outlined,
      SubscriptionCategory.gaming: Icons.sports_soccer,
      SubscriptionCategory.news: Icons.newspaper,
      SubscriptionCategory.other: Icons.music_note,
    };

    // Trier les catégories par coût total (décroissant)
    final List<SubscriptionCategory> sortedCategories = categoryTotals.keys.toList();
    sortedCategories.sort((a, b) => categoryTotals[b]!.compareTo(categoryTotals[a]!));

    // Prendre les 4 premières catégories pour l'affichage
    final displayCategories = sortedCategories.take(4).toList();

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Catégories',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            TextButton(
              onPressed: () {
                print("DEBUG: Navigation vers toutes les catégories demandée");
                // Navigation vers toutes les catégories
              },
              child: const Text('Voir tout'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.8,
          ),
          itemCount: displayCategories.length,
          itemBuilder: (context, index) {
            final category = displayCategories[index];
            final amount = categoryTotals[category]!;
            final color = categoryColors[category] ?? Colors.grey;
            final icon = categoryIcons[category] ?? Icons.category;

            return Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: Colors.grey.withAlpha(40)),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: color.withAlpha(30),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            icon,
                            color: color,
                            size: 18,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _getCategoryName(category),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${currencyFormat.format(amount)}/mois',
                      style: const TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildUpcomingPaymentsSection(BuildContext context, SubscriptionsLoadedState state) {
    final currencyFormat = NumberFormat.currency(locale: 'fr_FR', symbol: '€');

    // Identifier les services connus et leur associer une couleur
    final Map<String, Color> serviceColors = {
      'netflix': Colors.red,
      'spotify': Colors.green,
      'icloud': Colors.blue,
      'apple': Colors.grey,
      'disney': Colors.blue.shade700,
      'youtube': Colors.red.shade700,
      'amazon': Colors.orange,
      'google': Colors.blue.shade400,
    };

    // Trouver la couleur associée à un service
    Color getServiceColor(String name) {
      final lowerName = name.toLowerCase();
      for (final entry in serviceColors.entries) {
        if (lowerName.contains(entry.key)) {
          return entry.value;
        }
      }
      return Colors.purple; // Couleur par défaut
    }

    // Trier les abonnements par date de prochain paiement
    final sortedSubscriptions = List<Subscription>.from(state.subscriptions);
    sortedSubscriptions.sort((a, b) => a.nextPaymentDate.compareTo(b.nextPaymentDate));

    // Prendre les 3 prochains paiements
    final upcomingPayments = sortedSubscriptions.take(3).toList();

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Prochains paiements',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            TextButton(
              onPressed: () {
                print("DEBUG: Navigation vers le calendrier demandée");
                // Navigation vers le calendrier complet
              },
              child: const Text('Calendrier'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: upcomingPayments.length,
          itemBuilder: (context, index) {
            final subscription = upcomingPayments[index];
            final color = getServiceColor(subscription.name);

            // Formatter la date pour affichage
            String dateText;
            final now = DateTime.now();
            if (subscription.nextPaymentDate.year == now.year &&
                subscription.nextPaymentDate.month == now.month &&
                subscription.nextPaymentDate.day == now.day) {
              dateText = 'Aujourd\'hui';
            } else {
              final tomorrow = DateTime(now.year, now.month, now.day + 1);
              if (subscription.nextPaymentDate.year == tomorrow.year &&
                  subscription.nextPaymentDate.month == tomorrow.month &&
                  subscription.nextPaymentDate.day == tomorrow.day) {
                dateText = 'Demain';
              } else {
                dateText = DateFormat('d MMM', 'fr_FR').format(subscription.nextPaymentDate);
              }
            }

            // Ajouter une clé unique à chaque élément pour éviter les conflits de héros
            return Card(
              key: ValueKey('payment_${subscription.id}_$index'),
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: Colors.grey.withAlpha(40)),
              ),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: color.withAlpha(30),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(
                    child: Text(
                      subscription.name.isNotEmpty
                          ? subscription.name.substring(0, 1).toUpperCase()
                          : '?',
                      style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ),
                ),
                title: Text(
                  subscription.name,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  '$dateText · ${_getPeriodicityShort(subscription.periodicity)}',
                  style: const TextStyle(
                    fontSize: 12,
                  ),
                ),
                trailing: Text(
                  currencyFormat.format(subscription.amount),
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                onTap: () {
                  print("DEBUG: Navigation vers détail d'abonnement: ${subscription.id}");
                  // Navigation vers le détail de l'abonnement avec une clé spécifique pour éviter les conflits Hero
                  Navigator.pushNamed(
                    context,
                    Routes.subscriptionDetail,
                    arguments: subscription,
                  );
                },
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildOptimizationCard(BuildContext context, SubscriptionsLoadedState state) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Theme.of(context).primaryColor,
        borderRadius: BorderRadius.circular(16),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withAlpha(50),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.savings_outlined,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 12),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Économisez 20%',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  Text(
                    'Optimisez vos abonnements',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              print("DEBUG: Navigation vers les recommandations d'optimisation demandée");
              // Navigation vers les recommandations
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: Theme.of(context).primaryColor,
              elevation: 0,
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Center(
              child: Text(
                'Voir mes recommandations',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetectionPromotionCard(BuildContext context) {
    // Vérifier si c'est la première fois que l'utilisateur voit cette fonctionnalité
    // Cette logique devrait être implémentée avec SharedPreferences dans une vraie application
    final bool isFirstTime = true; // Remplacer par une vraie vérification

    return Card(
      margin: const EdgeInsets.all(0), // Modifié pour être cohérent avec les autres cartes
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      elevation: 4,
      child: InkWell(
        onTap: () {
          print("DEBUG: Navigation vers la page de détection d'abonnements demandée");
          // Utiliser une clé unique pour identifier cette navigation
          Navigator.pushNamed(
            context,
            Routes.detectSubscriptions,
            // Pas de Hero animation ici pour éviter le conflit
          );
        },
        borderRadius: BorderRadius.circular(16),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Theme.of(context).colorScheme.primary,
                Theme.of(context).colorScheme.secondary,
              ],
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.auto_awesome,
                      color: Colors.white,
                      size: 28,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text(
                          'NOUVEAU',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            fontSize: 12,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Détection automatique',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                'Découvrez vos abonnements automatiquement sans saisie manuelle',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 12),
              // Badges des méthodes de détection
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _buildDetectionMethodBadge(
                      context,
                      'Emails',
                      Icons.email_outlined
                  ),
                  _buildDetectionMethodBadge(
                      context,
                      'Relevés bancaires',
                      Icons.description_outlined
                  ),
                  _buildDetectionMethodBadge(
                      context,
                      'Catalogue',
                      Icons.search_outlined
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Bouton d'action
              Align(
                alignment: Alignment.centerRight,
                child: ElevatedButton.icon(
                  onPressed: () {
                    print("DEBUG: Navigation vers la page de détection d'abonnements via bouton 'Essayer'");
                    // Utiliser une clé unique pour cette navigation aussi
                    Navigator.pushNamed(
                      context,
                      Routes.detectSubscriptions,
                      // Pas de Hero animation ici
                    );
                  },
                  icon: const Icon(
                    Icons.arrow_forward,
                    color: Colors.white,
                  ),
                  label: const Text(
                    'Essayer maintenant',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.2),
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              // Tooltip conditionnel pour le premier lancement
              if (isFirstTime)
                Container(
                  margin: const EdgeInsets.only(top: 16),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.lightbulb_outline,
                        color: Theme.of(context).colorScheme.primary,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Économisez du temps en important automatiquement vos abonnements existants.',
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetectionMethodBadge(
      BuildContext context,
      String label,
      IconData icon
      ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: Colors.white,
            size: 14,
          ),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  String _getCategoryName(SubscriptionCategory category) {
    switch (category) {
      case SubscriptionCategory.streaming:
        return 'Streaming';
      case SubscriptionCategory.software:
        return 'Cloud';
      case SubscriptionCategory.gaming:
        return 'Sport';
      case SubscriptionCategory.news:
        return 'Actualités';
      case SubscriptionCategory.utility:
        return 'Services';
      case SubscriptionCategory.health:
        return 'Santé';
      case SubscriptionCategory.finance:
        return 'Finance';
      case SubscriptionCategory.education:
        return 'Éducation';
      case SubscriptionCategory.shopping:
        return 'Shopping';
      case SubscriptionCategory.other:
        return 'Musique';
    }
  }

  String _getPeriodicityShort(SubscriptionPeriodicity periodicity) {
    switch (periodicity) {
      case SubscriptionPeriodicity.daily:
        return 'Jour';
      case SubscriptionPeriodicity.weekly:
        return 'Hebdo';
      case SubscriptionPeriodicity.monthly:
        return 'Mensuel';
      case SubscriptionPeriodicity.quarterly:
        return 'Trim';
      case SubscriptionPeriodicity.biannual:
        return 'Sem';
      case SubscriptionPeriodicity.annual:
        return 'Annuel';
      case SubscriptionPeriodicity.custom:
        return 'Perso';
    }
  }
}

// Classe pour dessiner le cercle de pourcentage
class CirclePercentPainter extends CustomPainter {
  final double percentage;
  final Color activeColor;
  final Color backgroundColor;

  const CirclePercentPainter({
    required this.percentage,
    required this.activeColor,
    required this.backgroundColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    // Cercle de fond
    final backgroundPaint = Paint()
      ..color = backgroundColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8.0;

    canvas.drawCircle(center, radius - backgroundPaint.strokeWidth / 2, backgroundPaint);

    // Arc de progression
    final activePaint = Paint()
      ..color = activeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8.0
      ..strokeCap = StrokeCap.round;

    final angle = 2 * 3.14159 * percentage;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius - activePaint.strokeWidth / 2),
      -3.14159 / 2, // Commencer en haut
      angle,
      false,
      activePaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    if (oldDelegate is CirclePercentPainter) {
      return oldDelegate.percentage != percentage ||
          oldDelegate.activeColor != activeColor ||
          oldDelegate.backgroundColor != backgroundColor;
    }
    return true;
  }
}