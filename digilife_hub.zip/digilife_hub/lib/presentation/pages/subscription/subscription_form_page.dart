// lib/presentation/pages/subscription/subscription_form_page.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:digilife_hub/data/models/subscription_model.dart';
import 'package:digilife_hub/presentation/blocs/subscription/subscription_bloc_exports.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

class SubscriptionFormPage extends StatefulWidget {
  final Subscription? subscription;
  final bool isEditing;

  const SubscriptionFormPage({
    super.key,
    this.subscription,
    this.isEditing = false,
  });

  @override
  State<SubscriptionFormPage> createState() => _SubscriptionFormPageState();
}

class _SubscriptionFormPageState extends State<SubscriptionFormPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _amountController = TextEditingController();
  final _descriptionController = TextEditingController();

  DateTime _startDate = DateTime.now();
  DateTime _nextPaymentDate = DateTime.now().add(const Duration(days: 30));
  SubscriptionPeriodicity _periodicity = SubscriptionPeriodicity.monthly;
  SubscriptionCategory _category = SubscriptionCategory.other;
  SubscriptionStatus _status = SubscriptionStatus.active;
  bool _hasReminder = false;
  int _reminderDays = 3;

  bool _isLoading = false;

  @override
  void initState() {
    super.initState();

    // Si on est en mode édition, initialiser les champs avec les valeurs de l'abonnement
    if (widget.isEditing && widget.subscription != null) {
      _nameController.text = widget.subscription!.name;
      _amountController.text = widget.subscription!.amount.toString();
      _descriptionController.text = widget.subscription!.description ?? '';
      _startDate = widget.subscription!.startDate;
      _nextPaymentDate = widget.subscription!.nextPaymentDate;
      _periodicity = widget.subscription!.periodicity;
      _category = widget.subscription!.category;
      _status = widget.subscription!.status;
      _hasReminder = widget.subscription!.hasReminder;
      _reminderDays = widget.subscription!.reminderDays ?? 3;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _amountController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      final amount = double.tryParse(_amountController.text.replaceAll(',', '.')) ?? 0.0;

      // Créer ou mettre à jour l'abonnement
      final subscription = SubscriptionModel(
        id: widget.isEditing ? widget.subscription!.id : const Uuid().v4(),
        name: _nameController.text.trim(),
        amount: amount,
        periodicity: _periodicity,
        nextPaymentDate: _nextPaymentDate,
        category: _category,
        description: _descriptionController.text.trim(),
        logoUrl: null, // Pas d'upload de logo dans le MVP
        status: _status,
        startDate: _startDate,
        hasReminder: _hasReminder,
        reminderDays: _hasReminder ? _reminderDays : null,
      );

      if (widget.isEditing) {
        context.read<SubscriptionBloc>().add(UpdateSubscriptionEvent(subscription: subscription));
      } else {
        context.read<SubscriptionBloc>().add(AddSubscriptionEvent(subscription: subscription));
      }

      // Ne pas fermer la page immédiatement
      // La navigation sera gérée par le BlocListener
    }
  }

  Future<void> _selectDate(BuildContext context, bool isStartDate) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: isStartDate ? _startDate : _nextPaymentDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (pickedDate != null) {
      setState(() {
        if (isStartDate) {
          _startDate = pickedDate;
        } else {
          _nextPaymentDate = pickedDate;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isEditing ? 'Modifier l\'abonnement' : 'Ajouter un abonnement'),
      ),
      body: BlocListener<SubscriptionBloc, SubscriptionState>(
        listener: (context, state) {
          if (state is SubscriptionActionSuccessState) {
            setState(() {
              _isLoading = false;
            });

            // Afficher un SnackBar de succès avant de fermer la page
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: Colors.green,
                duration: const Duration(seconds: 1), // Durée courte
              ),
            );

            // Attendre un peu avant de naviguer pour que l'utilisateur voie le message
            Future.delayed(const Duration(milliseconds: 800), () {
              if (mounted) {
                Navigator.pop(context, true); // Retourner true pour indiquer un succès
              }
            });
          } else if (state is SubscriptionErrorState) {
            setState(() {
              _isLoading = false;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.failure.message),
                backgroundColor: Colors.red,
              ),
            );
          }
        },
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Informations de base
                _buildSectionTitle(context, 'Informations de base'),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nom du service *',
                    hintText: 'Ex: Netflix, Spotify, etc.',
                    prefixIcon: Icon(Icons.business),
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Veuillez entrer le nom du service';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<SubscriptionCategory>(
                  value: _category,
                  decoration: const InputDecoration(
                    labelText: 'Catégorie *',
                    prefixIcon: Icon(Icons.category),
                    border: OutlineInputBorder(),
                  ),
                  items: SubscriptionCategory.values.map((category) {
                    return DropdownMenuItem(
                      value: category,
                      child: Text(_getCategoryName(category)),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _category = value!;
                    });
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descriptionController,
                  decoration: const InputDecoration(
                    labelText: 'Description (optionnelle)',
                    hintText: 'Ajoutez des détails sur cet abonnement',
                    prefixIcon: Icon(Icons.description),
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                ),
                const SizedBox(height: 24),

                // Informations financières
                _buildSectionTitle(context, 'Informations financières'),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _amountController,
                  decoration: const InputDecoration(
                    labelText: 'Montant *',
                    hintText: 'Ex: 9.99',
                    prefixIcon: Icon(Icons.euro),
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Veuillez entrer le montant';
                    }
                    if (double.tryParse(value.replaceAll(',', '.')) == null) {
                      return 'Veuillez entrer un montant valide';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<SubscriptionPeriodicity>(
                  value: _periodicity,
                  decoration: const InputDecoration(
                    labelText: 'Périodicité *',
                    prefixIcon: Icon(Icons.update),
                    border: OutlineInputBorder(),
                  ),
                  items: SubscriptionPeriodicity.values.map((periodicity) {
                    return DropdownMenuItem(
                      value: periodicity,
                      child: Text(_getPeriodicityName(periodicity)),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _periodicity = value!;
                    });
                  },
                ),
                const SizedBox(height: 24),

                // Dates
                _buildSectionTitle(context, 'Dates'),
                const SizedBox(height: 16),
                _buildDatePicker(
                  context,
                  label: 'Date de début',
                  date: _startDate,
                  onTap: () => _selectDate(context, true),
                ),
                const SizedBox(height: 16),
                _buildDatePicker(
                  context,
                  label: 'Prochain paiement',
                  date: _nextPaymentDate,
                  onTap: () => _selectDate(context, false),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<SubscriptionStatus>(
                  value: _status,
                  decoration: const InputDecoration(
                    labelText: 'Statut',
                    prefixIcon: Icon(Icons.info_outline),
                    border: OutlineInputBorder(),
                  ),
                  items: SubscriptionStatus.values.map((status) {
                    return DropdownMenuItem(
                      value: status,
                      child: Text(_getStatusName(status)),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _status = value!;
                    });
                  },
                ),
                const SizedBox(height: 24),

                // Rappels
                _buildSectionTitle(context, 'Rappels'),
                const SizedBox(height: 16),
                SwitchListTile(
                  title: const Text('Activer les rappels'),
                  subtitle: const Text('Recevez des notifications avant la date de paiement'),
                  value: _hasReminder,
                  onChanged: (value) {
                    setState(() {
                      _hasReminder = value;
                    });
                  },
                  secondary: const Icon(Icons.notifications),
                ),
                if (_hasReminder) ...[
                  const SizedBox(height: 16),
                  DropdownButtonFormField<int>(
                    value: _reminderDays,
                    decoration: const InputDecoration(
                      labelText: 'Rappel avant échéance',
                      prefixIcon: Icon(Icons.timer),
                      border: OutlineInputBorder(),
                    ),
                    items: [1, 2, 3, 5, 7, 14].map((days) {
                      return DropdownMenuItem(
                        value: days,
                        child: Text('$days jour${days > 1 ? 's' : ''}'),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _reminderDays = value!;
                      });
                    },
                  ),
                ],
                const SizedBox(height: 32),

                // Bouton de soumission
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _submitForm,
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: _isLoading
                        ? const CircularProgressIndicator()
                        : Text(
                      widget.isEditing ? 'Mettre à jour' : 'Ajouter',
                      style: const TextStyle(fontSize: 16),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Divider(
          color: Theme.of(context).colorScheme.primary.withAlpha(50),
          thickness: 1,
        ),
      ],
    );
  }

  Widget _buildDatePicker(
      BuildContext context, {
        required String label,
        required DateTime date,
        required VoidCallback onTap,
      }) {
    final dateFormat = DateFormat('dd/MM/yyyy');
    return InkWell(
      onTap: onTap,
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: const Icon(Icons.calendar_today),
          border: const OutlineInputBorder(),
        ),
        child: Text(dateFormat.format(date)),
      ),
    );
  }

  String _getCategoryName(SubscriptionCategory category) {
    switch (category) {
      case SubscriptionCategory.streaming:
        return 'Streaming';
      case SubscriptionCategory.software:
        return 'Logiciels';
      case SubscriptionCategory.gaming:
        return 'Jeux';
      case SubscriptionCategory.news:
        return 'Actualités';
      case SubscriptionCategory.utility:
        return 'Services';
      case SubscriptionCategory.health:
        return 'Santé';
      case SubscriptionCategory.finance:
        return 'Finance';
      case SubscriptionCategory.education:
        return 'Éducation';
      case SubscriptionCategory.shopping:
        return 'Shopping';
      case SubscriptionCategory.other:
        return 'Autres';
    }
  }

  String _getPeriodicityName(SubscriptionPeriodicity periodicity) {
    switch (periodicity) {
      case SubscriptionPeriodicity.daily:
        return 'Quotidien';
      case SubscriptionPeriodicity.weekly:
        return 'Hebdomadaire';
      case SubscriptionPeriodicity.monthly:
        return 'Mensuel';
      case SubscriptionPeriodicity.quarterly:
        return 'Trimestriel';
      case SubscriptionPeriodicity.biannual:
        return 'Semestriel';
      case SubscriptionPeriodicity.annual:
        return 'Annuel';
      case SubscriptionPeriodicity.custom:
        return 'Personnalisé';
    }
  }

  String _getStatusName(SubscriptionStatus status) {
    switch (status) {
      case SubscriptionStatus.active:
        return 'Actif';
      case SubscriptionStatus.inactive:
        return 'Inactif';
      case SubscriptionStatus.trial:
        return 'Période d\'essai';
      case SubscriptionStatus.expiringSoon:
        return 'Expire bientôt';
      case SubscriptionStatus.expired:
        return 'Expiré';
    }
  }
}