// lib/presentation/pages/subscription/subscription_detail_page.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:digilife_hub/core/constants/routes.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:digilife_hub/presentation/blocs/subscription/subscription_bloc_exports.dart';
import 'package:intl/intl.dart';

class SubscriptionDetailPage extends StatelessWidget {
  final Subscription subscription;

  const SubscriptionDetailPage({
    super.key,
    required this.subscription,
  });

  void _deleteSubscription(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Supprimer l\'abonnement'),
        content: const Text('Êtes-vous sûr de vouloir supprimer cet abonnement ?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Annuler'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              context
                  .read<SubscriptionBloc>()
                  .add(DeleteSubscriptionEvent(id: subscription.id));
              Navigator.of(context).pop();
            },
            child: const Text('Supprimer'),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
          ),
        ],
      ),
    );
  }

  void _editSubscription(BuildContext context) {
    Navigator.pushNamed(
      context,
      Routes.updateSubscription,
      arguments: subscription,
    );
  }

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.currency(locale: 'fr_FR', symbol: '€');
    final dateFormat = DateFormat('dd/MM/yyyy');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Détails de l\'abonnement'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () => _editSubscription(context),
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () => _deleteSubscription(context),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
        // En-tête avec nom et statut
        Row(
        children: [
        Expanded(
        child: Text(
          subscription.name,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      _buildStatusBadge(context, subscription.status),
      ],
    ),
    const SizedBox(height: 24),

    // Informations principales
    _buildInfoCard(
    context,
    title: 'Informations principales',
    content: Column(
    children: [
    _buildInfoRow(
    context,
    icon: Icons.category,
    label: 'Catégorie',
    value: _getCategoryName(subscription.category),
    ),
    const Divider(),
    _buildInfoRow(
    context,
    icon: Icons.calendar_today,
    label: 'Date de début',
    value: dateFormat.format(subscription.startDate),
    ),
    const Divider(),
    _buildInfoRow(
    context,
    icon: Icons.calendar_month,
    label: 'Prochain paiement',
    value: dateFormat.format(subscription.nextPaymentDate),
    ),
    if (subscription.description != null && subscription.description!.isNotEmpty) ...[
    const Divider(),
    _buildInfoRow(
    context,
    icon: Icons.description,
    label: 'Description',
    value: subscription.description!,
    valueStyle: Theme.of(context).textTheme.bodyMedium,
    ),
    ],
    ],
    ),
    ),
    const SizedBox(height: 16),

    // Informations de coût
    _buildInfoCard(
    context,
    title: 'Informations de coût',
    content: Column(
    children: [
    _buildInfoRow(
    context,
    icon: Icons.attach_money,
    label: 'Montant',
    value: currencyFormat.format(subscription.amount),
    valueColor: Theme.of(context).colorScheme.primary,
    ),
    const Divider(),
    _buildInfoRow(
    context,
    icon: Icons.update,
    label: 'Périodicité',
    value: _getPeriodicityName(subscription.periodicity),
    ),
    const Divider(),
    _buildInfoRow(
    context,
    icon: Icons.calendar_month,
      label: 'Coût mensuel',
      value: currencyFormat.format(subscription.monthlyCost),
    ),
      const Divider(),
      _buildInfoRow(
        context,
        icon: Icons.calendar_month,
        label: 'Coût annuel',
        value: currencyFormat.format(subscription.annualCost),
      ),
    ],
    ),
    ),
            const SizedBox(height: 16),

            // Rappels
            _buildInfoCard(
              context,
              title: 'Rappels',
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildInfoRow(
                    context,
                    icon: Icons.notifications,
                    label: 'Rappels activés',
                    value: subscription.hasReminder ? 'Oui' : 'Non',
                    valueColor: subscription.hasReminder ? Colors.green : Colors.red,
                  ),
                  if (subscription.hasReminder && subscription.reminderDays != null) ...[
                    const Divider(),
                    _buildInfoRow(
                      context,
                      icon: Icons.timer,
                      label: 'Rappel avant échéance',
                      value: '${subscription.reminderDays} jour${subscription.reminderDays! > 1 ? 's' : ''}',
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(
      BuildContext context, {
        required String title,
        required Widget content,
      }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            content,
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(
      BuildContext context, {
        required IconData icon,
        required String label,
        required String value,
        Color? valueColor,
        TextStyle? valueStyle,
      }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: valueStyle != null
            ? CrossAxisAlignment.start
            : CrossAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 20,
            color: Colors.grey[600],
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.grey[600],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: valueStyle ?? Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: valueColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusBadge(BuildContext context, SubscriptionStatus status) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: _getStatusColor(status).withAlpha(30),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            _getStatusIcon(status),
            size: 16,
            color: _getStatusColor(status),
          ),
          const SizedBox(width: 4),
          Text(
            _getStatusName(status),
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: _getStatusColor(status),
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  String _getCategoryName(SubscriptionCategory category) {
    switch (category) {
      case SubscriptionCategory.streaming:
        return 'Streaming';
      case SubscriptionCategory.software:
        return 'Logiciels';
      case SubscriptionCategory.gaming:
        return 'Jeux';
      case SubscriptionCategory.news:
        return 'Actualités';
      case SubscriptionCategory.utility:
        return 'Services';
      case SubscriptionCategory.health:
        return 'Santé';
      case SubscriptionCategory.finance:
        return 'Finance';
      case SubscriptionCategory.education:
        return 'Éducation';
      case SubscriptionCategory.shopping:
        return 'Shopping';
      case SubscriptionCategory.other:
        return 'Autres';
    }
  }

  String _getPeriodicityName(SubscriptionPeriodicity periodicity) {
    switch (periodicity) {
      case SubscriptionPeriodicity.daily:
        return 'Quotidien';
      case SubscriptionPeriodicity.weekly:
        return 'Hebdomadaire';
      case SubscriptionPeriodicity.monthly:
        return 'Mensuel';
      case SubscriptionPeriodicity.quarterly:
        return 'Trimestriel';
      case SubscriptionPeriodicity.biannual:
        return 'Semestriel';
      case SubscriptionPeriodicity.annual:
        return 'Annuel';
      case SubscriptionPeriodicity.custom:
        return 'Personnalisé';
    }
  }

  String _getStatusName(SubscriptionStatus status) {
    switch (status) {
      case SubscriptionStatus.active:
        return 'Actif';
      case SubscriptionStatus.inactive:
        return 'Inactif';
      case SubscriptionStatus.trial:
        return 'Période d\'essai';
      case SubscriptionStatus.expiringSoon:
        return 'Expire bientôt';
      case SubscriptionStatus.expired:
        return 'Expiré';
    }
  }

  IconData _getStatusIcon(SubscriptionStatus status) {
    switch (status) {
      case SubscriptionStatus.active:
        return Icons.check_circle;
      case SubscriptionStatus.inactive:
        return Icons.pause_circle;
      case SubscriptionStatus.trial:
        return Icons.new_releases;
      case SubscriptionStatus.expiringSoon:
        return Icons.warning;
      case SubscriptionStatus.expired:
        return Icons.block;
    }
  }

  Color _getStatusColor(SubscriptionStatus status) {
    switch (status) {
      case SubscriptionStatus.active:
        return Colors.green;
      case SubscriptionStatus.inactive:
        return Colors.grey;
      case SubscriptionStatus.trial:
        return Colors.blue;
      case SubscriptionStatus.expiringSoon:
        return Colors.orange;
      case SubscriptionStatus.expired:
        return Colors.red;
    }
  }
}