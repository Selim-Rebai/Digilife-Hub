// lib/presentation/pages/subscription/subscription_dashboard_page.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:digilife_hub/core/constants/app_theme.dart';
import 'package:digilife_hub/core/constants/routes.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:digilife_hub/features/subscription_cancellation/presentation/bloc/cancellation_bloc.dart';
import 'package:digilife_hub/features/subscription_cancellation/presentation/pages/subscription_detail_cancellation.dart';
import 'package:digilife_hub/presentation/blocs/subscription/subscription_bloc_exports.dart';
import 'package:digilife_hub/presentation/widgets/common/loading_indicator.dart';
import 'package:digilife_hub/presentation/widgets/subscription/subscription_card.dart';
import 'package:digilife_hub/presentation/widgets/subscription/subscription_summary_card.dart';
import 'package:digilife_hub/presentation/widgets/subscription/category_filter_chip.dart';
import 'package:intl/intl.dart';
import 'package:digilife_hub/injection_container.dart' as di;

class SubscriptionDashboardPage extends StatefulWidget {
  const SubscriptionDashboardPage({super.key});

  @override
  State<SubscriptionDashboardPage> createState() => _SubscriptionDashboardPageState();
}

class _SubscriptionDashboardPageState extends State<SubscriptionDashboardPage> {
  final TextEditingController _searchController = TextEditingController();
  bool _isSearching = false;

  @override
  void initState() {
    super.initState();
    // Charger les abonnements au démarrage de la page
    context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onAddSubscriptionPressed() {
    Navigator.pushNamed(context, Routes.addSubscription).then((result) {
      // Rafraîchir les abonnements si l'opération a réussi ou si result est null
      // Le paramètre result sera true si l'ajout a réussi
      if (result == true || result == null) {
        context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
      }
    });
  }

  void _toggleSearch() {
    setState(() {
      _isSearching = !_isSearching;
      if (!_isSearching) {
        _searchController.clear();
        context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
      }
    });
  }

  void _onSearchChanged(String query) {
    if (query.isEmpty) {
      context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
    } else {
      context.read<SubscriptionBloc>().add(SearchSubscriptionsEvent(query: query));
    }
  }

  void _onCategorySelected(SubscriptionCategory category) {
    context.read<SubscriptionBloc>().add(FilterSubscriptionsByCategoryEvent(category: category));
  }

  void _showCancellationBottomSheet(BuildContext context, Subscription subscription) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => BlocProvider(
        create: (context) => di.sl<CancellationBloc>(),
        child: Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.7,
            child: SubscriptionDetailCancellation(
              subscription: subscription,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.currency(locale: 'fr_FR', symbol: '€');

    return Scaffold(
      appBar: AppBar(
        title: _isSearching
            ? TextField(
          controller: _searchController,
          decoration: const InputDecoration(
            hintText: 'Rechercher un abonnement...',
            border: InputBorder.none,
          ),
          autofocus: true,
          onChanged: _onSearchChanged,
        )
            : const Text('Mes Abonnements'),
        actions: [
          IconButton(
            icon: Icon(_isSearching ? Icons.close : Icons.search),
            onPressed: _toggleSearch,
          ),
        ],
      ),
      body: BlocConsumer<SubscriptionBloc, SubscriptionState>(
        listener: (context, state) {
          if (state is SubscriptionErrorState) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.failure.message),
                backgroundColor: Colors.red,
              ),
            );
          } else if (state is SubscriptionActionSuccessState) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: Colors.green,
              ),
            );
          }
        },
        builder: (context, state) {
          if (state is SubscriptionLoadingState) {
            return const Center(child: LoadingIndicator());
          } else if (state is SubscriptionsLoadedState) {
            return RefreshIndicator(
              onRefresh: () async {
                context.read<SubscriptionBloc>().add(RefreshSubscriptionsEvent());
              },
              child: CustomScrollView(
                slivers: [
                  // Résumé financier
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: SubscriptionSummaryCard(
                        monthlyTotal: state.totalMonthlyCost,
                        annualTotal: state.totalAnnualCost,
                        subscriptionCount: state.subscriptions.length,
                      ),
                    ),
                  ),

                  // Filtres par catégorie
                  SliverToBoxAdapter(
                    child: _buildCategoryFilters(state),
                  ),

                  // Titre de section
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            state.activeFilter != null
                                ? 'Catégorie : ${_getCategoryName(state.activeFilter!)}'
                                : state.searchQuery != null && state.searchQuery!.isNotEmpty
                                ? 'Résultats pour : ${state.searchQuery}'
                                : 'Tous les abonnements',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          Text(
                            '${state.subscriptions.length} abonnement${state.subscriptions.length > 1 ? 's' : ''}',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Liste des abonnements
                  state.subscriptions.isEmpty
                      ? SliverFillRemaining(
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.subscriptions_outlined,
                            size: 64,
                            color: Colors.grey,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            state.activeFilter != null || (state.searchQuery != null && state.searchQuery!.isNotEmpty)
                                ? 'Aucun abonnement trouvé'
                                : 'Aucun abonnement pour le moment',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              color: Colors.grey[600],
                            ),
                          ),
                          if (state.activeFilter != null || (state.searchQuery != null && state.searchQuery!.isNotEmpty))
                            TextButton(
                              onPressed: () {
                                context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
                              },
                              child: const Text('Voir tous les abonnements'),
                            ),
                        ],
                      ),
                    ),
                  )
                      : SliverPadding(
                    padding: const EdgeInsets.all(16.0),
                    sliver: SliverList(
                      delegate: SliverChildBuilderDelegate(
                            (context, index) {
                          final subscription = state.subscriptions[index];
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 12.0),
                            child: SubscriptionCard(
                              subscription: subscription,
                              onTap: () {
                                Navigator.pushNamed(
                                  context,
                                  Routes.subscriptionDetail,
                                  arguments: subscription,
                                ).then((_) {
                                  context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
                                });
                              },
                              onCancelTap: () {
                                _showCancellationBottomSheet(context, subscription);
                              },
                            ),
                          );
                        },
                        childCount: state.subscriptions.length,
                      ),
                    ),
                  ),
                ],
              ),
            );
          } else {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.subscriptions_outlined,
                    size: 64,
                    color: Colors.grey,
                  ),
                  const SizedBox(height: 16),
                  const Text('Chargez vos abonnements'),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
                    },
                    child: const Text('Charger'),
                  ),
                ],
              ),
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _onAddSubscriptionPressed,
        tooltip: 'Ajouter un abonnement',
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildCategoryFilters(SubscriptionsLoadedState state) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            // Puce "Tous" pour effacer les filtres
            CategoryFilterChip(
              label: 'Tous',
              icon: Icons.all_inclusive,
              isSelected: state.activeFilter == null,
              onSelected: (_) {
                context.read<SubscriptionBloc>().add(FilterSubscriptionsByCategoryEvent());
              },
            ),
            const SizedBox(width: 8),
            // Puces pour chaque catégorie
            ...SubscriptionCategory.values.map((category) {
              return Padding(
                padding: const EdgeInsets.only(right: 8.0),
                child: CategoryFilterChip(
                  label: _getCategoryName(category),
                  icon: _getCategoryIcon(category),
                  isSelected: state.activeFilter == category,
                  onSelected: (_) {
                    context.read<SubscriptionBloc>().add(FilterSubscriptionsByCategoryEvent(category: category));
                  },
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  String _getCategoryName(SubscriptionCategory category) {
    switch (category) {
      case SubscriptionCategory.streaming:
        return 'Streaming';
      case SubscriptionCategory.software:
        return 'Logiciels';
      case SubscriptionCategory.gaming:
        return 'Jeux';
      case SubscriptionCategory.news:
        return 'Actualités';
      case SubscriptionCategory.utility:
        return 'Services';
      case SubscriptionCategory.health:
        return 'Santé';
      case SubscriptionCategory.finance:
        return 'Finance';
      case SubscriptionCategory.education:
        return 'Éducation';
      case SubscriptionCategory.shopping:
        return 'Shopping';
      case SubscriptionCategory.other:
        return 'Autres';
    }
  }

  IconData _getCategoryIcon(SubscriptionCategory category) {
    switch (category) {
      case SubscriptionCategory.streaming:
        return Icons.play_circle_outline;
      case SubscriptionCategory.software:
        return Icons.code;
      case SubscriptionCategory.gaming:
        return Icons.sports_esports;
      case SubscriptionCategory.news:
        return Icons.newspaper;
      case SubscriptionCategory.utility:
        return Icons.electrical_services;
      case SubscriptionCategory.health:
        return Icons.favorite;
      case SubscriptionCategory.finance:
        return Icons.account_balance;
      case SubscriptionCategory.education:
        return Icons.school;
      case SubscriptionCategory.shopping:
        return Icons.shopping_bag;
      case SubscriptionCategory.other:
        return Icons.category;
    }
  }
}