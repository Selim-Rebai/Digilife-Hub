// lib/presentation/widgets/subscription/subscription_card.dart

import 'package:flutter/material.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:intl/intl.dart';

class SubscriptionCard extends StatelessWidget {
  final Subscription subscription;
  final VoidCallback onTap;
  final VoidCallback? onCancelTap;

  const SubscriptionCard({
    super.key,
    required this.subscription,
    required this.onTap,
    this.onCancelTap,
  });

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.currency(locale: 'fr_FR', symbol: '€');
    final dateFormat = DateFormat('dd/MM/yyyy');

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: _getBorderColor(subscription.status).withAlpha(50),
          width: 1,
        ),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  // Icône de la catégorie
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: _getCategoryColor(subscription.category).withAlpha(30),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      _getCategoryIcon(subscription.category),
                      color: _getCategoryColor(subscription.category),
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 16),

                  // Détails de l'abonnement
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                subscription.name,
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            _buildStatusBadge(context, subscription.status),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Prochain paiement : ${dateFormat.format(subscription.nextPaymentDate)}',
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Colors.grey[600],
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              currencyFormat.format(subscription.amount),
                              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                            ),
                            Text(
                              _getPeriodicityLabel(subscription.periodicity),
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // Flèche vers la droite
                  const Icon(
                    Icons.chevron_right,
                    color: Colors.grey,
                  ),
                ],
              ),

              // Bouton de résiliation en bas de la carte
              if (onCancelTap != null) ...[
                const SizedBox(height: 10),
                const Divider(height: 1),
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: OutlinedButton(
                      onPressed: onCancelTap,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.red,
                        minimumSize: const Size(100, 36),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18),
                        ),
                        side: const BorderSide(color: Colors.red),
                      ),
                      child: const Text('Résilier'),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusBadge(BuildContext context, SubscriptionStatus status) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: _getStatusColor(status).withAlpha(30),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        _getStatusLabel(status),
        style: Theme.of(context).textTheme.bodySmall?.copyWith(
          color: _getStatusColor(status),
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  String _getPeriodicityLabel(SubscriptionPeriodicity periodicity) {
    switch (periodicity) {
      case SubscriptionPeriodicity.daily:
        return '/ jour';
      case SubscriptionPeriodicity.weekly:
        return '/ semaine';
      case SubscriptionPeriodicity.monthly:
        return '/ mois';
      case SubscriptionPeriodicity.quarterly:
        return '/ trimestre';
      case SubscriptionPeriodicity.biannual:
        return '/ semestre';
      case SubscriptionPeriodicity.annual:
        return '/ an';
      case SubscriptionPeriodicity.custom:
        return '';
    }
  }

  String _getStatusLabel(SubscriptionStatus status) {
    switch (status) {
      case SubscriptionStatus.active:
        return 'Actif';
      case SubscriptionStatus.inactive:
        return 'Inactif';
      case SubscriptionStatus.trial:
        return 'Essai';
      case SubscriptionStatus.expiringSoon:
        return 'Expire bientôt';
      case SubscriptionStatus.expired:
        return 'Expiré';
    }
  }

  Color _getStatusColor(SubscriptionStatus status) {
    switch (status) {
      case SubscriptionStatus.active:
        return Colors.green;
      case SubscriptionStatus.inactive:
        return Colors.grey;
      case SubscriptionStatus.trial:
        return Colors.blue;
      case SubscriptionStatus.expiringSoon:
        return Colors.orange;
      case SubscriptionStatus.expired:
        return Colors.red;
    }
  }

  Color _getBorderColor(SubscriptionStatus status) {
    return _getStatusColor(status);
  }

  Color _getCategoryColor(SubscriptionCategory category) {
    switch (category) {
      case SubscriptionCategory.streaming:
        return Colors.red;
      case SubscriptionCategory.software:
        return Colors.blue;
      case SubscriptionCategory.gaming:
        return Colors.purple;
      case SubscriptionCategory.news:
        return Colors.orange;
      case SubscriptionCategory.utility:
        return Colors.green;
      case SubscriptionCategory.health:
        return Colors.pink;
      case SubscriptionCategory.finance:
        return Colors.indigo;
      case SubscriptionCategory.education:
        return Colors.teal;
      case SubscriptionCategory.shopping:
        return Colors.amber;
      case SubscriptionCategory.other:
        return Colors.grey;
    }
  }

  IconData _getCategoryIcon(SubscriptionCategory category) {
    switch (category) {
      case SubscriptionCategory.streaming:
        return Icons.play_circle_outline;
      case SubscriptionCategory.software:
        return Icons.code;
      case SubscriptionCategory.gaming:
        return Icons.sports_esports;
      case SubscriptionCategory.news:
        return Icons.newspaper;
      case SubscriptionCategory.utility:
        return Icons.electrical_services;
      case SubscriptionCategory.health:
        return Icons.favorite;
      case SubscriptionCategory.finance:
        return Icons.account_balance;
      case SubscriptionCategory.education:
        return Icons.school;
      case SubscriptionCategory.shopping:
        return Icons.shopping_bag;
      case SubscriptionCategory.other:
        return Icons.category;
    }
  }
}