// lib/presentation/widgets/subscription/subscription_summary_card.dart

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class SubscriptionSummaryCard extends StatelessWidget {
  final double monthlyTotal;
  final double annualTotal;
  final int subscriptionCount;

  const SubscriptionSummaryCard({
    super.key,
    required this.monthlyTotal,
    required this.annualTotal,
    required this.subscriptionCount,
  });

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.currency(locale: 'fr_FR', symbol: '€');

    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Theme.of(context).colorScheme.primary,
              Theme.of(context).colorScheme.primary.withAlpha(200),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Résumé de vos abonnements',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Vous avez $subscriptionCount abonnement${subscriptionCount > 1 ? 's' : ''}',
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildCostSummaryItem(
                    context,
                    title: 'Mensuel',
                    amount: monthlyTotal,
                    currencyFormat: currencyFormat,
                    icon: Icons.calendar_today,
                  ),
                  _buildCostSummaryItem(
                    context,
                    title: 'Annuel',
                    amount: annualTotal,
                    currencyFormat: currencyFormat,
                    icon: Icons.calendar_month,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCostSummaryItem(
      BuildContext context, {
        required String title,
        required double amount,
        required NumberFormat currencyFormat,
        required IconData icon,
      }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              icon,
              color: Colors.white70,
              size: 16,
            ),
            const SizedBox(width: 4),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 14,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          currencyFormat.format(amount),
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
      ],
    );
  }
}