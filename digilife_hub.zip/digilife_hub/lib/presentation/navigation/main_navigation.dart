// lib/presentation/navigation/main_navigation.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:digilife_hub/core/constants/routes.dart';
import 'package:digilife_hub/presentation/blocs/subscription/subscription_bloc_exports.dart';
import 'package:digilife_hub/presentation/pages/home/home_page.dart';
import 'package:digilife_hub/presentation/pages/subscription/subscription_dashboard_page.dart';
import 'package:digilife_hub/presentation/pages/calendar/calendar_page.dart';
import 'package:digilife_hub/presentation/pages/profile/profile_page.dart';

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _currentIndex = 0;

  // Liste des pages accessibles via la barre de navigation
  // Nous retirons la page SubscriptionFormPage de cette liste
  final List<Widget> _pages = [
    const HomePage(), // Page d'accueil avec le résumé des abonnements
    const SubscriptionDashboardPage(), // Page dashboard d'abonnements
    Container(), // Page vide pour l'index 2 (sera remplacée par une navigation)
    const CalendarPage(), // Calendrier des paiements
    const ProfilePage(), // Profil utilisateur
  ];

  void _onItemTapped(int index) {
    if (index == 2) {
      // Si c'est le bouton d'ajout, naviguer vers la page d'ajout
      Navigator.pushNamed(context, Routes.addSubscription).then((result) {
        // Rafraîchir les abonnements selon le résultat
        if (result == true) {
          // Si on était sur la page des abonnements, rafraîchir
          if (_currentIndex == 1) {
            context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
          }
          // Si on était sur la page d'accueil, rafraîchir aussi
          else if (_currentIndex == 0) {
            context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
          }
        }
      });
    } else {
      setState(() {
        _currentIndex = index;
      });

      // Rafraîchir les données quand on va sur la page d'abonnements ou d'accueil
      if (index == 0 || index == 1) {
        context.read<SubscriptionBloc>().add(LoadSubscriptionsEvent());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Theme.of(context).primaryColor,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: 'Accueil',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.subscriptions_outlined),
            activeIcon: Icon(Icons.subscriptions),
            label: 'Abonnements',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle_outline),
            activeIcon: Icon(Icons.add_circle),
            label: 'Ajouter',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today_outlined),
            activeIcon: Icon(Icons.calendar_today),
            label: 'Calendrier',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}