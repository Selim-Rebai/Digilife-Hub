// lib/domain/entities/subscription.dart

import 'package:equatable/equatable.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';

class Subscription extends Equatable {
  final String id;
  final String name;
  final double amount;
  final SubscriptionPeriodicity periodicity;
  final DateTime nextPaymentDate;
  final SubscriptionCategory category;
  final String? description;
  final String? logoUrl;
  final SubscriptionStatus status;
  final DateTime startDate;
  final bool hasReminder;
  final int? reminderDays;

  const Subscription({
    required this.id,
    required this.name,
    required this.amount,
    required this.periodicity,
    required this.nextPaymentDate,
    required this.category,
    this.description,
    this.logoUrl,
    required this.status,
    required this.startDate,
    required this.hasReminder,
    this.reminderDays,
  });

  @override
  List<Object?> get props => [
    id,
    name,
    amount,
    periodicity,
    nextPaymentDate,
    category,
    description,
    logoUrl,
    status,
    startDate,
    hasReminder,
    reminderDays
  ];

  /// Calcule le coût annuel de l'abonnement
  double get annualCost {
    switch (periodicity) {
      case SubscriptionPeriodicity.daily:
        return amount * 365;
      case SubscriptionPeriodicity.weekly:
        return amount * 52;
      case SubscriptionPeriodicity.monthly:
        return amount * 12;
      case SubscriptionPeriodicity.quarterly:
        return amount * 4;
      case SubscriptionPeriodicity.biannual:
        return amount * 2;
      case SubscriptionPeriodicity.annual:
        return amount;
      case SubscriptionPeriodicity.custom:
        return amount; // Pour les périodicités personnalisées, retourner simplement le montant
    }
  }

  /// Calcule le coût mensuel de l'abonnement
  double get monthlyCost {
    switch (periodicity) {
      case SubscriptionPeriodicity.daily:
        return amount * 30.4167; // Moyenne de jours par mois
      case SubscriptionPeriodicity.weekly:
        return amount * 4.34524; // Moyenne de semaines par mois
      case SubscriptionPeriodicity.monthly:
        return amount;
      case SubscriptionPeriodicity.quarterly:
        return amount / 3;
      case SubscriptionPeriodicity.biannual:
        return amount / 6;
      case SubscriptionPeriodicity.annual:
        return amount / 12;
      case SubscriptionPeriodicity.custom:
        return amount / 12; // Estimation par défaut
    }
  }

  /// Crée une copie de l'abonnement avec des valeurs optionnellement modifiées
  Subscription copyWith({
    String? id,
    String? name,
    double? amount,
    SubscriptionPeriodicity? periodicity,
    DateTime? nextPaymentDate,
    SubscriptionCategory? category,
    String? description,
    String? logoUrl,
    SubscriptionStatus? status,
    DateTime? startDate,
    bool? hasReminder,
    int? reminderDays,
  }) {
    return Subscription(
      id: id ?? this.id,
      name: name ?? this.name,
      amount: amount ?? this.amount,
      periodicity: periodicity ?? this.periodicity,
      nextPaymentDate: nextPaymentDate ?? this.nextPaymentDate,
      category: category ?? this.category,
      description: description ?? this.description,
      logoUrl: logoUrl ?? this.logoUrl,
      status: status ?? this.status,
      startDate: startDate ?? this.startDate,
      hasReminder: hasReminder ?? this.hasReminder,
      reminderDays: reminderDays ?? this.reminderDays,
    );
  }

  /// Crée un abonnement vide (utile pour les tests ou valeurs par défaut)
  factory Subscription.empty() => Subscription(
    id: '',
    name: '',
    amount: 0.0,
    periodicity: SubscriptionPeriodicity.monthly,
    nextPaymentDate: DateTime.now(),
    category: SubscriptionCategory.other,
    status: SubscriptionStatus.inactive,
    startDate: DateTime.now(),
    hasReminder: false,
  );
}