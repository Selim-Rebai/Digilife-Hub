// lib/domain/entities/subscription_enums.dart

/// Énumération des périodicités possibles pour un abonnement
enum SubscriptionPeriodicity {
  daily,     // Quotidien
  weekly,    // Hebdomadaire
  monthly,   // Mensuel
  quarterly, // Trimestriel
  biannual,  // Semestriel
  annual,    // Annuel
  custom     // Périodicité personnalisée
}

/// Énumération des catégories possibles pour un abonnement
enum SubscriptionCategory {
  streaming,    // Services de streaming (Netflix, Spotify, etc.)
  software,     // Logiciels et applications
  gaming,       // Jeux vidéo et services liés
  news,         // Actualités et magazines
  utility,      // Services publics (électricité, internet, etc.)
  health,       // Santé et bien-être
  finance,      // Services financiers
  education,    // Éducation et formation
  shopping,     // Shopping et box mensuelles
  other         // Autres types d'abonnements
}

/// Énumération des statuts possibles pour un abonnement
enum SubscriptionStatus {
  active,       // Abonnement actif
  inactive,     // Abonnement suspendu ou en pause
  trial,        // Période d'essai
  expiringSoon, // Expiration imminente
  expired       // Abonnement expiré
}