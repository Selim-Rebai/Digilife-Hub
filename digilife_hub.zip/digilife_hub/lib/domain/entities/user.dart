import 'package:equatable/equatable.dart';

class User extends Equatable {
  final String id;
  final String email;
  final String? displayName;
  final String? photoUrl;
  final bool emailVerified;
  final DateTime createdAt;
  final DateTime lastLogin;

  const User({
    required this.id,
    required this.email,
    this.displayName,
    this.photoUrl,
    required this.emailVerified,
    required this.createdAt,
    required this.lastLogin,
  });

  @override
  List<Object?> get props => [id, email, displayName, photoUrl, emailVerified, createdAt, lastLogin];

  // Crée un utilisateur par défaut avec un ID vide pour les cas non authentifiés
  factory User.empty() => User(
    id: '',
    email: '',
    emailVerified: false,
    createdAt: DateTime.now(),
    lastLogin: DateTime.now(),
  );

  bool get isEmpty => id.isEmpty;
  bool get isNotEmpty => id.isNotEmpty;
}