import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import 'package:digilife_hub/core/errors/auth_failures.dart';
import 'package:digilife_hub/domain/entities/user.dart';
import 'package:digilife_hub/domain/repositories/auth_repository.dart';

import '../../../core/errors/failures.dart';

class RegisterWithEmailPasswordUseCase {
  final AuthRepository repository;

  RegisterWithEmailPasswordUseCase(this.repository);

  Future<Either<Failure, User>> call(RegisterParams params) async {
    return await repository.registerWithEmailAndPassword(
      email: params.email,
      password: params.password,
      displayName: params.displayName,
    );
  }
}

class RegisterParams extends Equatable {
  final String email;
  final String password;
  final String? displayName;

  const RegisterParams({
    required this.email,
    required this.password,
    this.displayName,
  });

  @override
  List<Object?> get props => [email, password, displayName];
}