import 'package:dartz/dartz.dart';

import 'package:digilife_hub/core/errors/auth_failures.dart';
import 'package:digilife_hub/domain/repositories/auth_repository.dart';

import '../../../core/errors/failures.dart';

class SignOutUseCase {
  final AuthRepository repository;

  SignOutUseCase(this.repository);

  Future<Either<Failure, void>> call() async {
    return await repository.signOut();
  }
}