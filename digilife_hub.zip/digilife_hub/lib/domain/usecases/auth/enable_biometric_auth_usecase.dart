import 'package:dartz/dartz.dart';

import 'package:digilife_hub/core/errors/auth_failures.dart';
import 'package:digilife_hub/domain/repositories/auth_repository.dart';

import '../../../core/errors/failures.dart';

class EnableBiometricAuthUseCase {
  final AuthRepository repository;

  EnableBiometricAuthUseCase(this.repository);

  Future<Either<Failure, bool>> call() async {
    return await repository.enableBiometricAuth();
  }
}

class SignInWithBiometricUseCase {
  final AuthRepository repository;

  SignInWithBiometricUseCase(this.repository);

  Future<Either<Failure, dynamic>> call() async {
    return await repository.signInWithBiometric();
  }
}

class IsBiometricAvailableUseCase {
  final AuthRepository repository;

  IsBiometricAvailableUseCase(this.repository);

  Future<bool> call() async {
    return await repository.isBiometricAvailable();
  }
}