import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import 'package:digilife_hub/core/errors/auth_failures.dart';
import 'package:digilife_hub/domain/entities/user.dart';
import 'package:digilife_hub/domain/repositories/auth_repository.dart';

import '../../../core/errors/failures.dart';

class SignInWithEmailPasswordUseCase {
  final AuthRepository repository;

  SignInWithEmailPasswordUseCase(this.repository);

  Future<Either<Failure, User>> call(SignInParams params) async {
    return await repository.signInWithEmailAndPassword(
      email: params.email,
      password: params.password,
    );
  }
}

class SignInParams extends Equatable {
  final String email;
  final String password;

  const SignInParams({
    required this.email,
    required this.password,
  });

  @override
  List<Object> get props => [email, password];
}