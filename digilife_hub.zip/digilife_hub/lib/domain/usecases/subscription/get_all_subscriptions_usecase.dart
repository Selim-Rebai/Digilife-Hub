// lib/domain/usecases/subscription/get_all_subscriptions_usecase.dart

import 'package:dartz/dartz.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/repositories/subscription_repository.dart';

class GetAllSubscriptionsUseCase {
  final SubscriptionRepository repository;

  GetAllSubscriptionsUseCase(this.repository);

  Future<Either<Failure, List<Subscription>>> call() async {
    return await repository.getAllSubscriptions();
  }
}