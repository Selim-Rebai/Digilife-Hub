// lib/domain/usecases/subscription/calculate_total_annual_cost_usecase.dart

import 'package:dartz/dartz.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/domain/repositories/subscription_repository.dart';

class CalculateTotalAnnualCostUseCase {
  final SubscriptionRepository repository;

  CalculateTotalAnnualCostUseCase(this.repository);

  Future<Either<Failure, double>> call() async {
    return await repository.calculateTotalAnnualCost();
  }
}