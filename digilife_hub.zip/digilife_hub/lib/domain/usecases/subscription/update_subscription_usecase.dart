// lib/domain/usecases/subscription/update_subscription_usecase.dart

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/repositories/subscription_repository.dart';

class UpdateSubscriptionUseCase {
  final SubscriptionRepository repository;

  UpdateSubscriptionUseCase(this.repository);

  Future<Either<Failure, Subscription>> call(UpdateSubscriptionParams params) async {
    return await repository.updateSubscription(params.subscription);
  }
}

class UpdateSubscriptionParams extends Equatable {
  final Subscription subscription;

  const UpdateSubscriptionParams({required this.subscription});

  @override
  List<Object> get props => [subscription];
}