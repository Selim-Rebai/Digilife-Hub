// lib/domain/usecases/subscription/add_subscription_usecase.dart

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/repositories/subscription_repository.dart';

class AddSubscriptionUseCase {
  final SubscriptionRepository repository;

  AddSubscriptionUseCase(this.repository);

  Future<Either<Failure, Subscription>> call(AddSubscriptionParams params) async {
    return await repository.addSubscription(params.subscription);
  }
}

class AddSubscriptionParams extends Equatable {
  final Subscription subscription;

  const AddSubscriptionParams({required this.subscription});

  @override
  List<Object> get props => [subscription];
}