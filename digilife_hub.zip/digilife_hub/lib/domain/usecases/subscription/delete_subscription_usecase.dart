// lib/domain/usecases/subscription/delete_subscription_usecase.dart

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/domain/repositories/subscription_repository.dart';

class DeleteSubscriptionUseCase {
  final SubscriptionRepository repository;

  DeleteSubscriptionUseCase(this.repository);

  Future<Either<Failure, void>> call(DeleteSubscriptionParams params) async {
    return await repository.deleteSubscription(params.id);
  }
}

class DeleteSubscriptionParams extends Equatable {
  final String id;

  const DeleteSubscriptionParams({required this.id});

  @override
  List<Object> get props => [id];
}