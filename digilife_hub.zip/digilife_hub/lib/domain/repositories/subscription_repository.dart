// lib/domain/repositories/subscription_repository.dart

import 'package:dartz/dartz.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';

abstract class SubscriptionRepository {
  /// Obtient tous les abonnements de l'utilisateur actuel
  Future<Either<Failure, List<Subscription>>> getAllSubscriptions();

  /// Obtient un abonnement spécifique par son ID
  Future<Either<Failure, Subscription>> getSubscriptionById(String id);

  /// Ajoute un nouvel abonnement
  Future<Either<Failure, Subscription>> addSubscription(Subscription subscription);

  /// Met à jour un abonnement existant
  Future<Either<Failure, Subscription>> updateSubscription(Subscription subscription);

  /// Supprime un abonnement
  Future<Either<Failure, void>> deleteSubscription(String id);

  /// Obtient les abonnements par catégorie
  Future<Either<Failure, List<Subscription>>> getSubscriptionsByCategory(SubscriptionCategory category);

  /// Obtient les abonnements dont le paiement est à venir dans les X jours
  Future<Either<Failure, List<Subscription>>> getUpcomingSubscriptions(int days);

  /// Recherche des abonnements par nom
  Future<Either<Failure, List<Subscription>>> searchSubscriptions(String query);

  /// Calcule le coût total mensuel de tous les abonnements
  Future<Either<Failure, double>> calculateTotalMonthlyCost();

  /// Calcule le coût total annuel de tous les abonnements
  Future<Either<Failure, double>> calculateTotalAnnualCost();

  /// Obtient le stream des abonnements pour écouter les changements en temps réel
  Stream<List<Subscription>> subscriptionsStream();
}