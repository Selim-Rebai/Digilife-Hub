import 'package:dartz/dartz.dart';
import 'package:digilife_hub/core/errors/auth_failures.dart';
import 'package:digilife_hub/domain/entities/user.dart';

import '../../core/errors/failures.dart';

abstract class AuthRepository {
  // Retourne l'utilisateur actuel ou null si non authentifié
  Stream<User?> get user;

  // Vérifier si un utilisateur est connecté
  Future<bool> isSignedIn();

  // Inscription avec email et mot de passe
  Future<Either<Failure, User>> registerWithEmailAndPassword({
    required String email,
    required String password,
    String? displayName,
  });

  // Connexion avec email et mot de passe
  Future<Either<Failure, User>> signInWithEmailAndPassword({
    required String email,
    required String password,
  });

  // Connexion avec Google
  Future<Either<Failure, User>> signInWithGoogle();

  // Connexion avec Apple
  Future<Either<Failure, User>> signInWithApple();

  // Déconnexion
  Future<Either<Failure, void>> signOut();

  // Réinitialisation du mot de passe
  Future<Either<Failure, void>> sendPasswordResetEmail(String email);

  // Vérification de l'adresse email
  Future<Either<Failure, void>> sendEmailVerification();

  // Mise à jour du profil utilisateur
  Future<Either<Failure, User>> updateUserProfile({
    String? displayName,
    String? photoUrl,
  });

  // Supprimer le compte utilisateur
  Future<Either<Failure, void>> deleteAccount();

  // Vérifier si la biométrie est disponible
  Future<bool> isBiometricAvailable();

  // Activer l'authentification biométrique pour cet appareil
  Future<Either<Failure, bool>> enableBiometricAuth();

  // Se connecter avec la biométrie
  Future<Either<Failure, User>> signInWithBiometric();
}