// lib/features/subscription_cancellation/domain/services/cancellation_service.dart
import '../entities/cancellation_status.dart';
import '../entities/service_credentials.dart';

abstract class CancellationService {
  // Vérifier si le service peut être résilié via l'API
  Future<bool> isCancellationSupported(String serviceName);

  // Effectuer la résiliation
  Future<bool> cancelSubscription(
      String serviceName,
      String subscriptionId,
      ServiceCredentials credentials,
      );

  // Vérifier le statut d'une résiliation
  Future<CancellationStatus> checkCancellationStatus(
      String serviceName,
      String requestId,
      );
}