class ServiceCredentials {
  final String serviceName;
  final Map<String, String> credentials;

  const ServiceCredentials({
    required this.serviceName,
    required this.credentials,
  });

// Méthodes pour un stockage sécurisé
}