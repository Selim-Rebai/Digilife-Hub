import 'cancellation_status.dart';

class CancellationRequest {
  final String id;
  final String subscriptionId;
  final String serviceName;
  final DateTime requestDate;
  final CancellationStatus status;
  final String? message;
  final DateTime? completionDate;

  const CancellationRequest({
    required this.id,
    required this.subscriptionId,
    required this.serviceName,
    required this.requestDate,
    required this.status,
    this.message,
    this.completionDate,
  });
}