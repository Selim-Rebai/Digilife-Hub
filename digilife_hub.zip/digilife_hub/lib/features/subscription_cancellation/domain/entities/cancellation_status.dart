enum CancellationStatus {
  pending,
  inProgress,
  completed,
  failed,
  ineligible,
}
