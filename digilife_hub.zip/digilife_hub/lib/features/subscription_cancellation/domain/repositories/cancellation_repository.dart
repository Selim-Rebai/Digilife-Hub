// lib/features/subscription_cancellation/domain/repositories/cancellation_repository.dart
import 'package:dartz/dartz.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/cancellation_request.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/service_credentials.dart';

abstract class CancellationRepository {
  // Vérifier si un abonnement peut être résilié
  Future<Either<Failure, bool>> canCancelSubscription(String subscriptionId);

  // Initier une demande de résiliation
  Future<Either<Failure, CancellationRequest>> requestCancellation(
      String subscriptionId,
      ServiceCredentials credentials,
      );

  // Vérifier le statut d'une demande de résiliation
  Future<Either<Failure, CancellationRequest>> checkCancellationStatus(String requestId);

  // Obtenir l'historique des résiliations
  Future<Either<Failure, List<CancellationRequest>>> getCancellationHistory();
}

