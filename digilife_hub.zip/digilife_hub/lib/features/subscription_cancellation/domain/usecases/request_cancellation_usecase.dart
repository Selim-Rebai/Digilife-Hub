// lib/features/subscription_cancellation/domain/usecases/request_cancellation_usecase.dart
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/cancellation_request.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/service_credentials.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/repositories/cancellation_repository.dart';

class RequestCancellationUseCase {
  final CancellationRepository repository;

  RequestCancellationUseCase(this.repository);

  Future<Either<Failure, CancellationRequest>> call(RequestCancellationParams params) {
    return repository.requestCancellation(
      params.subscriptionId,
      params.credentials,
    );
  }
}

class RequestCancellationParams extends Equatable {
  final String subscriptionId;
  final ServiceCredentials credentials;

  const RequestCancellationParams({
    required this.subscriptionId,
    required this.credentials,
  });

  @override
  List<Object> get props => [subscriptionId, credentials];
}

