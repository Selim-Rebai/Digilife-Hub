// lib/features/subscription_cancellation/domain/usecases/check_cancellation_status_usecase.dart
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/cancellation_request.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/repositories/cancellation_repository.dart';

class CheckCancellationStatusUseCase {
  final CancellationRepository repository;

  CheckCancellationStatusUseCase(this.repository);

  Future<Either<Failure, CancellationRequest>> call(CheckCancellationStatusParams params) {
    return repository.checkCancellationStatus(params.requestId);
  }
}

class CheckCancellationStatusParams extends Equatable {
  final String requestId;

  const CheckCancellationStatusParams({required this.requestId});

  @override
  List<Object> get props => [requestId];
}