// Implémentons can_cancel_subscription_usecase.dart
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/repositories/cancellation_repository.dart';

class CanCancelSubscriptionUseCase {
  final CancellationRepository repository;

  CanCancelSubscriptionUseCase(this.repository);

  Future<Either<Failure, bool>> call(CanCancelSubscriptionParams params) {
    return repository.canCancelSubscription(params.subscriptionId);
  }
}

class CanCancelSubscriptionParams extends Equatable {
  final String subscriptionId;

  const CanCancelSubscriptionParams({required this.subscriptionId});

  @override
  List<Object> get props => [subscriptionId];
}