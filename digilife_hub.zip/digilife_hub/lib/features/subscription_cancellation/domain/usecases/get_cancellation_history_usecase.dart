// Implémentons get_cancellation_history_usecase.dart
import 'package:dartz/dartz.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/cancellation_request.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/repositories/cancellation_repository.dart';

class GetCancellationHistoryUseCase {
  final CancellationRepository repository;

  GetCancellationHistoryUseCase(this.repository);

  Future<Either<Failure, List<CancellationRequest>>> call() {
    return repository.getCancellationHistory();
  }
}