// lib/features/subscription_cancellation/data/repositories/cancellation_repository_impl.dart
import 'package:dartz/dartz.dart';
import 'package:uuid/uuid.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/cancellation_request.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/cancellation_status.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/service_credentials.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/repositories/cancellation_repository.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/services/cancellation_service.dart';

import '../../../../domain/entities/subscription_enums.dart';

class CancellationRepositoryImpl implements CancellationRepository {
  final List<CancellationService> _services;
  final List<CancellationRequest> _cancellationRequests = [];
  final Uuid _uuid = const Uuid();

  CancellationRepositoryImpl({
    required List<CancellationService> services,
  }) : _services = services;

  @override
  Future<Either<Failure, bool>> canCancelSubscription(String subscriptionId) async {
    try {
      // Obtenir le service correspondant à l'abonnement
      final subscription = await _getSubscriptionById(subscriptionId);
      if (subscription == null) {
        return const Left(NotFoundFailure('Abonnement non trouvé'));
      }

      // Vérifier si au moins un service peut gérer cette résiliation
      for (final service in _services) {
        if (await service.isCancellationSupported(subscription.name)) {
          return const Right(true);
        }
      }

      return const Right(false);
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, CancellationRequest>> requestCancellation(
      String subscriptionId,
      ServiceCredentials credentials,
      ) async {
    try {
      // Obtenir le service correspondant à l'abonnement
      final subscription = await _getSubscriptionById(subscriptionId);
      if (subscription == null) {
        return const Left(NotFoundFailure('Abonnement non trouvé'));
      }

      // Trouver le service approprié
      CancellationService? appropriateService;
      for (final service in _services) {
        if (await service.isCancellationSupported(subscription.name)) {
          appropriateService = service;
          break;
        }
      }

      if (appropriateService == null) {
        return const Left(NotSupportedFailure('Service de résiliation non pris en charge'));
      }

      // Effectuer la résiliation
      final success = await appropriateService.cancelSubscription(
        subscription.name,
        subscriptionId,
        credentials,
      );

      if (success) {
        // Créer une demande de résiliation
        final request = CancellationRequest(
          id: _uuid.v4(),
          subscriptionId: subscriptionId,
          serviceName: subscription.name,
          requestDate: DateTime.now(),
          status: CancellationStatus.inProgress,
        );

        _cancellationRequests.add(request);
        return Right(request);
      } else {
        return const Left(ProcessingFailure('Échec de la résiliation'));
      }
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, CancellationRequest>> checkCancellationStatus(String requestId) async {
    try {
      // Trouver la demande dans notre liste locale
      final request = _cancellationRequests.firstWhere(
            (request) => request.id == requestId,
        orElse: () => throw Exception('Demande non trouvée'),
      );

      // Trouver le service approprié
      CancellationService? appropriateService;
      for (final service in _services) {
        if (await service.isCancellationSupported(request.serviceName)) {
          appropriateService = service;
          break;
        }
      }

      if (appropriateService == null) {
        return const Left(NotSupportedFailure('Service de résiliation non pris en charge'));
      }

      // Vérifier le statut auprès du service
      final status = await appropriateService.checkCancellationStatus(
        request.serviceName,
        requestId,
      );

      // Mettre à jour la demande
      final updatedRequest = CancellationRequest(
        id: request.id,
        subscriptionId: request.subscriptionId,
        serviceName: request.serviceName,
        requestDate: request.requestDate,
        status: status,
        message: request.message,
        completionDate: status == CancellationStatus.completed ? DateTime.now() : null,
      );

      // Mettre à jour la liste locale
      final index = _cancellationRequests.indexWhere((r) => r.id == requestId);
      if (index >= 0) {
        _cancellationRequests[index] = updatedRequest;
      }

      return Right(updatedRequest);
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<CancellationRequest>>> getCancellationHistory() async {
    try {
      return Right(_cancellationRequests);
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }

  // Méthode simulée pour obtenir un abonnement par ID
  Future<Subscription?> _getSubscriptionById(String id) async {
    // Ceci devrait être remplacé par une vraie requête à votre repository d'abonnements
    // Pour l'exemple, nous simulons un abonnement
    return Subscription(
      id: id,
      name: 'Spotify',
      amount: 9.99,
      periodicity: SubscriptionPeriodicity.monthly,
      nextPaymentDate: DateTime.now().add(const Duration(days: 15)),
      category: SubscriptionCategory.streaming,
      status: SubscriptionStatus.active,
      startDate: DateTime.now().subtract(const Duration(days: 45)),
      hasReminder: true,
    );
  }
}