// lib/features/subscription_cancellation/data/services/spotify_cancellation_service.dart
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/cancellation_status.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/service_credentials.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/services/cancellation_service.dart';

class SpotifyCancellationService implements CancellationService {
  final Dio _dio;

  SpotifyCancellationService({required Dio dio}) : _dio = dio;

  @override
  Future<bool> isCancellationSupported(String serviceName) async {
    return serviceName.toLowerCase() == 'spotify';
  }

  @override
  Future<bool> cancelSubscription(
      String serviceName,
      String subscriptionId,
      ServiceCredentials credentials,
      ) async {
    if (!await isCancellationSupported(serviceName)) {
      return false;
    }

    try {
      // Obtenez d'abord un token d'accès
      final accessToken = await _getAccessToken(credentials);

      // Appeler l'API Spotify pour résilier l'abonnement
      final response = await _dio.put(
        'https://api.spotify.com/v1/me/subscriptions/cancel',
        options: Options(
          headers: {
            'Authorization': 'Bearer $accessToken',
            'Content-Type': 'application/json',
          },
        ),
        data: {
          'reason': 'cancellation_via_digilife_hub',
        },
      );

      return response.statusCode == 200;
    } catch (e) {
      // Gérer les erreurs
      print('Erreur lors de la résiliation Spotify: $e');
      return false;
    }
  }

  @override
  Future<CancellationStatus> checkCancellationStatus(
      String serviceName,
      String requestId,
      ) async {
    if (!await isCancellationSupported(serviceName)) {
      return CancellationStatus.ineligible;
    }

    // En réalité, il faudrait vérifier via l'API Spotify
    // Pour l'exemple, nous retournons un statut par défaut
    return CancellationStatus.completed;
  }

  // Méthode pour obtenir un token d'accès
  Future<String> _getAccessToken(ServiceCredentials credentials) async {
    try {
      final username = credentials.credentials['username'];
      final password = credentials.credentials['password'];

      // Encoder les identifiants en Base64
      final encodedCredentials = base64Encode(utf8.encode('$username:$password'));

      // Faire la demande de token
      final response = await _dio.post(
        'https://accounts.spotify.com/api/token',
        options: Options(
          headers: {
            'Authorization': 'Basic $encodedCredentials',
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        ),
        data: {
          'grant_type': 'client_credentials',
        },
      );

      if (response.statusCode == 200) {
        return response.data['access_token'];
      } else {
        throw Exception('Échec de l\'authentification Spotify');
      }
    } catch (e) {
      throw Exception('Erreur lors de l\'obtention du token: $e');
    }
  }
}