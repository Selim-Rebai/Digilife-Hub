// lib/features/subscription_cancellation/presentation/bloc/cancellation_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/usecases/can_cancel_subscription_usecase.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/usecases/request_cancellation_usecase.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/usecases/check_cancellation_status_usecase.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/usecases/get_cancellation_history_usecase.dart';
import 'package:digilife_hub/features/subscription_cancellation/presentation/bloc/cancellation_event.dart';
import 'package:digilife_hub/features/subscription_cancellation/presentation/bloc/cancellation_state.dart';

class CancellationBloc extends Bloc<CancellationEvent, CancellationState> {
  final CanCancelSubscriptionUseCase canCancelSubscriptionUseCase;
  final RequestCancellationUseCase requestCancellationUseCase;
  final CheckCancellationStatusUseCase checkCancellationStatusUseCase;
  final GetCancellationHistoryUseCase getCancellationHistoryUseCase;

  CancellationBloc({
    required this.canCancelSubscriptionUseCase,
    required this.requestCancellationUseCase,
    required this.checkCancellationStatusUseCase,
    required this.getCancellationHistoryUseCase,
  }) : super(CancellationInitial()) {
    on<CheckCancellationSupportEvent>(_onCheckCancellationSupport);
    on<RequestCancellationEvent>(_onRequestCancellation);
    on<CheckCancellationStatusEvent>(_onCheckCancellationStatus);
    on<LoadCancellationHistoryEvent>(_onLoadCancellationHistory);
  }

  Future<void> _onCheckCancellationSupport(
      CheckCancellationSupportEvent event,
      Emitter<CancellationState> emit,
      ) async {
    emit(CancellationLoading());

    final result = await canCancelSubscriptionUseCase(
      CanCancelSubscriptionParams(subscriptionId: event.subscriptionId),
    );

    result.fold(
          (failure) => emit(CancellationError(failure: failure)),
          (isSupported) => emit(CancellationSupported(isSupported: isSupported)),
    );
  }

  Future<void> _onRequestCancellation(
      RequestCancellationEvent event,
      Emitter<CancellationState> emit,
      ) async {
    emit(CancellationLoading());

    final result = await requestCancellationUseCase(
      RequestCancellationParams(
        subscriptionId: event.subscriptionId,
        credentials: event.credentials,
      ),
    );

    result.fold(
          (failure) => emit(CancellationError(failure: failure)),
          (request) => emit(CancellationRequested(request: request)),
    );
  }

  Future<void> _onCheckCancellationStatus(
      CheckCancellationStatusEvent event,
      Emitter<CancellationState> emit,
      ) async {
    emit(CancellationLoading());

    final result = await checkCancellationStatusUseCase(
      CheckCancellationStatusParams(requestId: event.requestId),
    );

    result.fold(
          (failure) => emit(CancellationError(failure: failure)),
          (request) => emit(CancellationStatusLoaded(request: request)),
    );
  }

  Future<void> _onLoadCancellationHistory(
      LoadCancellationHistoryEvent event,
      Emitter<CancellationState> emit,
      ) async {
    emit(CancellationLoading());

    final result = await getCancellationHistoryUseCase();

    result.fold(
          (failure) => emit(CancellationError(failure: failure)),
          (history) => emit(CancellationHistoryLoaded(history: history)),
    );
  }
}