// lib/features/subscription_cancellation/presentation/bloc/cancellation_state.dart
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/cancellation_request.dart';

abstract class CancellationState extends Equatable {
  const CancellationState();

  @override
  List<Object?> get props => [];
}

class CancellationInitial extends CancellationState {}

class CancellationLoading extends CancellationState {}

class CancellationSupported extends CancellationState {
  final bool isSupported;

  const CancellationSupported({required this.isSupported});

  @override
  List<Object> get props => [isSupported];
}

class CancellationRequested extends CancellationState {
  final CancellationRequest request;

  const CancellationRequested({required this.request});

  @override
  List<Object> get props => [request];
}

class CancellationStatusLoaded extends CancellationState {
  final CancellationRequest request;

  const CancellationStatusLoaded({required this.request});

  @override
  List<Object> get props => [request];
}

class CancellationHistoryLoaded extends CancellationState {
  final List<CancellationRequest> history;

  const CancellationHistoryLoaded({required this.history});

  @override
  List<Object> get props => [history];
}

class CancellationError extends CancellationState {
  final Failure failure;

  const CancellationError({required this.failure});

  @override
  List<Object> get props => [failure];
}