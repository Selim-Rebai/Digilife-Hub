// lib/features/subscription_cancellation/presentation/bloc/cancellation_event.dart
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/service_credentials.dart';

abstract class CancellationEvent extends Equatable {
  const CancellationEvent();

  @override
  List<Object?> get props => [];
}

class CheckCancellationSupportEvent extends CancellationEvent {
  final String subscriptionId;

  const CheckCancellationSupportEvent({required this.subscriptionId});

  @override
  List<Object> get props => [subscriptionId];
}

class RequestCancellationEvent extends CancellationEvent {
  final String subscriptionId;
  final ServiceCredentials credentials;

  const RequestCancellationEvent({
    required this.subscriptionId,
    required this.credentials,
  });

  @override
  List<Object> get props => [subscriptionId, credentials];
}

class CheckCancellationStatusEvent extends CancellationEvent {
  final String requestId;

  const CheckCancellationStatusEvent({required this.requestId});

  @override
  List<Object> get props => [requestId];
}

class LoadCancellationHistoryEvent extends CancellationEvent {}



