// Complétons le fichier cancellation_confirmation_dialog.dart
import 'package:flutter/material.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/service_credentials.dart';
import 'package:digilife_hub/features/subscription_cancellation/presentation/widgets/service_credentials_form.dart';
import 'package:intl/intl.dart';

import '../../../../domain/entities/subscription_enums.dart';

class CancellationConfirmationDialog extends StatefulWidget {
  final Subscription subscription;
  final Function(ServiceCredentials) onConfirm;

  const CancellationConfirmationDialog({
    super.key,
    required this.subscription,
    required this.onConfirm,
  });

  @override
  State<CancellationConfirmationDialog> createState() => _CancellationConfirmationDialogState();
}

class _CancellationConfirmationDialogState extends State<CancellationConfirmationDialog> {
  final currencyFormat = NumberFormat.currency(locale: 'fr_FR', symbol: '€');
  bool _showCredentialsForm = false;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Confirmer la résiliation'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!_showCredentialsForm) ...[
              const Text(
                'Êtes-vous sûr de vouloir résilier cet abonnement ?',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              _buildSubscriptionInfo(),
              const SizedBox(height: 16),
              const Text(
                'En confirmant, nous allons initier le processus de résiliation auprès du fournisseur.',
              ),
              const SizedBox(height: 8),
              const Text(
                'Vous recevrez une confirmation par email une fois la résiliation effectuée.',
                style: TextStyle(
                  fontStyle: FontStyle.italic,
                  fontSize: 12,
                ),
              ),
            ] else ...[
              ServiceCredentialsForm(
                serviceName: widget.subscription.name,
                onSubmit: widget.onConfirm,
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text('Annuler'),
        ),
        if (!_showCredentialsForm)
          ElevatedButton(
            onPressed: () {
              setState(() {
                _showCredentialsForm = true;
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Résilier'),
          ),
      ],
    );
  }

  Widget _buildSubscriptionInfo() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.subscription.name,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Montant:'),
              Text(
                currencyFormat.format(widget.subscription.amount),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Périodicité:'),
              Text(_getPeriodicityName(widget.subscription.periodicity)),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Économie annuelle:'),
              Text(
                currencyFormat.format(widget.subscription.annualCost),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _getPeriodicityName(SubscriptionPeriodicity periodicity) {
    switch (periodicity) {
      case SubscriptionPeriodicity.daily:
        return 'Quotidien';
      case SubscriptionPeriodicity.weekly:
        return 'Hebdomadaire';
      case SubscriptionPeriodicity.monthly:
        return 'Mensuel';
      case SubscriptionPeriodicity.quarterly:
        return 'Trimestriel';
      case SubscriptionPeriodicity.biannual:
        return 'Semestriel';
      case SubscriptionPeriodicity.annual:
        return 'Annuel';
      case SubscriptionPeriodicity.custom:
        return 'Personnalisé';
    }
  }
}