// Complétons le fichier service_credentials_form.dart
import 'package:flutter/material.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/service_credentials.dart';

class ServiceCredentialsForm extends StatefulWidget {
  final String serviceName;
  final Function(ServiceCredentials) onSubmit;

  const ServiceCredentialsForm({
    super.key,
    required this.serviceName,
    required this.onSubmit,
  });

  @override
  State<ServiceCredentialsForm> createState() => _ServiceCredentialsFormState();
}

class _ServiceCredentialsFormState extends State<ServiceCredentialsForm> {
  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isPasswordVisible = false;

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final credentials = ServiceCredentials(
        serviceName: widget.serviceName,
        credentials: {
          'username': _usernameController.text.trim(),
          'password': _passwordController.text,
        },
      );

      widget.onSubmit(credentials);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Identifiants pour ${widget.serviceName}',
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _usernameController,
            decoration: const InputDecoration(
              labelText: 'Email ou nom d\'utilisateur',
              prefixIcon: Icon(Icons.email),
              border: OutlineInputBorder(),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Veuillez entrer votre identifiant';
              }
              return null;
            },
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _passwordController,
            decoration: InputDecoration(
              labelText: 'Mot de passe',
              prefixIcon: const Icon(Icons.lock),
              suffixIcon: IconButton(
                icon: Icon(
                  _isPasswordVisible ? Icons.visibility_off : Icons.visibility,
                ),
                onPressed: () {
                  setState(() {
                    _isPasswordVisible = !_isPasswordVisible;
                  });
                },
              ),
              border: const OutlineInputBorder(),
            ),
            obscureText: !_isPasswordVisible,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Veuillez entrer votre mot de passe';
              }
              return null;
            },
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _submitForm,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 12),
                backgroundColor: Theme.of(context).primaryColor,
              ),
              child: const Text('Confirmer'),
            ),
          ),
        ],
      ),
    );
  }
}