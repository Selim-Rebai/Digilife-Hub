// Créons cancellation_history_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/cancellation_request.dart';
import 'package:digilife_hub/features/subscription_cancellation/domain/entities/cancellation_status.dart';
import 'package:digilife_hub/features/subscription_cancellation/presentation/bloc/cancellation_bloc.dart';
import 'package:digilife_hub/features/subscription_cancellation/presentation/bloc/cancellation_event.dart';
import 'package:digilife_hub/features/subscription_cancellation/presentation/bloc/cancellation_state.dart';
import 'package:intl/intl.dart';

class CancellationHistoryPage extends StatefulWidget {
  const CancellationHistoryPage({super.key});

  @override
  State<CancellationHistoryPage> createState() => _CancellationHistoryPageState();
}

class _CancellationHistoryPageState extends State<CancellationHistoryPage> {
  @override
  void initState() {
    super.initState();
    context.read<CancellationBloc>().add(LoadCancellationHistoryEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Historique des résiliations'),
      ),
      body: BlocBuilder<CancellationBloc, CancellationState>(
        builder: (context, state) {
          if (state is CancellationLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is CancellationHistoryLoaded) {
            if (state.history.isEmpty) {
              return const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.history,
                      size: 64,
                      color: Colors.grey,
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Aucune résiliation effectuée',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              );
            }

            return ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: state.history.length,
              itemBuilder: (context, index) {
                final request = state.history[index];
                return _buildCancellationCard(request);
              },
            );
          } else if (state is CancellationError) {
            return Center(
              child: Text(
                'Erreur: ${state.failure.message}',
                style: const TextStyle(color: Colors.red),
              ),
            );
          }

          return const Center(
            child: Text('Chargement de l\'historique...'),
          );
        },
      ),
    );
  }

  Widget _buildCancellationCard(CancellationRequest request) {
    final dateFormat = DateFormat('dd/MM/yyyy');

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    request.serviceName,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
                _buildStatusBadge(request.status),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Text(
                  'Demandée le ${dateFormat.format(request.requestDate)}',
                  style: const TextStyle(color: Colors.grey),
                ),
              ],
            ),
            if (request.completionDate != null) ...[
              const SizedBox(height: 4),
              Row(
                children: [
                  const Icon(Icons.check_circle, size: 16, color: Colors.green),
                  const SizedBox(width: 4),
                  Text(
                    'Terminée le ${dateFormat.format(request.completionDate!)}',
                    style: const TextStyle(color: Colors.green),
                  ),
                ],
              ),
            ],
            if (request.message != null) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(8),
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(request.message!),
              ),
            ],
            const SizedBox(height: 8),
            if (request.status == CancellationStatus.pending ||
                request.status == CancellationStatus.inProgress) ...[
              ElevatedButton.icon(
                onPressed: () {
                  context.read<CancellationBloc>().add(
                    CheckCancellationStatusEvent(requestId: request.id),
                  );
                },
                icon: const Icon(Icons.refresh),
                label: const Text('Actualiser le statut'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStatusBadge(CancellationStatus status) {
    String label;
    Color color;

    switch (status) {
      case CancellationStatus.pending:
        label = 'En attente';
        color = Colors.orange;
        break;
      case CancellationStatus.inProgress:
        label = 'En cours';
        color = Colors.blue;
        break;
      case CancellationStatus.completed:
        label = 'Terminée';
        color = Colors.green;
        break;
      case CancellationStatus.failed:
        label = 'Échouée';
        color = Colors.red;
        break;
      case CancellationStatus.ineligible:
        label = 'Non éligible';
        color = Colors.grey;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}