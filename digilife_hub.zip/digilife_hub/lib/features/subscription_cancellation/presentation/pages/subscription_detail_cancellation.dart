// lib/features/subscription_cancellation/presentation/pages/subscription_detail_cancellation.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/presentation/blocs/subscription/subscription_bloc_exports.dart';

class SubscriptionDetailCancellation extends StatelessWidget {
  final Subscription subscription;

  const SubscriptionDetailCancellation({
    super.key,
    required this.subscription,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Résiliation d\'abonnement',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Vous êtes sur le point de résilier votre abonnement à ${subscription.name}.',
            style: const TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 12),
          Text(
            'Montant: ${subscription.amount.toStringAsFixed(2)} €',
            style: const TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 24),
          const Text(
            'Note: La résiliation supprimer l\'abonnement directement de votre liste.',
            style: TextStyle(
              color: Colors.orange,
              fontStyle: FontStyle.italic,
            ),
          ),
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Annuler'),
              ),
              const SizedBox(width: 16),
              ElevatedButton(
                onPressed: () => _confirmCancellation(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
                child: const Text('Confirmer la résiliation'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _confirmCancellation(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Confirmer la résiliation'),
        content: Text(
          'Êtes-vous sûr de vouloir résilier votre abonnement à ${subscription.name}?',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(dialogContext);
            },
            child: const Text('Annuler'),
          ),
          ElevatedButton(
            onPressed: () {
              // Fermer la boîte de dialogue
              Navigator.pop(dialogContext);

              // Supprimer l'abonnement de Firebase
              context.read<SubscriptionBloc>().add(
                DeleteSubscriptionEvent(id: subscription.id),
              );

              // Fermer la bottom sheet
              Navigator.pop(context);

              // Afficher un message de confirmation
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Abonnement résilié avec succès'),
                  backgroundColor: Colors.green,
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Confirmer'),
          ),
        ],
      ),
    );
  }
}