// lib/features/subscription_detection/domain/entities/subscription_template.dart

import 'package:equatable/equatable.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';

/// Représente un modèle d'abonnement prédéfini pour faciliter l'ajout
class SubscriptionTemplate extends Equatable {
  /// Identifiant unique du modèle
  final String id;

  /// Nom du service d'abonnement
  final String name;

  /// Description du service
  final String description;

  /// Catégorie de l'abonnement
  final SubscriptionCategory category;

  /// Prix typique ou par défaut
  final double? typicalPrice;

  /// Périodicité typique (mensuelle, annuelle, etc.)
  final SubscriptionPeriodicity typicalPeriodicity;

  /// URL de l'icône ou du logo
  final String? logoUrl;

  /// Mots-clés pour la recherche
  final List<String> keywords;

  /// Noms d'expéditeurs d'email associés (pour la détection par email)
  final List<String> emailSenders;

  /// Noms de commerçants associés (pour la détection par relevé bancaire)
  final List<String> merchantNames;

  /// Site web officiel du service
  final String? website;

  /// Indique si c'est un service populaire
  final bool isPopular;

  const SubscriptionTemplate({
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    this.typicalPrice,
    required this.typicalPeriodicity,
    this.logoUrl,
    this.keywords = const [],
    this.emailSenders = const [],
    this.merchantNames = const [],
    this.website,
    this.isPopular = false,
  });

  @override
  List<Object?> get props => [
    id,
    name,
    description,
    category,
    typicalPrice,
    typicalPeriodicity,
    logoUrl,
    keywords,
    emailSenders,
    merchantNames,
    website,
    isPopular,
  ];
}