// lib/features/subscription_detection/domain/entities/detected_subscription.dart

import 'package:equatable/equatable.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';

/// Représente un abonnement détecté automatiquement
class DetectedSubscription extends Equatable {
  /// Nom du service ou fournisseur d'abonnement
  final String name;

  /// Montant suggéré de l'abonnement
  final double? suggestedAmount;

  /// Montant minimum observé (pour les abonnements variables)
  final double? minAmount;

  /// Montant maximum observé (pour les abonnements variables)
  final double? maxAmount;

  /// Catégorie suggérée pour l'abonnement
  final SubscriptionCategory? suggestedCategory;

  /// Périodicité suggérée (mensuel, annuel, etc.)
  final SubscriptionPeriodicity? suggestedPeriodicity;

  /// URL du logo si disponible
  final String? logoUrl;

  /// Description suggérée pour l'abonnement
  final String? suggestedDescription;

  /// Date suggérée pour le prochain paiement
  final DateTime? suggestedNextPaymentDate;

  /// Source de détection (email, CSV, etc.)
  final DetectionSource source;

  /// Niveau de confiance (0.0 à 1.0) dans la détection
  final double confidenceScore;

  /// Métadonnées supplémentaires (dépend de la source)
  final Map<String, dynamic> metadata;

  const DetectedSubscription({
    required this.name,
    this.suggestedAmount,
    this.minAmount,
    this.maxAmount,
    this.suggestedCategory,
    this.suggestedPeriodicity,
    this.logoUrl,
    this.suggestedDescription,
    this.suggestedNextPaymentDate,
    required this.source,
    required this.confidenceScore,
    this.metadata = const {},
  });

  @override
  List<Object?> get props => [
    name,
    suggestedAmount,
    minAmount,
    maxAmount,
    suggestedCategory,
    suggestedPeriodicity,
    logoUrl,
    suggestedDescription,
    suggestedNextPaymentDate,
    source,
    confidenceScore,
    metadata,
  ];
}

/// Sources possibles pour la détection d'un abonnement
enum DetectionSource {
  email,
  csvImport,
  template,
  manualEntry,
}