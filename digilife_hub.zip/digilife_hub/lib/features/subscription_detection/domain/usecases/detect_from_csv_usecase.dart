// lib/features/subscription_detection/domain/usecases/detect_from_csv_usecase.dart

import 'dart:io';
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/core/usecases/usecase.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';
import 'package:digilife_hub/features/subscription_detection/domain/repositories/subscription_detection_repository.dart';

class DetectFromCsvUseCase implements UseCase<List<DetectedSubscription>, DetectFromCsvParams> {
  final SubscriptionDetectionRepository repository;

  DetectFromCsvUseCase(this.repository);

  @override
  Future<Either<Failure, List<DetectedSubscription>>> call(DetectFromCsvParams params) {
    return repository.detectFromCsv(
      csvFile: params.csvFile,
      csvFormat: params.csvFormat,
      startDate: params.startDate,
    );
  }
}

class DetectFromCsvParams extends Equatable {
  final File csvFile;
  final CsvFormat csvFormat;
  final DateTime? startDate;

  const DetectFromCsvParams({
    required this.csvFile,
    required this.csvFormat,
    this.startDate,
  });

  @override
  List<Object?> get props => [csvFile, csvFormat, startDate];
}