// lib/features/subscription_detection/domain/usecases/get_subscription_templates_usecase.dart

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/core/usecases/usecase.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/subscription_template.dart';
import 'package:digilife_hub/features/subscription_detection/domain/repositories/subscription_detection_repository.dart';

class GetSubscriptionTemplatesUseCase implements UseCase<List<SubscriptionTemplate>, GetSubscriptionTemplatesParams> {
  final SubscriptionDetectionRepository repository;

  GetSubscriptionTemplatesUseCase(this.repository);

  @override
  Future<Either<Failure, List<SubscriptionTemplate>>> call(GetSubscriptionTemplatesParams params) {
    return repository.getSubscriptionTemplates(
      searchQuery: params.searchQuery,
      limit: params.limit,
    );
  }
}

class GetSubscriptionTemplatesParams extends Equatable {
  final String? searchQuery;
  final int limit;

  const GetSubscriptionTemplatesParams({
    this.searchQuery,
    this.limit = 20,
  });

  @override
  List<Object?> get props => [searchQuery, limit];
}