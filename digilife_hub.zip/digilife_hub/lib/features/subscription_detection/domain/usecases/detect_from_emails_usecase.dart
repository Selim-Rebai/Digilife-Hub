// lib/features/subscription_detection/domain/usecases/detect_from_emails_usecase.dart

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/core/usecases/usecase.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';
import 'package:digilife_hub/features/subscription_detection/domain/repositories/subscription_detection_repository.dart';

class DetectFromEmailsUseCase implements UseCase<List<DetectedSubscription>, DetectFromEmailsParams> {
  final SubscriptionDetectionRepository repository;

  DetectFromEmailsUseCase(this.repository);

  @override
  Future<Either<Failure, List<DetectedSubscription>>> call(DetectFromEmailsParams params) {
    return repository.detectFromEmails(
      userEmail: params.userEmail,
      accessToken: params.accessToken,
      startDate: params.startDate,
      maxResults: params.maxResults,
    );
  }
}

class DetectFromEmailsParams extends Equatable {
  final String userEmail;
  final String accessToken;
  final DateTime? startDate;
  final int maxResults;

  const DetectFromEmailsParams({
    required this.userEmail,
    required this.accessToken,
    this.startDate,
    this.maxResults = 100,
  });

  @override
  List<Object?> get props => [userEmail, accessToken, startDate, maxResults];
}