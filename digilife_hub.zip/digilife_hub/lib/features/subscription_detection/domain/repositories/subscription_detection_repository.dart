// lib/features/subscription_detection/domain/repositories/subscription_detection_repository.dart

import 'dart:io';
import 'package:dartz/dartz.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/subscription_template.dart';

/// Repository pour la détection automatique d'abonnements
abstract class SubscriptionDetectionRepository {
  /// Détecte les abonnements à partir des emails de l'utilisateur
  ///
  /// Nécessite une autorisation pour accéder à la boite email
  Future<Either<Failure, List<DetectedSubscription>>> detectFromEmails({
    required String userEmail,
    required String accessToken,
    DateTime? startDate,
    int maxResults = 100,
  });

  /// Détecte les abonnements à partir d'un fichier CSV importé
  ///
  /// Le fichier CSV doit contenir des données de transactions bancaires
  Future<Either<Failure, List<DetectedSubscription>>> detectFromCsv({
    required File csvFile,
    required CsvFormat csvFormat,
    DateTime? startDate,
  });

  /// Obtient la liste des modèles d'abonnements pour l'autocomplétion
  Future<Either<Failure, List<SubscriptionTemplate>>> getSubscriptionTemplates({
    String? searchQuery,
    int limit = 20,
  });

  /// Recherche les modèles d'abonnements correspondant à un texte
  Future<Either<Failure, List<SubscriptionTemplate>>> searchTemplates({
    required String query,
    int limit = 10,
  });

  /// Crée un abonnement détecté à partir d'un modèle
  Future<Either<Failure, DetectedSubscription>> createFromTemplate({
    required String templateId,
  });
}

/// Format de fichier CSV à utiliser pour l'analyse
enum CsvFormat {
  genericBank,
  creditAgricole,
  bnpParibas,
  societeGenerale,
  boursorama,
  ingDirect,
  revolut,
  n26,
  custom,
}