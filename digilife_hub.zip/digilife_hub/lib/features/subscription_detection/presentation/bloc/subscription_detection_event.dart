// lib/features/subscription_detection/presentation/bloc/subscription_detection_event.dart

import 'dart:io';
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/features/subscription_detection/domain/repositories/subscription_detection_repository.dart';

abstract class SubscriptionDetectionEvent extends Equatable {
  const SubscriptionDetectionEvent();

  @override
  List<Object?> get props => [];
}

/// Événement pour détecter les abonnements à partir des emails
class DetectFromEmailsEvent extends SubscriptionDetectionEvent {
  final String userEmail;
  final String accessToken;
  final DateTime? startDate;
  final int maxResults;

  const DetectFromEmailsEvent({
    required this.userEmail,
    required this.accessToken,
    this.startDate,
    this.maxResults = 100,
  });

  @override
  List<Object?> get props => [userEmail, accessToken, startDate, maxResults];
}

/// Événement pour détecter les abonnements à partir d'un fichier CSV
class DetectFromCsvEvent extends SubscriptionDetectionEvent {
  final File csvFile;
  final CsvFormat csvFormat;
  final DateTime? startDate;

  const DetectFromCsvEvent({
    required this.csvFile,
    required this.csvFormat,
    this.startDate,
  });

  @override
  List<Object?> get props => [csvFile, csvFormat, startDate];
}

/// Événement pour rechercher des modèles d'abonnements
class SearchSubscriptionTemplatesEvent extends SubscriptionDetectionEvent {
  final String query;
  final int limit;

  const SearchSubscriptionTemplatesEvent({
    required this.query,
    this.limit = 10,
  });

  @override
  List<Object> get props => [query, limit];
}

/// Événement pour obtenir les modèles d'abonnements populaires
class GetPopularTemplatesEvent extends SubscriptionDetectionEvent {
  final int limit;

  const GetPopularTemplatesEvent({this.limit = 10});

  @override
  List<Object> get props => [limit];
}

/// Événement pour créer un abonnement à partir d'un modèle
class CreateFromTemplateEvent extends SubscriptionDetectionEvent {
  final String templateId;

  const CreateFromTemplateEvent({required this.templateId});

  @override
  List<Object> get props => [templateId];
}

/// Événement pour ajouter un abonnement détecté à la liste des abonnements de l'utilisateur
class AddDetectedSubscriptionEvent extends SubscriptionDetectionEvent {
  final String subscriptionId;

  const AddDetectedSubscriptionEvent({required this.subscriptionId});

  @override
  List<Object> get props => [subscriptionId];
}

/// Événement pour ignorer un abonnement détecté
class IgnoreDetectedSubscriptionEvent extends SubscriptionDetectionEvent {
  final String subscriptionId;

  const IgnoreDetectedSubscriptionEvent({required this.subscriptionId});

  @override
  List<Object> get props => [subscriptionId];
}

/// Événement pour effacer toutes les détections
class ClearDetectionsEvent extends SubscriptionDetectionEvent {}