// lib/features/subscription_detection/presentation/bloc/subscription_detection_state.dart

import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/subscription_template.dart';

abstract class SubscriptionDetectionState extends Equatable {
  const SubscriptionDetectionState();

  @override
  List<Object?> get props => [];
}

/// État initial
class SubscriptionDetectionInitial extends SubscriptionDetectionState {}

/// État en cours de chargement
class SubscriptionDetectionLoading extends SubscriptionDetectionState {
  final String message;

  const SubscriptionDetectionLoading({this.message = 'Chargement en cours...'});

  @override
  List<Object> get props => [message];
}

/// État après détection réussie depuis les emails
class EmailDetectionSuccess extends SubscriptionDetectionState {
  final List<DetectedSubscription> detectedSubscriptions;

  const EmailDetectionSuccess({required this.detectedSubscriptions});

  @override
  List<Object> get props => [detectedSubscriptions];
}

/// État après détection réussie depuis un CSV
class CsvDetectionSuccess extends SubscriptionDetectionState {
  final List<DetectedSubscription> detectedSubscriptions;

  const CsvDetectionSuccess({required this.detectedSubscriptions});

  @override
  List<Object> get props => [detectedSubscriptions];
}

/// État après récupération des modèles d'abonnements
class TemplatesLoadedState extends SubscriptionDetectionState {
  final List<SubscriptionTemplate> templates;
  final String? searchQuery;

  const TemplatesLoadedState({
    required this.templates,
    this.searchQuery,
  });

  @override
  List<Object?> get props => [templates, searchQuery];
}

/// État après création d'un abonnement à partir d'un modèle
class TemplateCreationSuccess extends SubscriptionDetectionState {
  final DetectedSubscription detectedSubscription;

  const TemplateCreationSuccess({required this.detectedSubscription});

  @override
  List<Object> get props => [detectedSubscription];
}

/// État d'erreur
class SubscriptionDetectionError extends SubscriptionDetectionState {
  final Failure failure;

  const SubscriptionDetectionError({required this.failure});

  @override
  List<Object> get props => [failure];
}

/// État après ajout d'un abonnement détecté aux abonnements de l'utilisateur
class SubscriptionAddedState extends SubscriptionDetectionState {
  final String subscriptionId;
  final String message;

  const SubscriptionAddedState({
    required this.subscriptionId,
    this.message = 'Abonnement ajouté avec succès',
  });

  @override
  List<Object> get props => [subscriptionId, message];
}

/// État combiné contenant tout l'état de détection
class SubscriptionDetectionCompleteState extends SubscriptionDetectionState {
  final List<DetectedSubscription> emailDetections;
  final List<DetectedSubscription> csvDetections;
  final List<SubscriptionTemplate> popularTemplates;
  final List<String> addedSubscriptionIds;
  final List<String> ignoredSubscriptionIds;

  const SubscriptionDetectionCompleteState({
    this.emailDetections = const [],
    this.csvDetections = const [],
    this.popularTemplates = const [],
    this.addedSubscriptionIds = const [],
    this.ignoredSubscriptionIds = const [],
  });

  /// Tous les abonnements détectés (email et CSV)
  List<DetectedSubscription> get allDetections => [...emailDetections, ...csvDetections];

  /// Abonnements qui n'ont pas encore été traités (ni ajoutés ni ignorés)
  List<DetectedSubscription> get pendingDetections => allDetections
      .where((detection) =>
  !addedSubscriptionIds.contains(detection.name) &&
      !ignoredSubscriptionIds.contains(detection.name))
      .toList();

  /// Crée une copie avec des valeurs modifiées
  SubscriptionDetectionCompleteState copyWith({
    List<DetectedSubscription>? emailDetections,
    List<DetectedSubscription>? csvDetections,
    List<SubscriptionTemplate>? popularTemplates,
    List<String>? addedSubscriptionIds,
    List<String>? ignoredSubscriptionIds,
  }) {
    return SubscriptionDetectionCompleteState(
      emailDetections: emailDetections ?? this.emailDetections,
      csvDetections: csvDetections ?? this.csvDetections,
      popularTemplates: popularTemplates ?? this.popularTemplates,
      addedSubscriptionIds: addedSubscriptionIds ?? this.addedSubscriptionIds,
      ignoredSubscriptionIds: ignoredSubscriptionIds ?? this.ignoredSubscriptionIds,
    );
  }

  @override
  List<Object> get props => [
    emailDetections,
    csvDetections,
    popularTemplates,
    addedSubscriptionIds,
    ignoredSubscriptionIds,
  ];
}