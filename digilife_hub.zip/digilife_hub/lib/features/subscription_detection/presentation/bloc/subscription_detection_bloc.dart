// lib/features/subscription_detection/presentation/bloc/subscription_detection_bloc.dart

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:digilife_hub/features/subscription_detection/domain/usecases/detect_from_emails_usecase.dart';
import 'package:digilife_hub/features/subscription_detection/domain/usecases/detect_from_csv_usecase.dart';
import 'package:digilife_hub/features/subscription_detection/domain/usecases/get_subscription_templates_usecase.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/bloc/subscription_detection_event.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/bloc/subscription_detection_state.dart';
import 'package:digilife_hub/domain/usecases/subscription/add_subscription_usecase.dart';
import 'package:digilife_hub/data/models/subscription_model.dart';
import 'package:uuid/uuid.dart';
import 'package:digilife_hub/features/subscription_detection/data/repositories/subscription_detection_repository_impl.dart';
import '../../../../domain/entities/subscription_enums.dart';
import '../../domain/entities/detected_subscription.dart';

class SubscriptionDetectionBloc extends Bloc<SubscriptionDetectionEvent, SubscriptionDetectionState> {
  final DetectFromEmailsUseCase detectFromEmailsUseCase;
  final DetectFromCsvUseCase detectFromCsvUseCase;
  final GetSubscriptionTemplatesUseCase getSubscriptionTemplatesUseCase;
  final AddSubscriptionUseCase addSubscriptionUseCase;

  // État interne pour maintenir toutes les données détectées
  SubscriptionDetectionCompleteState _completeState = const SubscriptionDetectionCompleteState();

  SubscriptionDetectionBloc({
    required this.detectFromEmailsUseCase,
    required this.detectFromCsvUseCase,
    required this.getSubscriptionTemplatesUseCase,
    required this.addSubscriptionUseCase,
  }) : super(SubscriptionDetectionInitial()) {
    print("DEBUG: SubscriptionDetectionBloc - Constructeur");
    on<DetectFromEmailsEvent>(_onDetectFromEmails);
    on<DetectFromCsvEvent>(_onDetectFromCsv);
    on<SearchSubscriptionTemplatesEvent>(_onSearchSubscriptionTemplates);
    on<GetPopularTemplatesEvent>(_onGetPopularTemplates);
    on<CreateFromTemplateEvent>(_onCreateFromTemplate);
    on<AddDetectedSubscriptionEvent>(_onAddDetectedSubscription);
    on<IgnoreDetectedSubscriptionEvent>(_onIgnoreDetectedSubscription);
    on<ClearDetectionsEvent>(_onClearDetections);
  }

  Future<void> _onDetectFromEmails(
      DetectFromEmailsEvent event,
      Emitter<SubscriptionDetectionState> emit,
      ) async {
    print("DEBUG: Traitement de DetectFromEmailsEvent");
    print("DEBUG: Paramètres - email: ${event.userEmail}, maxResults: ${event.maxResults}");

    emit(const SubscriptionDetectionLoading(message: 'Analyse des emails en cours...'));
    print("DEBUG: État SubscriptionDetectionLoading émis");

    final result = await detectFromEmailsUseCase(
      DetectFromEmailsParams(
        userEmail: event.userEmail,
        accessToken: event.accessToken,
        startDate: event.startDate,
        maxResults: event.maxResults,
      ),
    );
    print("DEBUG: Résultat du cas d'utilisation obtenu");

    result.fold(
          (failure) {
        print("DEBUG: ÉCHEC de la détection par email: ${failure.message}");
        emit(SubscriptionDetectionError(failure: failure));
      },
          (detectedSubscriptions) {
        print("DEBUG: SUCCÈS - ${detectedSubscriptions.length} abonnements détectés");
        // Mise à jour de l'état interne
        _completeState = _completeState.copyWith(
          emailDetections: detectedSubscriptions,
        );

        // Émettre les deux états: le résultat immédiat et l'état complet
        emit(EmailDetectionSuccess(detectedSubscriptions: detectedSubscriptions));
        print("DEBUG: État EmailDetectionSuccess émis");
        emit(_completeState);
        print("DEBUG: État complet émis");
      },
    );
  }

  Future<void> _onDetectFromCsv(
      DetectFromCsvEvent event,
      Emitter<SubscriptionDetectionState> emit,
      ) async {
    print("DEBUG: Traitement de DetectFromCsvEvent");
    print("DEBUG: Fichier CSV: ${event.csvFile.path}, format: ${event.csvFormat}");

    emit(const SubscriptionDetectionLoading(message: 'Analyse du fichier CSV en cours...'));
    print("DEBUG: État SubscriptionDetectionLoading émis");

    final result = await detectFromCsvUseCase(
      DetectFromCsvParams(
        csvFile: event.csvFile,
        csvFormat: event.csvFormat,
        startDate: event.startDate,
      ),
    );
    print("DEBUG: Résultat du cas d'utilisation obtenu");

    result.fold(
          (failure) {
        print("DEBUG: ÉCHEC de la détection par CSV: ${failure.message}");
        emit(SubscriptionDetectionError(failure: failure));
      },
          (detectedSubscriptions) {
        print("DEBUG: SUCCÈS - ${detectedSubscriptions.length} abonnements détectés");
        // Mise à jour de l'état interne
        _completeState = _completeState.copyWith(
          csvDetections: detectedSubscriptions,
        );

        // Émettre les deux états
        emit(CsvDetectionSuccess(detectedSubscriptions: detectedSubscriptions));
        print("DEBUG: État CsvDetectionSuccess émis");
        emit(_completeState);
        print("DEBUG: État complet émis");
      },
    );
  }

  Future<void> _onSearchSubscriptionTemplates(
      SearchSubscriptionTemplatesEvent event,
      Emitter<SubscriptionDetectionState> emit,
      ) async {
    print("DEBUG: Traitement de SearchSubscriptionTemplatesEvent");
    print("DEBUG: Requête: ${event.query}, limite: ${event.limit}");

    emit(const SubscriptionDetectionLoading(message: 'Recherche de services d\'abonnement...'));
    print("DEBUG: État SubscriptionDetectionLoading émis");

    final result = await getSubscriptionTemplatesUseCase(
      GetSubscriptionTemplatesParams(
        searchQuery: event.query,
        limit: event.limit,
      ),
    );
    print("DEBUG: Résultat du cas d'utilisation obtenu");

    result.fold(
          (failure) {
        print("DEBUG: ÉCHEC de la recherche de templates: ${failure.message}");
        emit(SubscriptionDetectionError(failure: failure));
      },
          (templates) {
        print("DEBUG: SUCCÈS - ${templates.length} templates trouvés");
        emit(TemplatesLoadedState(
          templates: templates,
          searchQuery: event.query,
        ));
        print("DEBUG: État TemplatesLoadedState émis");
      },
    );
  }

  Future<void> _onGetPopularTemplates(
      GetPopularTemplatesEvent event,
      Emitter<SubscriptionDetectionState> emit,
      ) async {
    print("DEBUG: Traitement de GetPopularTemplatesEvent");
    print("DEBUG: Limite: ${event.limit}");

    emit(const SubscriptionDetectionLoading(message: 'Chargement des services populaires...'));
    print("DEBUG: État SubscriptionDetectionLoading émis");

    final result = await getSubscriptionTemplatesUseCase(
      GetSubscriptionTemplatesParams(limit: event.limit),
    );
    print("DEBUG: Résultat du cas d'utilisation obtenu");

    result.fold(
          (failure) {
        print("DEBUG: ÉCHEC du chargement des templates populaires: ${failure.message}");
        emit(SubscriptionDetectionError(failure: failure));
      },
          (templates) {
        print("DEBUG: SUCCÈS - ${templates.length} templates chargés");
        // Filtrer pour ne garder que les templates populaires
        final popularTemplates = templates
            .where((template) => template.isPopular)
            .toList();
        print("DEBUG: ${popularTemplates.length} templates populaires filtrés");

        // Mise à jour de l'état interne
        _completeState = _completeState.copyWith(
          popularTemplates: popularTemplates,
        );

        // Émettre les deux états
        emit(TemplatesLoadedState(templates: popularTemplates));
        print("DEBUG: État TemplatesLoadedState émis");
        emit(_completeState);
        print("DEBUG: État complet émis");
      },
    );
  }

  Future<void> _onCreateFromTemplate(
      CreateFromTemplateEvent event,
      Emitter<SubscriptionDetectionState> emit,
      ) async {
    print("DEBUG: Traitement de CreateFromTemplateEvent");
    print("DEBUG: Template ID: ${event.templateId}");

    emit(const SubscriptionDetectionLoading(message: 'Création de l\'abonnement...'));
    print("DEBUG: État SubscriptionDetectionLoading émis");

    // Ici, nous devrions normalement appeler un usecase, mais pour simplifier,
    // nous allons créer l'abonnement manuellement à partir des templates disponibles
    try {
      final template = _completeState.popularTemplates
          .firstWhere(
            (t) => t.id == event.templateId,
        orElse: () {
          print("DEBUG: Template non trouvé: ${event.templateId}");
          throw Exception('Template non trouvé: ${event.templateId}');
        },
      );
      print("DEBUG: Template trouvé: ${template.name}");

      // Créer l'abonnement détecté à partir du template
      final detectedSubscription = _createDetectedSubscriptionFromTemplate(template);
      print("DEBUG: Abonnement détecté créé: ${detectedSubscription.name}");

      emit(TemplateCreationSuccess(detectedSubscription: detectedSubscription));
      print("DEBUG: État TemplateCreationSuccess émis");
    } catch (e) {
      print("DEBUG: Erreur lors de la création depuis le template: $e");
      emit(SubscriptionDetectionError(
        failure: NotFoundFailure('Erreur lors de la création depuis le template: $e'),
      ));
    }
  }

  Future<void> _onAddDetectedSubscription(
      AddDetectedSubscriptionEvent event,
      Emitter<SubscriptionDetectionState> emit,
      ) async {
    print("DEBUG: Traitement de AddDetectedSubscriptionEvent");
    print("DEBUG: Subscription ID: ${event.subscriptionId}");

    emit(const SubscriptionDetectionLoading(message: 'Ajout de l\'abonnement...'));
    print("DEBUG: État SubscriptionDetectionLoading émis");

    // Trouver l'abonnement détecté par son ID (ici on utilise le nom comme ID)
    final detectedSubscription = _findDetectedSubscriptionById(event.subscriptionId);

    if (detectedSubscription == null) {
      print("DEBUG: Abonnement détecté non trouvé: ${event.subscriptionId}");
      emit(SubscriptionDetectionError(
        failure: const NotFoundFailure('Abonnement détecté non trouvé'),
      ));
      return;
    }

    print("DEBUG: Abonnement détecté trouvé: ${detectedSubscription.name}");

    // Convertir l'abonnement détecté en modèle d'abonnement pour l'ajouter
    final subscription = _convertToSubscriptionModel(detectedSubscription);
    print("DEBUG: Conversion en modèle d'abonnement réussie");

    // Ajouter l'abonnement avec le usecase
    final result = await addSubscriptionUseCase(
      AddSubscriptionParams(subscription: subscription),
    );
    print("DEBUG: Résultat du cas d'utilisation obtenu");

    result.fold(
          (failure) {
        print("DEBUG: ÉCHEC de l'ajout d'abonnement: ${failure.message}");
        emit(SubscriptionDetectionError(failure: failure));
      },
          (_) {
        print("DEBUG: SUCCÈS - Abonnement ajouté");
        // Mettre à jour la liste des IDs d'abonnements ajoutés
        _completeState = _completeState.copyWith(
          addedSubscriptionIds: [..._completeState.addedSubscriptionIds, event.subscriptionId],
        );

        // Émettre les deux états
        emit(SubscriptionAddedState(subscriptionId: event.subscriptionId));
        print("DEBUG: État SubscriptionAddedState émis");
        emit(_completeState);
        print("DEBUG: État complet émis");
      },
    );
  }

  Future<void> _onIgnoreDetectedSubscription(
      IgnoreDetectedSubscriptionEvent event,
      Emitter<SubscriptionDetectionState> emit,
      ) async {
    print("DEBUG: Traitement de IgnoreDetectedSubscriptionEvent");
    print("DEBUG: Subscription ID: ${event.subscriptionId}");

    // Mise à jour de la liste des IDs d'abonnements ignorés
    _completeState = _completeState.copyWith(
      ignoredSubscriptionIds: [..._completeState.ignoredSubscriptionIds, event.subscriptionId],
    );
    print("DEBUG: Abonnement marqué comme ignoré");

    // Émettre l'état complet mis à jour
    emit(_completeState);
    print("DEBUG: État complet émis");
  }

  Future<void> _onClearDetections(
      ClearDetectionsEvent event,
      Emitter<SubscriptionDetectionState> emit,
      ) async {
    print("DEBUG: Traitement de ClearDetectionsEvent");

    // Réinitialiser l'état complet
    _completeState = const SubscriptionDetectionCompleteState();
    print("DEBUG: État complet réinitialisé");

    // Émettre l'état initial
    emit(SubscriptionDetectionInitial());
    print("DEBUG: État SubscriptionDetectionInitial émis");
  }

  // Méthode utilitaire pour convertir un template en abonnement détecté
  DetectedSubscription _createDetectedSubscriptionFromTemplate(
      final template,
      ) {
    print("DEBUG: Création d'un abonnement détecté à partir du template: ${template.name}");
    return DetectedSubscription(
      name: template.name,
      suggestedAmount: template.typicalPrice,
      suggestedCategory: template.category,
      suggestedPeriodicity: template.typicalPeriodicity,
      logoUrl: template.logoUrl,
      suggestedDescription: template.description,
      // Suggérer la prochaine date de paiement (1 mois à partir de maintenant par défaut)
      suggestedNextPaymentDate: DateTime.now().add(const Duration(days: 30)),
      source: DetectionSource.template,
      confidenceScore: 0.9, // Score élevé car issu d'un modèle prédéfini
      metadata: {
        'templateId': template.id,
        'website': template.website,
      },
    );
  }

  // Méthode pour trouver un abonnement détecté par son ID (nom)
  DetectedSubscription? _findDetectedSubscriptionById(String id) {
    print("DEBUG: Recherche d'un abonnement détecté avec ID: $id");

    // Rechercher dans les détections d'emails
    for (var subscription in _completeState.emailDetections) {
      if (subscription.name == id) {
        print("DEBUG: Trouvé dans les détections d'emails");
        return subscription;
      }
    }

    // Rechercher dans les détections CSV
    for (var subscription in _completeState.csvDetections) {
      if (subscription.name == id) {
        print("DEBUG: Trouvé dans les détections CSV");
        return subscription;
      }
    }

    print("DEBUG: Abonnement non trouvé");
    return null;
  }

  // Méthode pour convertir un abonnement détecté en modèle d'abonnement
  SubscriptionModel _convertToSubscriptionModel(DetectedSubscription detected) {
    print("DEBUG: Conversion de l'abonnement détecté en modèle: ${detected.name}");
    return SubscriptionModel(
      id: const Uuid().v4(),
      name: detected.name,
      amount: detected.suggestedAmount ?? 0.0,
      periodicity: detected.suggestedPeriodicity ?? SubscriptionPeriodicity.monthly,
      nextPaymentDate: detected.suggestedNextPaymentDate ?? DateTime.now().add(const Duration(days: 30)),
      category: detected.suggestedCategory ?? SubscriptionCategory.other,
      description: detected.suggestedDescription,
      logoUrl: detected.logoUrl,
      status: SubscriptionStatus.active,
      startDate: DateTime.now(),
      hasReminder: true,
      reminderDays: 3,
    );
  }
}