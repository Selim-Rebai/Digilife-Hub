// lib/features/subscription_detection/presentation/widgets/template_suggestion_widget.dart

import 'package:flutter/material.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/subscription_template.dart';

import '../../../../domain/entities/subscription_enums.dart';

class TemplateSuggestionWidget extends StatefulWidget {
  final List<SubscriptionTemplate> templates;
  final bool isLoading;
  final Function(String) onSearch;
  final Function(String) onSelectTemplate;

  const TemplateSuggestionWidget({
    super.key,
    required this.templates,
    required this.isLoading,
    required this.onSearch,
    required this.onSelectTemplate,
  });

  @override
  State<TemplateSuggestionWidget> createState() => _TemplateSuggestionWidgetState();
}

class _TemplateSuggestionWidgetState extends State<TemplateSuggestionWidget> {
  final TextEditingController _searchController = TextEditingController();
  bool _isSearchFocused = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // En-tête explicatif
          const Text(
            'Catalogue d\'abonnements',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Parcourez notre catalogue pour trouver rapidement vos abonnements ou utilisez la recherche.',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 24),

          // Champ de recherche
          Focus(
            onFocusChange: (hasFocus) {
              setState(() {
                _isSearchFocused = hasFocus;
              });
            },
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Rechercher un service...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _isSearchFocused || _searchController.text.isNotEmpty
                    ? IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    _searchController.clear();
                    widget.onSearch('');
                    FocusScope.of(context).unfocus();
                  },
                )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
              ),
              onChanged: widget.onSearch,
              textInputAction: TextInputAction.search,
              onSubmitted: widget.onSearch,
            ),
          ),
          const SizedBox(height: 16),

          // Indicateur de chargement ou grille d'abonnements
          if (widget.isLoading)
            const Expanded(
              child: Center(
                child: CircularProgressIndicator(),
              ),
            )
          else if (widget.templates.isEmpty)
            const Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.search_off,
                      size: 64,
                      color: Colors.grey,
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Aucun service trouvé',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Essayez une autre recherche.',
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            )
          else
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 1.0,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: widget.templates.length,
                itemBuilder: (context, index) {
                  final template = widget.templates[index];
                  return _buildTemplateCard(context, template);
                },
              ),
            ),
        ],
      ),
    );
  }

  // Carte pour un modèle d'abonnement
  Widget _buildTemplateCard(BuildContext context, SubscriptionTemplate template) {
    return InkWell(
      onTap: () => widget.onSelectTemplate(template.id),
      borderRadius: BorderRadius.circular(12),
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Logo ou icône par défaut
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(32),
                ),
                child: Center(
                  child: template.logoUrl != null
                      ? Image.asset(template.logoUrl!, width: 48, height: 48)
                      : Icon(
                    _getCategoryIcon(template.category),
                    size: 32,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // Nom du service
              Text(
                template.name,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),

              // Prix typique s'il est disponible
              if (template.typicalPrice != null)
                Text(
                  '${template.typicalPrice!.toStringAsFixed(2)} €/${_getPeriodicityAbbreviation(template.typicalPeriodicity)}',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // Obtenir l'icône correspondant à la catégorie
  IconData _getCategoryIcon(SubscriptionCategory category) {
    switch (category) {
      case SubscriptionCategory.streaming:
        return Icons.play_circle_outline;
      case SubscriptionCategory.software:
        return Icons.laptop_mac;
      case SubscriptionCategory.gaming:
        return Icons.sports_esports;
      case SubscriptionCategory.news:
        return Icons.article;
      case SubscriptionCategory.utility:
        return Icons.build;
      case SubscriptionCategory.health:
        return Icons.favorite;
      case SubscriptionCategory.finance:
        return Icons.account_balance;
      case SubscriptionCategory.education:
        return Icons.school;
      case SubscriptionCategory.shopping:
        return Icons.shopping_bag;
      case SubscriptionCategory.other:
        return Icons.category;
    }
  }

  // Obtenir l'abréviation de la périodicité
  String _getPeriodicityAbbreviation(SubscriptionPeriodicity periodicity) {
    switch (periodicity) {
      case SubscriptionPeriodicity.daily:
        return 'jour';
      case SubscriptionPeriodicity.weekly:
        return 'sem';
      case SubscriptionPeriodicity.monthly:
        return 'mois';
      case SubscriptionPeriodicity.quarterly:
        return 'trim';
      case SubscriptionPeriodicity.biannual:
        return 'sem';
      case SubscriptionPeriodicity.annual:
        return 'an';
      case SubscriptionPeriodicity.custom:
        return '';
    }
  }
}