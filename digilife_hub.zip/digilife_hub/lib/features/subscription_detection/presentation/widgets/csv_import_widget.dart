// lib/features/subscription_detection/presentation/widgets/csv_import_widget.dart

import 'package:flutter/material.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/widgets/detected_subscription_card.dart';

class CsvImportWidget extends StatelessWidget {
  final VoidCallback onImportCsv;
  final List<DetectedSubscription> detectedSubscriptions;
  final bool isLoading;
  final Function(String) onAddSubscription;
  final Function(String) onIgnoreSubscription;

  const CsvImportWidget({
    super.key,
    required this.onImportCsv,
    required this.detectedSubscriptions,
    required this.isLoading,
    required this.onAddSubscription,
    required this.onIgnoreSubscription,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // En-tête explicatif
          const Text(
            'Importation de relevé bancaire',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Importez un relevé bancaire au format CSV pour détecter automatiquement vos abonnements récurrents. Cette opération est sécurisée et effectuée localement sur votre appareil.',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 24),

          // Bouton pour importer un fichier CSV
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: isLoading ? null : onImportCsv,
              icon: const Icon(Icons.upload_file),
              label: Text(isLoading ? 'Analyse en cours...' : 'Importer un relevé bancaire'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Center(
            child: Text(
              'Formats supportés: CSV',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey,
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Instructions pour l'export de relevé bancaire
          const ExpansionTile(
            title: Text('Comment exporter un relevé bancaire ?'),
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '1. Connectez-vous à votre espace bancaire en ligne',
                      style: TextStyle(fontSize: 14),
                    ),
                    SizedBox(height: 8),
                    Text(
                      '2. Accédez à la section "Relevés" ou "Opérations"',
                      style: TextStyle(fontSize: 14),
                    ),
                    SizedBox(height: 8),
                    Text(
                      '3. Sélectionnez la période souhaitée (3-6 mois idéalement)',
                      style: TextStyle(fontSize: 14),
                    ),
                    SizedBox(height: 8),
                    Text(
                      '4. Cliquez sur le bouton d\'export au format CSV',
                      style: TextStyle(fontSize: 14),
                    ),
                    SizedBox(height: 8),
                    Text(
                      '5. Importez le fichier téléchargé via le bouton ci-dessus',
                      style: TextStyle(fontSize: 14),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Indicateur de chargement ou liste des abonnements détectés
          if (isLoading)
            const Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 16),
                    Text('Analyse du relevé bancaire en cours...'),
                  ],
                ),
              ),
            )
          else if (detectedSubscriptions.isEmpty)
            Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.upload_file,
                      size: 64,
                      color: Colors.grey,
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Aucun abonnement détecté',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Importez un relevé bancaire pour commencer.',
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            )
          else
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${detectedSubscriptions.length} abonnement${detectedSubscriptions.length > 1 ? 's' : ''} détecté${detectedSubscriptions.length > 1 ? 's' : ''}',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: ListView.builder(
                      itemCount: detectedSubscriptions.length,
                      itemBuilder: (context, index) {
                        final subscription = detectedSubscriptions[index];
                        return DetectedSubscriptionCard(
                          subscription: subscription,
                          onAdd: () => onAddSubscription(subscription.name),
                          onIgnore: () => onIgnoreSubscription(subscription.name),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}