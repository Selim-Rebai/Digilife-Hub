// lib/features/subscription_detection/presentation/widgets/detection_tooltip.dart

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Widget de tooltip pour expliquer la fonctionnalité de détection automatique
/// S'affiche uniquement lors de la première utilisation de la fonctionnalité
class DetectionTooltip extends StatefulWidget {
  final Widget child;
  final String tooltipKey;
  final String title;
  final String message;
  final IconData icon;

  const DetectionTooltip({
    super.key,
    required this.child,
    required this.tooltipKey,
    required this.title,
    required this.message,
    this.icon = Icons.lightbulb_outline,
  });

  @override
  State<DetectionTooltip> createState() => _DetectionTooltipState();
}

class _DetectionTooltipState extends State<DetectionTooltip> {
  bool _showTooltip = false;
  OverlayEntry? _overlayEntry;
  final GlobalKey _widgetKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    // Vérifier si c'est la première fois que l'utilisateur voit cette fonctionnalité
    _checkFirstTime();
  }

  Future<void> _checkFirstTime() async {
    final prefs = await SharedPreferences.getInstance();
    final bool isFirstTime = !(prefs.getBool(widget.tooltipKey) ?? false);

    if (isFirstTime && mounted) {
      setState(() {
        _showTooltip = true;
      });

      // Attendre que le widget soit rendu avant d'afficher le tooltip
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showOverlay();

        // Marquer comme vu après 5 secondes et fermer le tooltip
        Future.delayed(const Duration(seconds: 5), () {
          prefs.setBool(widget.tooltipKey, true);
          _hideOverlay();
        });
      });
    }
  }

  void _showOverlay() {
    if (_overlayEntry != null) return;

    final RenderBox renderBox = _widgetKey.currentContext!.findRenderObject() as RenderBox;
    final Size size = renderBox.size;
    final Offset position = renderBox.localToGlobal(Offset.zero);

    _overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        top: position.dy + size.height + 8,
        left: position.dx - 100 + (size.width / 2),
        child: Material(
          elevation: 4,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 250,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Icon(
                      widget.icon,
                      color: Theme.of(context).colorScheme.primary,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        widget.title,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: _hideOverlay,
                      child: const Icon(
                        Icons.close,
                        size: 16,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  widget.message,
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    Overlay.of(context).insert(_overlayEntry!);
  }

  void _hideOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
    setState(() {
      _showTooltip = false;
    });
  }

  @override
  void dispose() {
    _hideOverlay();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      key: _widgetKey,
      child: widget.child,
    );
  }
}

// Extension pour faciliter l'utilisation
extension TooltipContextExtension on BuildContext {
  bool shouldShowDetectionTooltip(String key) {
    // Cette méthode pourrait être étendue pour vérifier les préférences utilisateur
    // Pour l'instant, elle retourne true pour simuler le premier lancement
    return true;
  }
}