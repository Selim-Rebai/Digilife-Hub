// lib/features/subscription_detection/presentation/widgets/detection_progress_indicator.dart

import 'package:flutter/material.dart';

/// Widget animé pour indiquer la progression de la détection d'abonnements
class DetectionProgressIndicator extends StatefulWidget {
  final String message;
  final double progress;
  final bool isComplete;
  final VoidCallback? onComplete;

  const DetectionProgressIndicator({
    super.key,
    required this.message,
    this.progress = 0.0,
    this.isComplete = false,
    this.onComplete,
  });

  @override
  State<DetectionProgressIndicator> createState() => _DetectionProgressIndicatorState();
}

class _DetectionProgressIndicatorState extends State<DetectionProgressIndicator>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _opacityAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _opacityAnimation = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    _scaleAnimation = Tween<double>(begin: 0.95, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOutBack,
      ),
    );

    // Démarrer l'animation
    if (widget.isComplete) {
      _animationController.value = 1.0;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (widget.onComplete != null) {
          widget.onComplete!();
        }
      });
    } else {
      _animationController.repeat(reverse: true);
    }
  }

  @override
  void didUpdateWidget(DetectionProgressIndicator oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.isComplete && !oldWidget.isComplete) {
      _animationController.stop();
      _animationController.forward().then((_) {
        if (widget.onComplete != null) {
          widget.onComplete!();
        }
      });
    } else if (!widget.isComplete && oldWidget.isComplete) {
      _animationController.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animationController,
      builder: (context, child) {
        return Opacity(
          opacity: _opacityAnimation.value,
          child: Transform.scale(
            scale: _scaleAnimation.value,
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Icône animée
                    widget.isComplete
                        ? const Icon(
                      Icons.check_circle,
                      color: Colors.green,
                      size: 48,
                    )
                        : SizedBox(
                      width: 48,
                      height: 48,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Cercle de progression
                          SizedBox(
                            width: 48,
                            height: 48,
                            child: CircularProgressIndicator(
                              value: widget.progress > 0 ? widget.progress : null,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                Theme.of(context).colorScheme.primary,
                              ),
                              strokeWidth: 4,
                            ),
                          ),
                          // Icône au centre
                          Icon(
                            Icons.auto_awesome,
                            color: Theme.of(context).colorScheme.primary,
                            size: 24,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Message
                    Text(
                      widget.message,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    // Si en cours, afficher un indicateur de progression textuel
                    if (!widget.isComplete) ...[
                      const SizedBox(height: 12),
                      if (widget.progress > 0) ...[
                        // Barre de progression avec pourcentage
                        LinearProgressIndicator(
                          value: widget.progress,
                          minHeight: 8,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '${(widget.progress * 100).toInt()}%',
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ] else ...[
                        // Animation de recherche
                        _buildScanningAnimation(context),
                      ],
                    ],
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // Animation de balayage pour simuler une recherche
  Widget _buildScanningAnimation(BuildContext context) {
    return SizedBox(
      height: 40,
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.grey[200],
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          AnimatedBuilder(
            animation: _animationController,
            builder: (context, child) {
              return Positioned(
                left: MediaQuery.of(context).size.width * 0.5 * _animationController.value - 100,
                top: 0,
                bottom: 0,
                width: 100,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.transparent,
                        Theme.of(context).colorScheme.primary.withOpacity(0.3),
                        Colors.transparent,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

// Widget pour afficher les étapes de détection
class DetectionStepIndicator extends StatelessWidget {
  final List<String> steps;
  final int currentStep;

  const DetectionStepIndicator({
    super.key,
    required this.steps,
    required this.currentStep,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        steps.length,
            (index) => _buildStep(context, index),
      ),
    );
  }

  Widget _buildStep(BuildContext context, int index) {
    final bool isCompleted = index < currentStep;
    final bool isCurrent = index == currentStep;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          // Indicateur d'état (cercle)
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: isCompleted
                  ? Colors.green
                  : isCurrent
                  ? Theme.of(context).colorScheme.primary
                  : Colors.grey[300],
              shape: BoxShape.circle,
            ),
            child: Center(
              child: isCompleted
                  ? const Icon(
                Icons.check,
                color: Colors.white,
                size: 16,
              )
                  : isCurrent
                  ? const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2,
                ),
              )
                  : null,
            ),
          ),
          const SizedBox(width: 12),

          // Texte de l'étape
          Expanded(
            child: Text(
              steps[index],
              style: TextStyle(
                color: isCompleted
                    ? Colors.green
                    : isCurrent
                    ? Theme.of(context).colorScheme.primary
                    : Colors.grey,
                fontWeight: isCompleted || isCurrent
                    ? FontWeight.bold
                    : FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}