// lib/features/subscription_detection/presentation/widgets/detected_subscription_card.dart

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';

class DetectedSubscriptionCard extends StatelessWidget {
  final DetectedSubscription subscription;
  final VoidCallback onAdd;
  final VoidCallback onIgnore;

  const DetectedSubscriptionCard({
    super.key,
    required this.subscription,
    required this.onAdd,
    required this.onIgnore,
  });

  @override
  Widget build(BuildContext context) {
    final currencyFormatter = NumberFormat.currency(locale: 'fr_FR', symbol: '€');

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // En-tête avec nom et catégorie
            Row(
              children: [
                // Icône de catégorie
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: _getCategoryColor(subscription.suggestedCategory).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    _getCategoryIcon(subscription.suggestedCategory),
                    color: _getCategoryColor(subscription.suggestedCategory),
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),

                // Nom du service
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        subscription.name,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      if (subscription.suggestedCategory != null)
                        Text(
                          _getCategoryName(subscription.suggestedCategory!),
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[600],
                          ),
                        ),
                    ],
                  ),
                ),

                // Badge de source de détection
                _buildSourceBadge(context, subscription.source),
              ],
            ),
            const SizedBox(height: 16),

            // Détails de l'abonnement
            Row(
              children: [
                // Montant
                if (subscription.suggestedAmount != null)
                  Expanded(
                    child: _buildInfoItem(
                      context,
                      'Montant',
                      currencyFormatter.format(subscription.suggestedAmount),
                      Icons.attach_money,
                    ),
                  ),

                // Périodicité
                if (subscription.suggestedPeriodicity != null)
                  Expanded(
                    child: _buildInfoItem(
                      context,
                      'Périodicité',
                      _getPeriodicityName(subscription.suggestedPeriodicity!),
                      Icons.calendar_today,
                    ),
                  ),

                // Confiance
                Expanded(
                  child: _buildInfoItem(
                    context,
                    'Confiance',
                    _getConfidenceLabel(subscription.confidenceScore),
                    Icons.verified,
                    _getConfidenceColor(subscription.confidenceScore),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Actions
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                // Bouton ignorer
                OutlinedButton(
                  onPressed: onIgnore,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.grey[600],
                    side: BorderSide(color: Colors.grey[300]!),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text('Ignorer'),
                ),
                const SizedBox(width: 12),

                // Bouton ajouter
                ElevatedButton(
                  onPressed: onAdd,
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: Theme.of(context).primaryColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text('Ajouter'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Widget pour afficher un élément d'information
  Widget _buildInfoItem(
      BuildContext context,
      String label,
      String value,
      IconData icon, [
        Color? iconColor,
      ]) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
        ),
        const SizedBox(height: 4),
        Row(
          children: [
            Icon(
              icon,
              size: 16,
              color: iconColor ?? Theme.of(context).primaryColor,
            ),
            const SizedBox(width: 4),
            Flexible(
              child: Text(
                value,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ],
    );
  }

  // Widget pour afficher un badge de source
  Widget _buildSourceBadge(BuildContext context, DetectionSource source) {
    Color color;
    String label;

    switch (source) {
      case DetectionSource.email:
        color = Colors.blue;
        label = 'Email';
        break;
      case DetectionSource.csvImport:
        color = Colors.green;
        label = 'Relevé';
        break;
      case DetectionSource.template:
        color = Colors.purple;
        label = 'Catalogue';
        break;
      case DetectionSource.manualEntry:
        color = Colors.grey;
        label = 'Manuel';
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.bold,
          color: color,
        ),
      ),
    );
  }

  // Obtenir la couleur correspondant à la catégorie
  Color _getCategoryColor(SubscriptionCategory? category) {
    if (category == null) return Colors.grey;

    switch (category) {
      case SubscriptionCategory.streaming:
        return Colors.red;
      case SubscriptionCategory.software:
        return Colors.blue;
      case SubscriptionCategory.gaming:
        return Colors.purple;
      case SubscriptionCategory.news:
        return Colors.orange;
      case SubscriptionCategory.utility:
        return Colors.teal;
      case SubscriptionCategory.health:
        return Colors.pink;
      case SubscriptionCategory.finance:
        return Colors.indigo;
      case SubscriptionCategory.education:
        return Colors.green;
      case SubscriptionCategory.shopping:
        return Colors.amber;
      case SubscriptionCategory.other:
        return Colors.grey;
    }
  }

  // Obtenir l'icône correspondant à la catégorie
  IconData _getCategoryIcon(SubscriptionCategory? category) {
    if (category == null) return Icons.category;

    switch (category) {
      case SubscriptionCategory.streaming:
        return Icons.play_circle_outline;
      case SubscriptionCategory.software:
        return Icons.laptop_mac;
      case SubscriptionCategory.gaming:
        return Icons.sports_esports;
      case SubscriptionCategory.news:
        return Icons.article;
      case SubscriptionCategory.utility:
        return Icons.build;
      case SubscriptionCategory.health:
        return Icons.favorite;
      case SubscriptionCategory.finance:
        return Icons.account_balance;
      case SubscriptionCategory.education:
        return Icons.school;
      case SubscriptionCategory.shopping:
        return Icons.shopping_bag;
      case SubscriptionCategory.other:
        return Icons.category;
    }
  }

  // Obtenir le nom de la catégorie
  String _getCategoryName(SubscriptionCategory category) {
    switch (category) {
      case SubscriptionCategory.streaming:
        return 'Streaming';
      case SubscriptionCategory.software:
        return 'Logiciels';
      case SubscriptionCategory.gaming:
        return 'Jeux';
      case SubscriptionCategory.news:
        return 'Actualités';
      case SubscriptionCategory.utility:
        return 'Services';
      case SubscriptionCategory.health:
        return 'Santé';
      case SubscriptionCategory.finance:
        return 'Finance';
      case SubscriptionCategory.education:
        return 'Éducation';
      case SubscriptionCategory.shopping:
        return 'Shopping';
      case SubscriptionCategory.other:
        return 'Autre';
    }
  }

  // Obtenir le nom de la périodicité
  String _getPeriodicityName(SubscriptionPeriodicity periodicity) {
    switch (periodicity) {
      case SubscriptionPeriodicity.daily:
        return 'Quotidien';
      case SubscriptionPeriodicity.weekly:
        return 'Hebdo';
      case SubscriptionPeriodicity.monthly:
        return 'Mensuel';
      case SubscriptionPeriodicity.quarterly:
        return 'Trim.';
      case SubscriptionPeriodicity.biannual:
        return 'Sem.';
      case SubscriptionPeriodicity.annual:
        return 'Annuel';
      case SubscriptionPeriodicity.custom:
        return 'Personnalisé';
    }
  }

  // Obtenir le label de confiance
  String _getConfidenceLabel(double confidence) {
    if (confidence >= 0.8) return 'Élevée';
    if (confidence >= 0.5) return 'Moyenne';
    return 'Faible';
  }

  // Obtenir la couleur de confiance
  Color _getConfidenceColor(double confidence) {
    if (confidence >= 0.8) return Colors.green;
    if (confidence >= 0.5) return Colors.orange;
    return Colors.red;
  }
}