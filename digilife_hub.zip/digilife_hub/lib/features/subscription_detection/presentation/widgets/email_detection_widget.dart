// lib/features/subscription_detection/presentation/widgets/email_detection_widget.dart

import 'package:flutter/material.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/widgets/detected_subscription_card.dart';

class EmailDetectionWidget extends StatelessWidget {
  final VoidCallback onDetectFromEmails;
  final List<DetectedSubscription> detectedSubscriptions;
  final bool isLoading;
  final Function(String) onAddSubscription;
  final Function(String) onIgnoreSubscription;

  const EmailDetectionWidget({
    super.key,
    required this.onDetectFromEmails,
    required this.detectedSubscriptions,
    required this.isLoading,
    required this.onAddSubscription,
    required this.onIgnoreSubscription,
  });

  @override
  Widget build(BuildContext context) {
    print("DEBUG: EmailDetectionWidget - build - isLoading: $isLoading, subscriptions: ${detectedSubscriptions.length}");

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // En-tête explicatif
          const Text(
            'Détection par emails',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'DigiLife Hub analysera vos emails pour détecter automatiquement vos abonnements actifs. Cette opération est sécurisée et vos données restent privées.',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 24),

          // Bouton pour lancer la détection
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: isLoading ? null : () {
                print("DEBUG: EmailDetectionWidget - Bouton de détection cliqué");
                onDetectFromEmails();
              },
              icon: const Icon(Icons.email),
              label: Text(isLoading ? 'Analyse en cours...' : 'Analyser mes emails'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Center(
            child: Text(
              'Connexion Gmail requise',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey,
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Indicateur de chargement ou liste des abonnements détectés
          Expanded(
            child: isLoading
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 16),
                  const Text('Recherche d\'abonnements dans vos emails...'),
                ],
              ),
            )
                : detectedSubscriptions.isEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.search_off,
                    size: 64,
                    color: Colors.grey,
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Aucun abonnement détecté',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Lancez l\'analyse ou essayez une autre méthode.',
                    style: TextStyle(
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            )
                : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${detectedSubscriptions.length} abonnement${detectedSubscriptions.length > 1 ? 's' : ''} détecté${detectedSubscriptions.length > 1 ? 's' : ''}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.builder(
                    itemCount: detectedSubscriptions.length,
                    itemBuilder: (context, index) {
                      final subscription = detectedSubscriptions[index];
                      print("DEBUG: EmailDetectionWidget - Construction de la carte pour ${subscription.name}");
                      return DetectedSubscriptionCard(
                        subscription: subscription,
                        onAdd: () {
                          print("DEBUG: EmailDetectionWidget - Ajout de ${subscription.name}");
                          onAddSubscription(subscription.name);
                        },
                        onIgnore: () {
                          print("DEBUG: EmailDetectionWidget - Ignorer ${subscription.name}");
                          onIgnoreSubscription(subscription.name);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}