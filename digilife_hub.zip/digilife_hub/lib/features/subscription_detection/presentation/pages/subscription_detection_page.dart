// lib/features/subscription_detection/presentation/pages/subscription_detection_page.dart

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:file_picker/file_picker.dart';
import 'package:digilife_hub/core/constants/app_theme.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';
import 'package:digilife_hub/features/subscription_detection/domain/repositories/subscription_detection_repository.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/bloc/subscription_detection_bloc.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/bloc/subscription_detection_event.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/bloc/subscription_detection_state.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/widgets/csv_import_widget.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/widgets/email_detection_widget.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/widgets/template_suggestion_widget.dart';

import '../../domain/entities/subscription_template.dart';

class SubscriptionDetectionPage extends StatefulWidget {
  const SubscriptionDetectionPage({super.key});

  @override
  State<SubscriptionDetectionPage> createState() => _SubscriptionDetectionPageState();
}

class _SubscriptionDetectionPageState extends State<SubscriptionDetectionPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    print("DEBUG: SubscriptionDetectionPage - initState");
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _currentIndex = _tabController.index;
        print("DEBUG: SubscriptionDetectionPage - Tab changé vers index $_currentIndex");
      });
    });

    // Charger les templates populaires au démarrage
    WidgetsBinding.instance.addPostFrameCallback((_) {
      print("DEBUG: SubscriptionDetectionPage - Chargement des templates populaires");
      context.read<SubscriptionDetectionBloc>().add(const GetPopularTemplatesEvent());
    });
  }

  @override
  void dispose() {
    print("DEBUG: SubscriptionDetectionPage - dispose");
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print("DEBUG: SubscriptionDetectionPage - build");
    return Scaffold(
      appBar: AppBar(
        title: const Text('Détection d\'abonnements'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(
              icon: Icon(Icons.email_outlined),
              text: "Emails",
            ),
            Tab(
              icon: Icon(Icons.description_outlined),
              text: "Relevé bancaire",
            ),
            Tab(
              icon: Icon(Icons.search_outlined),
              text: "Catalogue",
            ),
          ],
        ),
      ),
      body: BlocConsumer<SubscriptionDetectionBloc, SubscriptionDetectionState>(
        listener: (context, state) {
          print("DEBUG: SubscriptionDetectionBloc - Nouvel état: ${state.runtimeType}");

          if (state is SubscriptionDetectionError) {
            print("DEBUG: ERREUR de détection: ${state.failure.message}");
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Erreur: ${state.failure.message}'),
                backgroundColor: Colors.red,
              ),
            );
          } else if (state is SubscriptionAddedState) {
            print("DEBUG: Abonnement ajouté avec succès: ${state.subscriptionId}");
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: Colors.green,
              ),
            );
          }
        },
        builder: (context, state) {
          print("DEBUG: Construction UI avec état: ${state.runtimeType}");
          return TabBarView(
            controller: _tabController,
            children: [
              // Onglet 1: Détection par email
              EmailDetectionWidget(
                onDetectFromEmails: _detectFromEmails,
                detectedSubscriptions: _getEmailDetections(state),
                isLoading: state is SubscriptionDetectionLoading,
                onAddSubscription: _addDetectedSubscription,
                onIgnoreSubscription: _ignoreDetectedSubscription,
              ),

              // Onglet 2: Importation de CSV
              CsvImportWidget(
                onImportCsv: _importCsv,
                detectedSubscriptions: _getCsvDetections(state),
                isLoading: state is SubscriptionDetectionLoading,
                onAddSubscription: _addDetectedSubscription,
                onIgnoreSubscription: _ignoreDetectedSubscription,
              ),

              // Onglet 3: Catalogue de templates
              TemplateSuggestionWidget(
                templates: _getPopularTemplates(state),
                isLoading: state is SubscriptionDetectionLoading,
                onSearch: _searchTemplates,
                onSelectTemplate: _createFromTemplate,
              ),
            ],
          );
        },
      ),
    );
  }

  // Méthode pour détecter les abonnements depuis les emails
  void _detectFromEmails() {
    print("DEBUG: _detectFromEmails appelé");
    // Dans une application réelle, vous auriez une authentification Gmail OAuth ici
    // Pour cet exemple, nous utiliserons des valeurs factices
    context.read<SubscriptionDetectionBloc>().add(
      const DetectFromEmailsEvent(
        userEmail: 'utilisateur@gmail.com',
        accessToken: 'token_factice',
        maxResults: 100,
      ),
    );
    print("DEBUG: DetectFromEmailsEvent envoyé au bloc");
  }

  // Méthode pour importer un fichier CSV
  Future<void> _importCsv() async {
    print("DEBUG: _importCsv appelé");
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv'],
      );

      print("DEBUG: Résultat sélection fichier: ${result != null ? 'Fichier sélectionné' : 'Aucun fichier'}");

      if (result != null && result.files.single.path != null) {
        final file = File(result.files.single.path!);
        print("DEBUG: Chemin du fichier: ${file.path}");

        // Demander le format du CSV à l'utilisateur
        if (!mounted) return;
        final format = await _showCsvFormatDialog(context);

        print("DEBUG: Format CSV sélectionné: $format");

        if (format != null) {
          print("DEBUG: Envoi de DetectFromCsvEvent au bloc");
          context.read<SubscriptionDetectionBloc>().add(
            DetectFromCsvEvent(
              csvFile: file,
              csvFormat: format,
            ),
          );
        } else {
          print("DEBUG: Aucun format CSV sélectionné");
        }
      }
    } catch (e) {
      print("DEBUG: ERREUR dans _importCsv: $e");
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erreur lors de la sélection du fichier: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // Méthode pour rechercher des templates
  void _searchTemplates(String query) {
    print("DEBUG: _searchTemplates appelé avec query: $query");
    if (query.isNotEmpty) {
      context.read<SubscriptionDetectionBloc>().add(
        SearchSubscriptionTemplatesEvent(query: query),
      );
    } else {
      // Si la recherche est vide, afficher les templates populaires
      context.read<SubscriptionDetectionBloc>().add(
        const GetPopularTemplatesEvent(),
      );
    }
  }

  // Méthode pour créer un abonnement à partir d'un template
  void _createFromTemplate(String templateId) {
    print("DEBUG: _createFromTemplate appelé avec templateId: $templateId");
    context.read<SubscriptionDetectionBloc>().add(
      CreateFromTemplateEvent(templateId: templateId),
    );
  }

  // Méthode pour ajouter un abonnement détecté
  void _addDetectedSubscription(String subscriptionId) {
    print("DEBUG: _addDetectedSubscription appelé avec subscriptionId: $subscriptionId");
    context.read<SubscriptionDetectionBloc>().add(
      AddDetectedSubscriptionEvent(subscriptionId: subscriptionId),
    );
  }

  // Méthode pour ignorer un abonnement détecté
  void _ignoreDetectedSubscription(String subscriptionId) {
    print("DEBUG: _ignoreDetectedSubscription appelé avec subscriptionId: $subscriptionId");
    context.read<SubscriptionDetectionBloc>().add(
      IgnoreDetectedSubscriptionEvent(subscriptionId: subscriptionId),
    );
  }

  // Méthode pour afficher la boîte de dialogue de sélection du format CSV
  Future<CsvFormat?> _showCsvFormatDialog(BuildContext context) async {
    print("DEBUG: _showCsvFormatDialog appelé");
    return showDialog<CsvFormat>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sélectionnez le format de votre relevé bancaire'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(
            shrinkWrap: true,
            children: [
              _buildCsvFormatItem(context, 'Format générique', CsvFormat.genericBank),
              _buildCsvFormatItem(context, 'Crédit Agricole', CsvFormat.creditAgricole),
              _buildCsvFormatItem(context, 'BNP Paribas', CsvFormat.bnpParibas),
              _buildCsvFormatItem(context, 'Société Générale', CsvFormat.societeGenerale),
              _buildCsvFormatItem(context, 'Boursorama', CsvFormat.boursorama),
              _buildCsvFormatItem(context, 'Format personnalisé', CsvFormat.custom),
            ],
          ),
        ),
      ),
    );
  }

  // Widget pour un élément de la liste des formats CSV
  Widget _buildCsvFormatItem(BuildContext context, String label, CsvFormat format) {
    return ListTile(
      title: Text(label),
      onTap: () {
        print("DEBUG: Format CSV sélectionné: $label");
        Navigator.of(context).pop(format);
      },
    );
  }

  // Méthodes pour extraire les données de l'état actuel
  List<DetectedSubscription> _getEmailDetections(SubscriptionDetectionState state) {
    if (state is SubscriptionDetectionCompleteState) {
      print("DEBUG: _getEmailDetections - ${state.emailDetections.length} abonnements disponibles");
      return state.emailDetections.where((s) =>
      !state.addedSubscriptionIds.contains(s.name) &&
          !state.ignoredSubscriptionIds.contains(s.name)
      ).toList();
    } else if (state is EmailDetectionSuccess) {
      print("DEBUG: _getEmailDetections - ${state.detectedSubscriptions.length} abonnements détectés");
      return state.detectedSubscriptions;
    }
    print("DEBUG: _getEmailDetections - aucun abonnement disponible");
    return [];
  }

  List<DetectedSubscription> _getCsvDetections(SubscriptionDetectionState state) {
    if (state is SubscriptionDetectionCompleteState) {
      print("DEBUG: _getCsvDetections - ${state.csvDetections.length} abonnements disponibles");
      return state.csvDetections.where((s) =>
      !state.addedSubscriptionIds.contains(s.name) &&
          !state.ignoredSubscriptionIds.contains(s.name)
      ).toList();
    } else if (state is CsvDetectionSuccess) {
      print("DEBUG: _getCsvDetections - ${state.detectedSubscriptions.length} abonnements détectés");
      return state.detectedSubscriptions;
    }
    print("DEBUG: _getCsvDetections - aucun abonnement disponible");
    return [];
  }

  List<SubscriptionTemplate> _getPopularTemplates(SubscriptionDetectionState state) {
    if (state is SubscriptionDetectionCompleteState) {
      print("DEBUG: _getPopularTemplates - ${state.popularTemplates.length} templates disponibles");
      return state.popularTemplates;
    } else if (state is TemplatesLoadedState) {
      print("DEBUG: _getPopularTemplates - ${state.templates.length} templates chargés");
      return state.templates;
    }
    print("DEBUG: _getPopularTemplates - aucun template disponible");
    return [];
  }
}