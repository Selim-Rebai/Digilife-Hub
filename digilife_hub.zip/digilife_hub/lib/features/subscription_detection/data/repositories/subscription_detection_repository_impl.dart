// lib/features/subscription_detection/data/repositories/subscription_detection_repository_impl.dart

import 'dart:io';
import 'package:dartz/dartz.dart';
import 'package:digilife_hub/core/errors/exceptions.dart' as core_exceptions ;
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/features/subscription_detection/data/datasources/csv_datasource.dart';
import 'package:digilife_hub/features/subscription_detection/data/datasources/email_datasource.dart';
import 'package:digilife_hub/features/subscription_detection/data/datasources/subscription_template_datasource.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/subscription_template.dart';
import 'package:digilife_hub/features/subscription_detection/domain/repositories/subscription_detection_repository.dart';

import '../../../../domain/entities/subscription_enums.dart';

class SubscriptionDetectionRepositoryImpl implements SubscriptionDetectionRepository {
  final EmailDataSource emailDataSource;
  final CsvDataSource csvDataSource;
  final SubscriptionTemplateDataSource templateDataSource;

  SubscriptionDetectionRepositoryImpl({
    required this.emailDataSource,
    required this.csvDataSource,
    required this.templateDataSource,
  });

  @override
  Future<Either<Failure, List<DetectedSubscription>>> detectFromEmails({
    required String userEmail,
    required String accessToken,
    DateTime? startDate,
    int maxResults = 100,
  }) async {
    try {
      final subscriptions = await emailDataSource.detectSubscriptions(
        userEmail: userEmail,
        accessToken: accessToken,
        startDate: startDate,
        maxResults: maxResults,
      );

      return Right(subscriptions);
    } on core_exceptions.ServerException catch (e) {
      return Left(ServerFailure(e.toString()));
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<DetectedSubscription>>> detectFromCsv({
    required File csvFile,
    required CsvFormat csvFormat,
    DateTime? startDate,
  }) async {
    try {
      final subscriptions = await csvDataSource.detectSubscriptions(
        csvFile: csvFile,
        csvFormat: csvFormat,
        startDate: startDate,
      );

      return Right(subscriptions);
    } on FormatException catch (e) {
      return Left(FormatFailure(e.toString()));
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<SubscriptionTemplate>>> getSubscriptionTemplates({
    String? searchQuery,
    int limit = 20,
  }) async {
    try {
      // Si une requête de recherche est fournie, effectuer une recherche
      if (searchQuery != null && searchQuery.isNotEmpty) {
        final templates = await templateDataSource.searchTemplates(
          searchQuery,
          limit: limit,
        );

        return Right(templates);
      }

      // Sinon, récupérer tous les templates (limités)
      final templates = await templateDataSource.getTemplates();

      return Right(templates.take(limit).toList());
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<SubscriptionTemplate>>> searchTemplates({
    required String query,
    int limit = 10,
  }) async {
    try {
      final templates = await templateDataSource.searchTemplates(
        query,
        limit: limit,
      );

      return Right(templates);
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, DetectedSubscription>> createFromTemplate({
    required String templateId,
  }) async {
    try {
      // Récupérer le template par son ID
      final template = await templateDataSource.getTemplateById(templateId);

      // Convertir le template en abonnement détecté
      final detectedSubscription = DetectedSubscription(
        name: template.name,
        suggestedAmount: template.typicalPrice,
        suggestedCategory: template.category,
        suggestedPeriodicity: template.typicalPeriodicity,
        logoUrl: template.logoUrl,
        suggestedDescription: template.description,
        suggestedNextPaymentDate: _calculateNextPaymentDate(template.typicalPeriodicity),
        source: DetectionSource.template,
        confidenceScore: 0.9, // Score élevé car issu d'un modèle prédéfini
        metadata: {
          'templateId': template.id,
          'website': template.website,
        },
      );

      return Right(detectedSubscription);
    } on NotFoundException catch (e) {
      return Left(NotFoundFailure(e.toString()));
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }

  /// Calcule la date du prochain paiement en fonction de la périodicité
  DateTime _calculateNextPaymentDate(SubscriptionPeriodicity periodicity) {
    final now = DateTime.now();

    switch (periodicity) {
      case SubscriptionPeriodicity.daily:
        return now.add(const Duration(days: 1));
      case SubscriptionPeriodicity.weekly:
        return now.add(const Duration(days: 7));
      case SubscriptionPeriodicity.monthly:
        return DateTime(now.year, now.month + 1, now.day);
      case SubscriptionPeriodicity.quarterly:
        return DateTime(now.year, now.month + 3, now.day);
      case SubscriptionPeriodicity.biannual:
        return DateTime(now.year, now.month + 6, now.day);
      case SubscriptionPeriodicity.annual:
        return DateTime(now.year + 1, now.month, now.day);
      default:
        return DateTime(now.year, now.month + 1, now.day); // Par défaut mensuel
    }
  }
}

/// Erreur spécifique pour les problèmes de format
class FormatFailure extends Failure {
  const FormatFailure(super.message);
}

/// Erreur spécifique pour les éléments non trouvés
class NotFoundFailure extends Failure {
  const NotFoundFailure(super.message);
}