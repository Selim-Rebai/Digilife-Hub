// lib/features/subscription_detection/data/datasources/csv_datasource.dart

import 'dart:io';
import 'dart:convert';
import 'package:digilife_hub/core/errors/exceptions.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:digilife_hub/features/subscription_detection/data/models/detected_subscription_model.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';
import 'package:digilife_hub/features/subscription_detection/domain/repositories/subscription_detection_repository.dart';
import 'package:csv/csv.dart';
import 'package:intl/intl.dart';
import 'dart:math' as math;

/// Source de données pour l'analyse des relevés bancaires en CSV
abstract class CsvDataSource {
  /// Analyse un fichier CSV de relevé bancaire pour détecter des abonnements
  Future<List<DetectedSubscriptionModel>> detectSubscriptions({
    required File csvFile,
    required CsvFormat csvFormat,
    DateTime? startDate,
  });
}

/// Implémentation de la source de données CSV pour les relevés bancaires
class CsvDataSourceImpl implements CsvDataSource {
  // Liste de mots-clés présents dans les descriptions de transactions d'abonnements
  final List<String> _subscriptionKeywords = [
    'abo', 'abonnement', 'subscription', 'mensuel', 'monthly',
    'netflix', 'spotify', 'disney+', 'amazon prime', 'canal+',
    'apple', 'google', 'microsoft', 'adobe', 'youtube',
  ];

  // Liste des services connus avec leurs informations
  final List<Map<String, dynamic>> _knownServices = [
    {
      'name': 'Netflix',
      'keywords': ['netflix'],
      'category': SubscriptionCategory.streaming,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    {
      'name': 'Spotify',
      'keywords': ['spotify'],
      'category': SubscriptionCategory.streaming,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    {
      'name': 'Disney+',
      'keywords': ['disney+', 'disney plus'],
      'category': SubscriptionCategory.streaming,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    {
      'name': 'Amazon Prime',
      'keywords': ['amazon prime', 'prime video'],
      'category': SubscriptionCategory.streaming,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    {
      'name': 'YouTube Premium',
      'keywords': ['youtube premium', 'youtube music'],
      'category': SubscriptionCategory.streaming,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    {
      'name': 'Microsoft 365',
      'keywords': ['microsoft 365', 'office 365', 'microsoft'],
      'category': SubscriptionCategory.software,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    {
      'name': 'Adobe Creative Cloud',
      'keywords': ['adobe', 'creative cloud'],
      'category': SubscriptionCategory.software,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    // Ajoutez d'autres services selon vos besoins
  ];

  @override
  Future<List<DetectedSubscriptionModel>> detectSubscriptions({
    required File csvFile,
    required CsvFormat csvFormat,
    DateTime? startDate,
  }) async {
    try {
      // Lire le contenu du fichier CSV
      final String fileContent = await csvFile.readAsString();

      // Détecter automatiquement le séparateur CSV
      String separator = ',';
      if (fileContent.contains(';')) {
        separator = ';';
      } else if (fileContent.contains('\t')) {
        separator = '\t';
      }

      // Analyser le CSV
      final List<List<dynamic>> csvData = const CsvToListConverter().convert(
        fileContent,
        fieldDelimiter: separator,
        eol: '\n',
      );

      if (csvData.isEmpty) {
        throw const FormatException('Le fichier CSV est vide ou malformé');
      }

      // Obtenir les en-têtes en fonction du format choisi
      final headers = _getHeadersForFormat(csvFormat, csvData.first);

      // Si le format n'est pas reconnu ou les en-têtes ne sont pas valides
      if (headers.isEmpty) {
        throw FormatException('Format CSV non reconnu: $csvFormat');
      }

      // Liste pour stocker les transactions
      final List<Map<String, dynamic>> transactions = [];

      // Traiter chaque ligne de données
      for (int i = 1; i < csvData.length; i++) {
        if (csvData[i].length < headers.length) continue;

        final Map<String, dynamic> transaction = {};
        for (int j = 0; j < headers.length; j++) {
          transaction[headers[j]] = j < csvData[i].length ? csvData[i][j] : null;
        }

        transactions.add(transaction);
      }

      // Filtrer par date si nécessaire
      final filteredTransactions = startDate != null
          ? transactions.where((t) => _parseDate(t['date'], csvFormat).isAfter(startDate))
          : transactions;

      // Analyser les transactions pour détecter des patterns récurrents
      final recurringTransactions = _findRecurringTransactions(
        filteredTransactions.toList(),
        csvFormat,
      );

      // Convertir les transactions récurrentes en abonnements détectés
      return _convertToDetectedSubscriptions(recurringTransactions);
    } catch (e) {
      throw FormatException('Erreur lors de l\'analyse du CSV: $e');
    }
  }

  /// Obtient les en-têtes appropriés en fonction du format du CSV
  List<String> _getHeadersForFormat(CsvFormat format, List<dynamic> firstRow) {
    switch (format) {
      case CsvFormat.genericBank:
        return ['date', 'description', 'amount'];
      case CsvFormat.creditAgricole:
        return ['date', 'valeur', 'description', 'debit', 'credit'];
      case CsvFormat.bnpParibas:
        return ['date opération', 'date valeur', 'description', 'débit euros', 'crédit euros'];
      case CsvFormat.societeGenerale:
        return ['date', 'description', 'montant', 'type'];
      case CsvFormat.boursorama:
        return ['date opération', 'libellé', 'montant', 'type'];
    // Ajoutez d'autres formats selon vos besoins
      case CsvFormat.custom:
      // Pour le format personnalisé, utiliser les en-têtes de la première ligne
        return firstRow.map((header) => header.toString().toLowerCase()).toList();
      default:
        return [];
    }
  }

  /// Convertit une chaîne de date en objet DateTime selon le format
  DateTime _parseDate(dynamic dateStr, CsvFormat format) {
    if (dateStr == null) return DateTime.now();

    try {
      switch (format) {
        case CsvFormat.creditAgricole:
        case CsvFormat.bnpParibas:
          return DateFormat('dd/MM/yyyy').parse(dateStr.toString());
        case CsvFormat.societeGenerale:
          return DateFormat('dd/MM/yy').parse(dateStr.toString());
        case CsvFormat.boursorama:
          return DateFormat('yyyy-MM-dd').parse(dateStr.toString());
      // Ajoutez d'autres formats selon vos besoins
        default:
        // Essayer plusieurs formats courants
          for (var formatStr in ['dd/MM/yyyy', 'yyyy-MM-dd', 'MM/dd/yyyy']) {
            try {
              return DateFormat(formatStr).parse(dateStr.toString());
            } catch (_) {
              // Passer au format suivant en cas d'échec
            }
          }
          // Par défaut, retourner la date actuelle
          return DateTime.now();
      }
    } catch (e) {
      // En cas d'erreur, retourner la date actuelle
      return DateTime.now();
    }
  }

  /// Extrait le montant d'une transaction selon le format
  double _extractAmount(Map<String, dynamic> transaction, CsvFormat format) {
    try {
      switch (format) {
        case CsvFormat.genericBank:
          return _parseAmount(transaction['amount']);
        case CsvFormat.creditAgricole:
        // Crédit Agricole a des colonnes séparées pour débit et crédit
          final debit = _parseAmount(transaction['debit']);
          final credit = _parseAmount(transaction['credit']);
          return debit != 0 ? -debit : credit;
        case CsvFormat.bnpParibas:
          final debit = _parseAmount(transaction['débit euros']);
          final credit = _parseAmount(transaction['crédit euros']);
          return debit != 0 ? -debit : credit;
        case CsvFormat.societeGenerale:
        case CsvFormat.boursorama:
          return _parseAmount(transaction['montant']);
      // Ajoutez d'autres formats selon vos besoins
        default:
        // Chercher une clé qui pourrait contenir le montant
          for (var key in ['amount', 'montant', 'debit', 'credit', 'débit', 'crédit']) {
            if (transaction.containsKey(key) && transaction[key] != null) {
              return _parseAmount(transaction[key]);
            }
          }
          return 0.0;
      }
    } catch (e) {
      return 0.0;
    }
  }

  /// Convertit une chaîne ou un nombre en double
  double _parseAmount(dynamic amount) {
    if (amount == null) return 0.0;

    if (amount is num) {
      return amount.toDouble();
    }

    final String amountStr = amount.toString()
        .replaceAll(' ', '')
        .replaceAll('€', '')
        .replaceAll('EUR', '')
        .replaceAll(',', '.');

    return double.tryParse(amountStr) ?? 0.0;
  }

  /// Trouve des groupes de transactions récurrentes
  List<Map<String, dynamic>> _findRecurringTransactions(
      List<Map<String, dynamic>> transactions,
      CsvFormat format,
      ) {
    // Map pour regrouper les transactions par description similaire
    final Map<String, List<Map<String, dynamic>>> groupedTransactions = {};

    // Regrouper les transactions par description
    for (var transaction in transactions) {
      final description = _normalizeDescription(transaction['description'].toString());

      // Vérifier si la description contient des mots-clés d'abonnement
      if (_isLikelySubscription(description)) {
        final key = _getDescriptionKey(description);

        if (!groupedTransactions.containsKey(key)) {
          groupedTransactions[key] = [];
        }

        groupedTransactions[key]!.add({
          ...transaction,
          'normalizedDescription': description,
          'amount': _extractAmount(transaction, format),
          'date': _parseDate(transaction['date'], format),
        });
      }
    }

    // Filtrer les groupes pour ne garder que ceux qui ont des transactions récurrentes
    final List<Map<String, dynamic>> recurringGroups = [];

    groupedTransactions.forEach((key, transactionGroup) {
      // Trier les transactions par date
      transactionGroup.sort((a, b) => (a['date'] as DateTime).compareTo(b['date'] as DateTime));

      // Si plus d'une transaction dans le groupe
      if (transactionGroup.length > 1) {
        // Calculer les intervalles entre transactions
        final List<int> intervals = [];
        for (int i = 1; i < transactionGroup.length; i++) {
          final days = (transactionGroup[i]['date'] as DateTime)
              .difference(transactionGroup[i - 1]['date'] as DateTime)
              .inDays;
          intervals.add(days);
        }

        // Si les intervalles sont similaires, c'est probablement un abonnement
        if (_areIntervalsSimilar(intervals)) {
          // Extraire montant min, max et moyen
          final amounts = transactionGroup.map((t) => t['amount'] as double).toList();
          final avgAmount = amounts.reduce((a, b) => a + b) / amounts.length;
          final minAmount = amounts.reduce((a, b) => a < b ? a : b);
          final maxAmount = amounts.reduce((a, b) => a > b ? a : b);

          // Périodicité estimée
          final avgInterval = intervals.reduce((a, b) => a + b) / intervals.length;
          final periodicity = _estimatePeriodicity(avgInterval);

          // Ajouter le groupe à la liste des groupes récurrents
          recurringGroups.add({
            'description': transactionGroup.first['normalizedDescription'],
            'transactions': transactionGroup,
            'avgAmount': avgAmount,
            'minAmount': minAmount,
            'maxAmount': maxAmount,
            'avgInterval': avgInterval,
            'periodicity': periodicity,
            'count': transactionGroup.length,
            'lastDate': transactionGroup.last['date'],
          });
        }
      }
    });

    return recurringGroups;
  }

  /// Normalise une description de transaction
  String _normalizeDescription(String description) {
    return description
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), ' ')  // Remplacer les caractères spéciaux par des espaces
        .replaceAll(RegExp(r'\s+'), ' ')      // Remplacer les espaces multiples par un seul
        .trim();
  }

  /// Vérifie si une description est susceptible d'être un abonnement
  bool _isLikelySubscription(String normalizedDescription) {
    // Vérifier les mots-clés généraux
    if (_subscriptionKeywords.any((keyword) => normalizedDescription.contains(keyword))) {
      return true;
    }

    // Vérifier si la description correspond à un service connu
    for (var service in _knownServices) {
      if ((service['keywords'] as List<String>).any((keyword) =>
          normalizedDescription.contains(keyword))) {
        return true;
      }
    }

    return false;
  }

  /// Génère une clé pour regrouper des descriptions similaires
  String _getDescriptionKey(String normalizedDescription) {
    // Pour les services connus, utiliser directement le nom du service
    for (var service in _knownServices) {
      if ((service['keywords'] as List<String>).any((keyword) =>
          normalizedDescription.contains(keyword))) {
        return service['name'];
      }
    }

    // Pour les autres, utiliser les 3 premiers mots (en éliminant les mots très courants)
    final words = normalizedDescription.split(' ')
        .where((word) => word.length > 2 && !['par', 'pour', 'avec', 'des', 'les'].contains(word))
        .take(3)
        .join(' ');

    return words.isEmpty ? normalizedDescription : words;
  }

  /// Vérifie si les intervalles entre transactions sont similaires
  bool _areIntervalsSimilar(List<int> intervals) {
    if (intervals.isEmpty) return false;
    if (intervals.length == 1) return true;

    // Calculer la moyenne et l'écart-type
    final avg = intervals.reduce((a, b) => a + b) / intervals.length;
    final sumSquareDiff = intervals.map((i) => (i - avg) * (i - avg)).reduce((a, b) => a + b);
    final stdDev = math.sqrt(sumSquareDiff / intervals.length);

    // Si l'écart-type est inférieur à 20% de la moyenne, considérer comme similaire
    return stdDev < (avg * 0.2);
  }

  /// Estime la périodicité basée sur l'intervalle moyen en jours
  SubscriptionPeriodicity _estimatePeriodicity(double avgInterval) {
    if (avgInterval <= 7) return SubscriptionPeriodicity.weekly;
    if (avgInterval <= 35) return SubscriptionPeriodicity.monthly;
    if (avgInterval <= 100) return SubscriptionPeriodicity.quarterly;
    if (avgInterval <= 190) return SubscriptionPeriodicity.biannual;
    return SubscriptionPeriodicity.annual;
  }

  /// Convertit des groupes de transactions récurrentes en modèles d'abonnements détectés
  List<DetectedSubscriptionModel> _convertToDetectedSubscriptions(
      List<Map<String, dynamic>> recurringGroups,
      ) {
    final List<DetectedSubscriptionModel> detectedSubscriptions = [];

    for (var group in recurringGroups) {
      final description = group['description'] as String;

      // Déterminer le nom et la catégorie
      String name = description;
      SubscriptionCategory category = SubscriptionCategory.other;

      // Vérifier si c'est un service connu
      for (var service in _knownServices) {
        if ((service['keywords'] as List<String>).any((keyword) => description.contains(keyword))) {
          name = service['name'] as String;
          category = service['category'] as SubscriptionCategory;
          break;
        }
      }

      // Créer l'abonnement détecté
      detectedSubscriptions.add(DetectedSubscriptionModel(
        name: _capitalizeFirstLetters(name),
        suggestedAmount: group['avgAmount'] as double,
        minAmount: group['minAmount'] as double,
        maxAmount: group['maxAmount'] as double,
        suggestedCategory: category,
        suggestedPeriodicity: group['periodicity'] as SubscriptionPeriodicity,
        // Suggérer la prochaine date de paiement basée sur la dernière date et la périodicité
        suggestedNextPaymentDate: _calculateNextPaymentDate(
          group['lastDate'] as DateTime,
          group['periodicity'] as SubscriptionPeriodicity,
        ),
        source: DetectionSource.csvImport,
        confidenceScore: _calculateConfidenceScore(group),
        metadata: {
          'transactionCount': group['count'] as int,
          'avgInterval': group['avgInterval'] as double,
        },
      ));
    }

    return detectedSubscriptions;
  }

  /// Capitalise les premières lettres de chaque mot
  String _capitalizeFirstLetters(String text) {
    return text.split(' ').map((word) =>
    word.isNotEmpty ? '${word[0].toUpperCase()}${word.substring(1)}' : ''
    ).join(' ');
  }

  /// Calcule la date du prochain paiement
  DateTime _calculateNextPaymentDate(DateTime lastDate, SubscriptionPeriodicity periodicity) {
    switch (periodicity) {
      case SubscriptionPeriodicity.daily:
        return lastDate.add(const Duration(days: 1));
      case SubscriptionPeriodicity.weekly:
        return lastDate.add(const Duration(days: 7));
      case SubscriptionPeriodicity.monthly:
        return DateTime(lastDate.year, lastDate.month + 1, lastDate.day);
      case SubscriptionPeriodicity.quarterly:
        return DateTime(lastDate.year, lastDate.month + 3, lastDate.day);
      case SubscriptionPeriodicity.biannual:
        return DateTime(lastDate.year, lastDate.month + 6, lastDate.day);
      case SubscriptionPeriodicity.annual:
        return DateTime(lastDate.year + 1, lastDate.month, lastDate.day);
      default:
        return lastDate.add(const Duration(days: 30));
    }
  }

  /// Calcule un score de confiance pour la détection
  double _calculateConfidenceScore(Map<String, dynamic> group) {
    // Plus il y a de transactions, plus la confiance est élevée
    double baseScore = 0.5;

    // Ajouter des points basés sur le nombre de transactions
    final count = group['count'] as int;
    if (count >= 12) {
      baseScore += 0.4;
    } else if (count >= 6) {
      baseScore += 0.3;
    } else if (count >= 3) {
      baseScore += 0.2;
    } else {
      baseScore += 0.1;
    }

    // Service connu?
    final description = group['description'] as String;
    for (var service in _knownServices) {
      if ((service['keywords'] as List<String>).any((keyword) => description.contains(keyword))) {
        baseScore += 0.1;
        break;
      }
    }

    // Limiter à 0.95 maximum
    return baseScore > 0.95 ? 0.95 : baseScore;
  }
}

