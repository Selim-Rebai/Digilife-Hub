// lib/features/subscription_detection/data/datasources/email_datasource.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:digilife_hub/core/errors/exceptions.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:digilife_hub/features/subscription_detection/data/models/detected_subscription_model.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';

/// Source de données pour la détection d'abonnements depuis les emails
abstract class EmailDataSource {
  /// Détecte les abonnements potentiels à partir des emails de l'utilisateur
  Future<List<DetectedSubscriptionModel>> detectSubscriptions({
    required String userEmail,
    required String accessToken,
    DateTime? startDate,
    int maxResults = 100,
  });
}

/// Implémentation pour l'API Gmail
class GmailDataSource implements EmailDataSource {
  final http.Client client;
  final List<String> _keywords = [
    'abonnement',
    'subscription',
    'mensuel',
    'monthly',
    'renouvellement',
    'renewal',
    'facture',
    'invoice',
    'receipt',
    'payment',
  ];

  final List<Map<String, dynamic>> _knownServices = [
    {
      'name': 'Netflix',
      'senders': ['info@netflix.com', 'netflix@netflix.com'],
      'category': SubscriptionCategory.streaming,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    {
      'name': 'Spotify',
      'senders': ['no-reply@spotify.com', 'spotify@spotify.com'],
      'category': SubscriptionCategory.streaming,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    {
      'name': 'Amazon Prime',
      'senders': ['auto-confirm@amazon.fr', 'transaction-confirm@amazon.fr', 'shipment-tracking@amazon.fr'],
      'category': SubscriptionCategory.shopping,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    {
      'name': 'Disney+',
      'senders': ['disneyplus@mail.disneyplus.com', 'disneyplusemea@disney.co.uk'],
      'category': SubscriptionCategory.streaming,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    {
      'name': 'YouTube Premium',
      'senders': ['google-noreply@google.com', 'youtube@youtube.com'],
      'category': SubscriptionCategory.streaming,
      'periodicity': SubscriptionPeriodicity.monthly,
    },
    // Vous pouvez ajouter d'autres services ici
  ];

  GmailDataSource({required this.client});

  @override
  Future<List<DetectedSubscriptionModel>> detectSubscriptions({
    required String userEmail,
    required String accessToken,
    DateTime? startDate,
    int maxResults = 100,
  }) async {
    try {
      // Construire la requête de recherche
      final startDateStr = startDate != null
          ? 'after:${startDate.year}/${startDate.month}/${startDate.day}'
          : 'newer_than:6m';

      // Ajouter mots-clés et expéditeurs connus
      final senderQuery = _knownServices
          .map((service) => service['senders'] as List<String>)
          .expand((senders) => senders)
          .map((sender) => 'from:$sender')
          .join(' OR ');

      final keywordQuery = _keywords
          .map((keyword) => '($keyword)')
          .join(' OR ');

      // Combiner les requêtes
      final searchQuery = '($keywordQuery) OR ($senderQuery) $startDateStr';

      // URL encodée pour la recherche
      final encodedQuery = Uri.encodeComponent(searchQuery);

      // Appel à l'API Gmail pour obtenir les messages correspondants
      final messagesResponse = await client.get(
        Uri.parse('https://www.googleapis.com/gmail/v1/users/me/messages?q=$encodedQuery&maxResults=$maxResults'),
        headers: {'Authorization': 'Bearer $accessToken'},
      );

      if (messagesResponse.statusCode != 200) {
        throw ServerException('Erreur lors de la récupération des emails: ${messagesResponse.body}');
      }

      final messagesData = json.decode(messagesResponse.body);
      final messages = messagesData['messages'] as List<dynamic>?;

      if (messages == null || messages.isEmpty) {
        return [];
      }

      // Liste pour stocker les abonnements détectés
      final detectedSubscriptions = <DetectedSubscriptionModel>[];

      // Traiter chaque message pour extraire les informations d'abonnement
      for (var message in messages) {
        final messageId = message['id'] as String;

        // Obtenir le contenu complet du message
        final messageResponse = await client.get(
          Uri.parse('https://www.googleapis.com/gmail/v1/users/me/messages/$messageId'),
          headers: {'Authorization': 'Bearer $accessToken'},
        );

        if (messageResponse.statusCode != 200) {
          continue; // Passer au message suivant en cas d'erreur
        }

        final messageData = json.decode(messageResponse.body);
        final headers = messageData['payload']['headers'] as List<dynamic>;

        // Extraire l'expéditeur et le sujet
        String? sender;
        String? subject;

        for (var header in headers) {
          if (header['name'] == 'From') {
            sender = header['value'] as String;
          } else if (header['name'] == 'Subject') {
            subject = header['value'] as String;
          }
        }

        if (sender == null || subject == null) {
          continue;
        }

        // Trouver le service correspondant
        var matchedService = _findMatchingService(sender);
        if (matchedService != null) {
          // Extraire le montant (si présent dans le sujet)
          final amountMatch = RegExp(r'(\d+[,.]\d{2})').firstMatch(subject);
          double? amount;

          if (amountMatch != null) {
            final amountStr = amountMatch.group(1)?.replaceAll(',', '.');
            amount = amountStr != null ? double.tryParse(amountStr) : null;
          }

          // Créer l'abonnement détecté
          detectedSubscriptions.add(DetectedSubscriptionModel(
            name: matchedService['name'] as String,
            suggestedAmount: amount,
            suggestedCategory: matchedService['category'] as SubscriptionCategory,
            suggestedPeriodicity: matchedService['periodicity'] as SubscriptionPeriodicity,
            source: DetectionSource.email,
            confidenceScore: 0.8, // Score élevé car service connu
            metadata: {
              'emailSender': sender,
              'emailSubject': subject,
              'messageId': messageId,
            },
          ));
        } else if (_containsSubscriptionKeywords(subject)) {
          // Pour les emails non associés à un service connu mais contenant des mots-clés
          // Essayer d'extraire le nom du service depuis l'expéditeur
          final serviceName = _extractServiceName(sender, subject);
          final amountMatch = RegExp(r'(\d+[,.]\d{2})').firstMatch(subject);
          double? amount;

          if (amountMatch != null) {
            final amountStr = amountMatch.group(1)?.replaceAll(',', '.');
            amount = amountStr != null ? double.tryParse(amountStr) : null;
          }

          // Créer l'abonnement détecté avec une confiance moindre
          detectedSubscriptions.add(DetectedSubscriptionModel(
            name: serviceName,
            suggestedAmount: amount,
            suggestedCategory: _guessCategoryFromKeywords(subject),
            suggestedPeriodicity: SubscriptionPeriodicity.monthly, // Supposer mensuel par défaut
            source: DetectionSource.email,
            confidenceScore: 0.6, // Score moyen car détection par mots-clés
            metadata: {
              'emailSender': sender,
              'emailSubject': subject,
              'messageId': messageId,
            },
          ));
        }
      }

      // Dédupliquer les abonnements (par nom)
      final uniqueSubscriptions = <String, DetectedSubscriptionModel>{};
      for (var subscription in detectedSubscriptions) {
        final existing = uniqueSubscriptions[subscription.name];
        if (existing == null || existing.confidenceScore < subscription.confidenceScore) {
          uniqueSubscriptions[subscription.name] = subscription;
        }
      }

      return uniqueSubscriptions.values.toList();
    } catch (e) {
      throw ServerException('Erreur lors de la détection depuis les emails: $e');
    }
  }

  /// Trouve un service correspondant à partir de l'adresse email de l'expéditeur
  Map<String, dynamic>? _findMatchingService(String sender) {
    final emailPattern = RegExp(r'<([^>]+)>');
    final match = emailPattern.firstMatch(sender);
    final email = match != null ? match.group(1) : sender;

    return _knownServices.firstWhere(
          (service) => (service['senders'] as List<String>).any((s) => email?.contains(s) ?? false),
      orElse: () => {} as Map<String, dynamic>,
    );
  }

  /// Vérifie si le sujet contient des mots-clés liés aux abonnements
  bool _containsSubscriptionKeywords(String subject) {
    final lowerSubject = subject.toLowerCase();
    return _keywords.any((keyword) => lowerSubject.contains(keyword.toLowerCase()));
  }

  /// Extrait un nom de service à partir de l'expéditeur et du sujet
  String _extractServiceName(String sender, String subject) {
    // Essayer d'extraire le nom du service à partir de l'expéditeur
    // Pattern commun: "Nom du Service <email@service.com>"
    final namePattern = RegExp(r'^"?([^"<]+)"?');
    final nameMatch = namePattern.firstMatch(sender);
    if (nameMatch != null) {
      final name = nameMatch.group(1)?.trim();
      if (name != null && name.isNotEmpty && !name.contains('@')) {
        return name.replaceAll(RegExp(r'\bTeam\b|\bSupport\b|\bInfo\b'), '').trim();
      }
    }

    // Si nom non trouvé dans l'expéditeur, essayer d'extraire du domaine de l'email
    final emailPattern = RegExp(r'<([^>]+)>');
    final emailMatch = emailPattern.firstMatch(sender);
    final email = emailMatch != null ? emailMatch.group(1) : sender;

    if (email != null) {
      final domainPattern = RegExp(r'@([^.]+)');
      final domainMatch = domainPattern.firstMatch(email);
      if (domainMatch != null) {
        final domain = domainMatch.group(1);
        if (domain != null && domain.isNotEmpty) {
          // Capitaliser la première lettre
          return domain.substring(0, 1).toUpperCase() + domain.substring(1);
        }
      }
    }

    // Si tout échoue, extraire des mots significatifs du sujet
    final words = subject.split(' ');
    if (words.isNotEmpty && words.length >= 2) {
      return words.take(3).join(' ');
    }

    return "Abonnement inconnu";
  }

  // Fin de la méthode _guessCategoryFromKeywords

  SubscriptionCategory _guessCategoryFromKeywords(String subject) {
    final lowerSubject = subject.toLowerCase();

    if (lowerSubject.contains('film') ||
        lowerSubject.contains('série') ||
        lowerSubject.contains('movie') ||
        lowerSubject.contains('stream') ||
        lowerSubject.contains('vidéo')) {
      return SubscriptionCategory.streaming;
    }

    if (lowerSubject.contains('logiciel') ||
        lowerSubject.contains('software') ||
        lowerSubject.contains('app') ||
        lowerSubject.contains('cloud')) {
      return SubscriptionCategory.software;
    }

    if (lowerSubject.contains('jeu') ||
        lowerSubject.contains('game')) {
      return SubscriptionCategory.gaming;
    }

    if (lowerSubject.contains('news') ||
        lowerSubject.contains('journal') ||
        lowerSubject.contains('actualité') ||
        lowerSubject.contains('magazine')) {
      return SubscriptionCategory.news;
    }

    if (lowerSubject.contains('santé') ||
        lowerSubject.contains('health') ||
        lowerSubject.contains('fitness')) {
      return SubscriptionCategory.health;
    }

    if (lowerSubject.contains('finance') ||
        lowerSubject.contains('banque') ||
        lowerSubject.contains('assurance') ||
        lowerSubject.contains('bank')) {
      return SubscriptionCategory.finance;
    }

    if (lowerSubject.contains('cours') ||
        lowerSubject.contains('formation') ||
        lowerSubject.contains('learning') ||
        lowerSubject.contains('education')) {
      return SubscriptionCategory.education;
    }

    // Par défaut, retourner "autre"
    return SubscriptionCategory.other;
  }
}