// lib/features/subscription_detection/data/datasources/subscription_template_datasource.dart

import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:digilife_hub/core/errors/exceptions.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:digilife_hub/features/subscription_detection/data/models/subscription_template_model.dart';

/// Source de données pour les modèles d'abonnements prédéfinis
abstract class SubscriptionTemplateDataSource {
  /// Récupère tous les modèles d'abonnements
  Future<List<SubscriptionTemplateModel>> getTemplates();

  /// Recherche des modèles d'abonnements par nom ou mots-clés
  Future<List<SubscriptionTemplateModel>> searchTemplates(String query, {int limit = 10});

  /// Récupère un modèle d'abonnement spécifique par son ID
  Future<SubscriptionTemplateModel> getTemplateById(String id);
}

/// Implémentation avec des modèles stockés localement dans un fichier JSON
class LocalSubscriptionTemplateDataSource implements SubscriptionTemplateDataSource {
  // Cache des templates pour éviter de relire le fichier
  List<SubscriptionTemplateModel>? _cachedTemplates;

  @override
  Future<List<SubscriptionTemplateModel>> getTemplates() async {
    try {
      // Si déjà en cache, utiliser directement
      if (_cachedTemplates != null) {
        return _cachedTemplates!;
      }

      // Charger les données depuis le fichier JSON
      final String jsonString = await rootBundle.loadString('assets/data/subscription_templates.json');
      final List<dynamic> jsonList = json.decode(jsonString);

      // Convertir en modèles
      _cachedTemplates = jsonList
          .map((json) => SubscriptionTemplateModel.fromJson(json))
          .toList();

      return _cachedTemplates!;
    } catch (e) {
      // Si le fichier n'est pas trouvé ou malformé, utiliser une liste intégrée de base
      _cachedTemplates = _getDefaultTemplates();
      return _cachedTemplates!;
    }
  }

  @override
  Future<List<SubscriptionTemplateModel>> searchTemplates(String query, {int limit = 10}) async {
    if (query.isEmpty) {
      // Si la requête est vide, retourner les plus populaires
      final templates = await getTemplates();
      return templates
          .where((template) => template.isPopular)
          .take(limit)
          .toList();
    }

    // Conversion de la requête pour la recherche
    final queryLower = query.toLowerCase();

    // Récupérer tous les templates
    final templates = await getTemplates();

    // Fonction pour calculer un score de correspondance
    int _calculateMatchScore(SubscriptionTemplateModel template) {
      int score = 0;

      // Correspondance exacte sur le nom
      if (template.name.toLowerCase() == queryLower) {
        score += 100;
      }
      // Correspondance sur le début du nom
      else if (template.name.toLowerCase().startsWith(queryLower)) {
        score += 50;
      }
      // Correspondance sur le nom contient la requête
      else if (template.name.toLowerCase().contains(queryLower)) {
        score += 25;
      }

      // Correspondance avec les mots-clés
      for (var keyword in template.keywords) {
        if (keyword.toLowerCase() == queryLower) {
          score += 30;
        } else if (keyword.toLowerCase().contains(queryLower)) {
          score += 15;
        }
      }

      // Bonus pour les services populaires
      if (template.isPopular) {
        score += 10;
      }

      return score;
    }

    // Filtrer et trier les templates selon le score de correspondance
    final searchResults = templates
        .map((template) => {
      'template': template,
      'score': _calculateMatchScore(template),
    })
        .where((item) => (item['score'] as num?) != null && (item['score'] as num) > 0) // Filtrer ceux qui ont un score positif
        .toList()
      ..sort((a, b) => (b['score'] as int).compareTo(a['score'] as int)); // Trier par score

    // Retourner les meilleurs résultats limités
    return searchResults
        .take(limit)
        .map((item) => item['template'] as SubscriptionTemplateModel)
        .toList();
  }

  @override
  Future<SubscriptionTemplateModel> getTemplateById(String id) async {
    final templates = await getTemplates();
    return templates.firstWhere(
          (template) => template.id == id,
      orElse: () => throw NotFoundException('Modèle d\'abonnement non trouvé avec l\'ID: $id'),
    );
  }

  /// Fournit une liste de modèles d'abonnements par défaut
  List<SubscriptionTemplateModel> _getDefaultTemplates() {
    return [
    const SubscriptionTemplateModel(
      id: 'netflix',
      name: 'Netflix',
      description: 'Service de streaming de films et séries',
      category: SubscriptionCategory.streaming,
      typicalPrice: 9.99,
      typicalPeriodicity: SubscriptionPeriodicity.monthly,
      logoUrl: 'assets/logos/netflix.png',
      keywords: ['netflix', 'streaming', 'films', 'séries'],
      emailSenders: ['info@netflix.com', 'netflix@netflix.com'],
      merchantNames: ['NETFLIX', 'Netflix'],
      website: 'https://www.netflix.com',
      isPopular: true,
    ),
      SubscriptionTemplateModel(
        id: 'spotify',
        name: 'Spotify',
        description: 'Service de streaming musical',
        category: SubscriptionCategory.streaming,
        typicalPrice: 9.99,
        typicalPeriodicity: SubscriptionPeriodicity.monthly,
        logoUrl: 'assets/logos/spotify.png',
        keywords: ['spotify', 'music', 'streaming', 'audio'],
        emailSenders: ['no-reply@spotify.com', 'spotify@spotify.com'],
        merchantNames: ['SPOTIFY', 'Spotify'],
        website: 'https://www.spotify.com',
        isPopular: true,
      ),
      SubscriptionTemplateModel(
        id: 'amazon-prime',
        name: 'Amazon Prime',
        description: 'Service de livraison rapide et streaming vidéo',
        category: SubscriptionCategory.streaming,
        typicalPrice: 5.99,
        typicalPeriodicity: SubscriptionPeriodicity.monthly,
        logoUrl: 'assets/logos/amazon-prime.png',
        keywords: ['amazon', 'prime', 'streaming', 'shopping'],
        emailSenders: ['auto-confirm@amazon.fr', 'transaction-confirm@amazon.fr'],
        merchantNames: ['AMAZON PRIME', 'Amazon Prime', 'AMZN Prime'],
        website: 'https://www.amazon.fr/prime',
        isPopular: true,
      ),
      SubscriptionTemplateModel(
        id: 'disney-plus',
        name: 'Disney+',
        description: 'Service de streaming de films et séries Disney',
        category: SubscriptionCategory.streaming,
        typicalPrice: 8.99,
        typicalPeriodicity: SubscriptionPeriodicity.monthly,
        logoUrl: 'assets/logos/disney-plus.png',
        keywords: ['disney', 'disney+', 'streaming'],
        emailSenders: ['disneyplus@mail.disneyplus.com'],
        merchantNames: ['DISNEY PLUS', 'Disney+', 'DISNEY+'],
        website: 'https://www.disneyplus.com',
        isPopular: true,
      ),
      SubscriptionTemplateModel(
        id: 'youtube-premium',
        name: 'YouTube Premium',
        description: 'YouTube sans publicités et YouTube Music',
        category: SubscriptionCategory.streaming,
        typicalPrice: 11.99,
        typicalPeriodicity: SubscriptionPeriodicity.monthly,
        logoUrl: 'assets/logos/youtube-premium.png',
        keywords: ['youtube', 'premium', 'music', 'streaming'],
        emailSenders: ['google-noreply@google.com', 'youtube-noreply@youtube.com'],
        merchantNames: ['YOUTUBE', 'YouTube Premium', 'GOOGLE *YouTube'],
        website: 'https://www.youtube.com/premium',
        isPopular: true,
      ),
      SubscriptionTemplateModel(
        id: 'canal-plus',
        name: 'Canal+',
        description: 'Chaîne de télévision et service de streaming',
        category: SubscriptionCategory.streaming,
        typicalPrice: 20.99,
        typicalPeriodicity: SubscriptionPeriodicity.monthly,
        logoUrl: 'assets/logos/canal-plus.png',
        keywords: ['canal', 'canal+', 'tv', 'streaming'],
        emailSenders: ['ne-pas-repondre@canal-plus.com'],
        merchantNames: ['CANAL+', 'Canal Plus', 'CANAL PLUS'],
        website: 'https://www.canalplus.com',
        isPopular: true,
      ),
      SubscriptionTemplateModel(
        id: 'microsoft-365',
        name: 'Microsoft 365',
        description: 'Suite Office et stockage cloud',
        category: SubscriptionCategory.software,
        typicalPrice: 7.99,
        typicalPeriodicity: SubscriptionPeriodicity.monthly,
        logoUrl: 'assets/logos/microsoft-365.png',
        keywords: ['microsoft', 'office', '365', 'word', 'excel'],
        emailSenders: ['microsoft-billing@microsoft.com', 'office365@email.office.com'],
        merchantNames: ['MICROSOFT', 'Microsoft 365', 'MS Office 365'],
        website: 'https://www.microsoft.com/microsoft-365',
        isPopular: true,
      ),
      SubscriptionTemplateModel(
        id: 'adobe-cc',
        name: 'Adobe Creative Cloud',
        description: 'Suite de logiciels créatifs',
        category: SubscriptionCategory.software,
        typicalPrice: 59.99,
        typicalPeriodicity: SubscriptionPeriodicity.monthly,
        logoUrl: 'assets/logos/adobe-cc.png',
        keywords: ['adobe', 'creative', 'cloud', 'photoshop', 'illustrator'],
        emailSenders: ['message@adobe.com', 'no-reply@adobe.com'],
        merchantNames: ['ADOBE', 'Adobe Systems', 'ADOBE CC'],
        website: 'https://www.adobe.com/creativecloud.html',
        isPopular: true,
      ),
      SubscriptionTemplateModel(
        id: 'dropbox',
        name: 'Dropbox',
        description: 'Service de stockage cloud',
        category: SubscriptionCategory.software,
        typicalPrice: 9.99,
        typicalPeriodicity: SubscriptionPeriodicity.monthly,
        logoUrl: 'assets/logos/dropbox.png',
        keywords: ['dropbox', 'cloud', 'storage', 'sauvegarde'],
        emailSenders: ['no-reply@dropbox.com', 'info@dropboxmail.com'],
        merchantNames: ['DROPBOX', 'Dropbox, Inc.'],
        website: 'https://www.dropbox.com',
        isPopular: false,
      ),
      // Ajouter d'autres templates selon vos besoins...
    ];
  }
}

/// Exception pour les éléments non trouvés
class NotFoundException implements Exception {
  final String message;

  NotFoundException(this.message);

  @override
  String toString() => message;
}