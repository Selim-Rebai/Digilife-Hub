// lib/features/subscription_detection/data/models/subscription_template_model.dart

import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/subscription_template.dart';

class SubscriptionTemplateModel extends SubscriptionTemplate {
  const SubscriptionTemplateModel({
    required String id,
    required String name,
    required String description,
    required SubscriptionCategory category,
    double? typicalPrice,
    required SubscriptionPeriodicity typicalPeriodicity,
    String? logoUrl,
    List<String> keywords = const [],
    List<String> emailSenders = const [],
    List<String> merchantNames = const [],
    String? website,
    bool isPopular = false,
  }) : super(
    id: id,
    name: name,
    description: description,
    category: category,
    typicalPrice: typicalPrice,
    typicalPeriodicity: typicalPeriodicity,
    logoUrl: logoUrl,
    keywords: keywords,
    emailSenders: emailSenders,
    merchantNames: merchantNames,
    website: website,
    isPopular: isPopular,
  );

  /// Crée un modèle à partir d'un Map (JSON)
  factory SubscriptionTemplateModel.fromJson(Map<String, dynamic> json) {
    return SubscriptionTemplateModel(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String,
      category: _parseCategory(json['category'] as String?),
      typicalPrice: json['typicalPrice'] != null ? (json['typicalPrice'] as num).toDouble() : null,
      typicalPeriodicity: _parsePeriodicity(json['typicalPeriodicity'] as String?),
      logoUrl: json['logoUrl'] as String?,
      keywords: _parseStringList(json['keywords']),
      emailSenders: _parseStringList(json['emailSenders']),
      merchantNames: _parseStringList(json['merchantNames']),
      website: json['website'] as String?,
      isPopular: json['isPopular'] as bool? ?? false,
    );
  }

  /// Convertit le modèle en Map (JSON)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'category': category.toString().split('.').last,
      'typicalPrice': typicalPrice,
      'typicalPeriodicity': typicalPeriodicity.toString().split('.').last,
      'logoUrl': logoUrl,
      'keywords': keywords,
      'emailSenders': emailSenders,
      'merchantNames': merchantNames,
      'website': website,
      'isPopular': isPopular,
    };
  }

  /// Crée une copie avec des valeurs modifiées
  SubscriptionTemplateModel copyWith({
    String? id,
    String? name,
    String? description,
    SubscriptionCategory? category,
    double? typicalPrice,
    SubscriptionPeriodicity? typicalPeriodicity,
    String? logoUrl,
    List<String>? keywords,
    List<String>? emailSenders,
    List<String>? merchantNames,
    String? website,
    bool? isPopular,
  }) {
    return SubscriptionTemplateModel(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      category: category ?? this.category,
      typicalPrice: typicalPrice ?? this.typicalPrice,
      typicalPeriodicity: typicalPeriodicity ?? this.typicalPeriodicity,
      logoUrl: logoUrl ?? this.logoUrl,
      keywords: keywords ?? this.keywords,
      emailSenders: emailSenders ?? this.emailSenders,
      merchantNames: merchantNames ?? this.merchantNames,
      website: website ?? this.website,
      isPopular: isPopular ?? this.isPopular,
    );
  }

  /// Fonction utilitaire pour convertir une chaîne en catégorie
  static SubscriptionCategory _parseCategory(String? value) {
    if (value == null) return SubscriptionCategory.other;

    try {
      return SubscriptionCategory.values.firstWhere(
            (e) => e.toString().split('.').last.toLowerCase() == value.toLowerCase(),
      );
    } catch (_) {
      return SubscriptionCategory.other;
    }
  }

  /// Fonction utilitaire pour convertir une chaîne en périodicité
  static SubscriptionPeriodicity _parsePeriodicity(String? value) {
    if (value == null) return SubscriptionPeriodicity.monthly;

    try {
      return SubscriptionPeriodicity.values.firstWhere(
            (e) => e.toString().split('.').last.toLowerCase() == value.toLowerCase(),
      );
    } catch (_) {
      return SubscriptionPeriodicity.monthly;
    }
  }

  /// Fonction utilitaire pour convertir une liste JSON en liste de chaînes
  static List<String> _parseStringList(dynamic value) {
    if (value == null) return [];
    if (value is List) {
      return value.map((item) => item.toString()).toList();
    }
    return [];
  }
}