// lib/features/subscription_detection/data/models/detected_subscription_model.dart

import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:digilife_hub/features/subscription_detection/domain/entities/detected_subscription.dart';

class DetectedSubscriptionModel extends DetectedSubscription {
  const DetectedSubscriptionModel({
    required String name,
    double? suggestedAmount,
    double? minAmount,
    double? maxAmount,
    SubscriptionCategory? suggestedCategory,
    SubscriptionPeriodicity? suggestedPeriodicity,
    String? logoUrl,
    String? suggestedDescription,
    DateTime? suggestedNextPaymentDate,
    required DetectionSource source,
    required double confidenceScore,
    Map<String, dynamic> metadata = const {},
  }) : super(
    name: name,
    suggestedAmount: suggestedAmount,
    minAmount: minAmount,
    maxAmount: maxAmount,
    suggestedCategory: suggestedCategory,
    suggestedPeriodicity: suggestedPeriodicity,
    logoUrl: logoUrl,
    suggestedDescription: suggestedDescription,
    suggestedNextPaymentDate: suggestedNextPaymentDate,
    source: source,
    confidenceScore: confidenceScore,
    metadata: metadata,
  );

  /// Création à partir d'un Map (JSON)
  factory DetectedSubscriptionModel.fromJson(Map<String, dynamic> json) {
    // Fonction utilitaire pour convertir une chaîne en énumération
    SubscriptionCategory? _parseCategory(String? value) {
      if (value == null) return null;
      try {
        return SubscriptionCategory.values.firstWhere(
              (e) => e.toString().split('.').last.toLowerCase() == value.toLowerCase(),
        );
      } catch (_) {
        return null;
      }
    }

    SubscriptionPeriodicity? _parsePeriodicity(String? value) {
      if (value == null) return null;
      try {
        return SubscriptionPeriodicity.values.firstWhere(
              (e) => e.toString().split('.').last.toLowerCase() == value.toLowerCase(),
        );
      } catch (_) {
        return null;
      }
    }

    DetectionSource _parseSource(String value) {
      try {
        return DetectionSource.values.firstWhere(
              (e) => e.toString().split('.').last.toLowerCase() == value.toLowerCase(),
        );
      } catch (_) {
        return DetectionSource.manualEntry; // Valeur par défaut
      }
    }

    return DetectedSubscriptionModel(
      name: json['name'] as String,
      suggestedAmount: json['suggestedAmount'] != null ? (json['suggestedAmount'] as num).toDouble() : null,
      minAmount: json['minAmount'] != null ? (json['minAmount'] as num).toDouble() : null,
      maxAmount: json['maxAmount'] != null ? (json['maxAmount'] as num).toDouble() : null,
      suggestedCategory: _parseCategory(json['suggestedCategory'] as String?),
      suggestedPeriodicity: _parsePeriodicity(json['suggestedPeriodicity'] as String?),
      logoUrl: json['logoUrl'] as String?,
      suggestedDescription: json['suggestedDescription'] as String?,
      suggestedNextPaymentDate: json['suggestedNextPaymentDate'] != null
          ? DateTime.parse(json['suggestedNextPaymentDate'] as String)
          : null,
      source: _parseSource(json['source'] as String),
      confidenceScore: (json['confidenceScore'] as num?)?.toDouble() ?? 0.5,
      metadata: json['metadata'] as Map<String, dynamic>? ?? {},
    );
  }

  /// Conversion en Map (JSON)
  Map<String, dynamic> toJson() {
    String? _enumToString(Object? enumValue) {
      return enumValue?.toString().split('.').last;
    }

    return {
      'name': name,
      'suggestedAmount': suggestedAmount,
      'minAmount': minAmount,
      'maxAmount': maxAmount,
      'suggestedCategory': _enumToString(suggestedCategory),
      'suggestedPeriodicity': _enumToString(suggestedPeriodicity),
      'logoUrl': logoUrl,
      'suggestedDescription': suggestedDescription,
      'suggestedNextPaymentDate': suggestedNextPaymentDate?.toIso8601String(),
      'source': _enumToString(source),
      'confidenceScore': confidenceScore,
      'metadata': metadata,
    };
  }

  /// Crée une copie avec des valeurs modifiées
  DetectedSubscriptionModel copyWith({
    String? name,
    double? suggestedAmount,
    double? minAmount,
    double? maxAmount,
    SubscriptionCategory? suggestedCategory,
    SubscriptionPeriodicity? suggestedPeriodicity,
    String? logoUrl,
    String? suggestedDescription,
    DateTime? suggestedNextPaymentDate,
    DetectionSource? source,
    double? confidenceScore,
    Map<String, dynamic>? metadata,
  }) {
    return DetectedSubscriptionModel(
      name: name ?? this.name,
      suggestedAmount: suggestedAmount ?? this.suggestedAmount,
      minAmount: minAmount ?? this.minAmount,
      maxAmount: maxAmount ?? this.maxAmount,
      suggestedCategory: suggestedCategory ?? this.suggestedCategory,
      suggestedPeriodicity: suggestedPeriodicity ?? this.suggestedPeriodicity,
      logoUrl: logoUrl ?? this.logoUrl,
      suggestedDescription: suggestedDescription ?? this.suggestedDescription,
      suggestedNextPaymentDate: suggestedNextPaymentDate ?? this.suggestedNextPaymentDate,
      source: source ?? this.source,
      confidenceScore: confidenceScore ?? this.confidenceScore,
      metadata: metadata ?? this.metadata,
    );
  }
}