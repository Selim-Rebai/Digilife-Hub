import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:digilife_hub/core/config/firebase_config.dart';
import 'package:digilife_hub/presentation/app.dart';
import 'injection_container.dart' as di;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Orientation fixe (option - vous pouvez l'ajuster selon vos besoins)
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  // Initialiser Firebase
  await FirebaseConfig.initialize();

  // Initialiser l'injection de dépendances
  await di.init();

  runApp(const DigiLifeHubApp());
}