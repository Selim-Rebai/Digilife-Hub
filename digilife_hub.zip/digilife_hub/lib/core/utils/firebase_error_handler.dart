import 'package:firebase_auth/firebase_auth.dart';
import 'package:digilife_hub/core/errors/auth_failures.dart';
import 'package:digilife_hub/core/errors/failures.dart';

class FirebaseErrorHandler {
  static Failure handleAuthException(Object e) {
    if (e is FirebaseAuthException) {
      switch (e.code) {
        case 'invalid-email':
          return const InvalidEmailFailure();
        case 'user-disabled':
          return const UserDisabledFailure();
        case 'user-not-found':
          return const UserNotFoundFailure();
        case 'wrong-password':
          return const WrongPasswordFailure();
        case 'email-already-in-use':
          return const EmailAlreadyInUseFailure();
        case 'weak-password':
          return const WeakPasswordFailure();
        case 'too-many-requests':
          return const TooManyRequestsFailure();
        case 'operation-not-allowed':
          return AuthFailure('Opération non autorisée: ${e.message}');
        case 'account-exists-with-different-credential':
          return const AuthFailure('Ce compte existe avec des identifiants différents');
        case 'invalid-credential':
          return const AuthFailure('Identifiants invalides');
        case 'invalid-verification-code':
          return const AuthFailure('Code de vérification invalide');
        case 'invalid-verification-id':
          return const AuthFailure('ID de vérification invalide');
        default:
          return AuthFailure('Erreur d\'authentification: ${e.message}');
      }
    } else if (e is FirebaseException) {
      return ServerFailure('Erreur serveur: ${e.message}');
    }

    return UnknownFailure(e.toString());
  }
}