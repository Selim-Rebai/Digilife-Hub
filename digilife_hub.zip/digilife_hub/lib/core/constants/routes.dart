// lib/core/constants/routes.dart

import 'package:flutter/material.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/presentation/pages/auth/forgot_password_page.dart';
import 'package:digilife_hub/presentation/pages/auth/login_page.dart';
import 'package:digilife_hub/presentation/pages/auth/register_page.dart';
import 'package:digilife_hub/presentation/pages/splash/splash_page.dart';
import 'package:digilife_hub/presentation/pages/home/home_page.dart';
import 'package:digilife_hub/presentation/pages/subscription/subscription_dashboard_page.dart';
import 'package:digilife_hub/presentation/pages/subscription/subscription_form_page.dart';
import 'package:digilife_hub/presentation/pages/subscription/subscription_detail_page.dart';
import 'package:digilife_hub/presentation/pages/profile/profile_page.dart';
import 'package:digilife_hub/presentation/pages/calendar/calendar_page.dart';
import 'package:digilife_hub/presentation/navigation/main_navigation.dart';
import 'package:digilife_hub/features/subscription_detection/presentation/pages/subscription_detection_page.dart';

class Routes {
  // Pages principales
  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';

  // Pages après authentification
  static const String home = '/home';
  static const String dashboard = '/dashboard';
  static const String subscriptions = '/subscriptions';
  static const String addSubscription = '/add-subscription';
  static const String updateSubscription = '/update-subscription';
  static const String subscriptionDetail = '/subscription-detail';

  // Détection d'abonnements
  static const String detectSubscriptions = '/detect-subscriptions';

  // Gestionnaire d'identités
  static const String identityManager = '/identity-manager';
  static const String addIdentity = '/add-identity';
  static const String identityDetail = '/identity-detail';

  // Pages de profil et paramètres
  static const String profile = '/profile';
  static const String settings = '/settings';
  static const String security = '/security';

  // Fonction pour obtenir toutes les routes
  static Map<String, WidgetBuilder> getRoutes() {
    print("DEBUG: Routes - getRoutes appelé");
    return {
      splash: (context) => const SplashPage(),
      login: (context) => const LoginPage(),
      register: (context) => const RegisterPage(),
      forgotPassword: (context) => const ForgotPasswordPage(),
      home: (context) => const MainNavigation(),
      dashboard: (context) => const SubscriptionDashboardPage(),
      subscriptions: (context) => const SubscriptionDashboardPage(),
      addSubscription: (context) => const SubscriptionFormPage(),
      profile: (context) => const ProfilePage(),
      detectSubscriptions: (context) {
        print("DEBUG: Routes - Navigation vers SubscriptionDetectionPage");
        return const SubscriptionDetectionPage();
      },
      // Les routes nécessitant des arguments sont gérées dans onGenerateRoute
    };
  }
}