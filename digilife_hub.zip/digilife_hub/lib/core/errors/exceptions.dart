// lib/core/errors/exceptions.dart

/// Exception de base pour l'application
class AppException implements Exception {
  final String message;

  const AppException(this.message);

  @override
  String toString() => message;
}

/// Exception pour les erreurs de serveur
class ServerException extends AppException {
  const ServerException([String message = 'Erreur de serveur'])
      : super(message);
}

/// Exception pour les erreurs de cache
class CacheException extends AppException {
  const CacheException([String message = 'Erreur de cache'])
      : super(message);
}

/// Exception pour les erreurs de réseau
class NetworkException extends AppException {
  const NetworkException([String message = 'Erreur de connexion réseau'])
      : super(message);
}

/// Exception pour les erreurs de format
class FormatException extends AppException {
  const FormatException([String message = 'Format de données invalide'])
      : super(message);
}

/// Exception pour quand un élément n'est pas trouvé
class NotFoundException extends AppException {
  const NotFoundException([String message = 'Élément non trouvé'])
      : super(message);
}

/// Exception pour les erreurs d'authentification
class AuthException extends AppException {
  const AuthException([String message = "Erreur d'authentification"])
      : super(message);
}

/// Exception pour les erreurs de validation
class ValidationException extends AppException {
  final Map<String, String>? errors;

  const ValidationException([String message = 'Erreur de validation', this.errors])
      : super(message);
}

/// Exception pour les opérations non autorisées
class UnauthorizedException extends AppException {
  const UnauthorizedException([String message = 'Opération non autorisée'])
      : super(message);
}

/// Exception pour les fonctionnalités non supportées
class UnsupportedFeatureException extends AppException {
  const UnsupportedFeatureException([String message = 'Fonctionnalité non supportée'])
      : super(message);
}