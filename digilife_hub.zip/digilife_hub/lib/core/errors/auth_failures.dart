import 'package:digilife_hub/core/errors/failures.dart';

// Failures spécifiques à l'authentification
class AuthFailure extends Failure {
  const AuthFailure(super.message);
}

class EmailAlreadyInUseFailure extends AuthFailure {
  const EmailAlreadyInUseFailure() : super('Cette adresse email est déjà utilisée');
}

class InvalidEmailFailure extends AuthFailure {
  const InvalidEmailFailure() : super('Adresse email invalide');
}

class WeakPasswordFailure extends AuthFailure {
  const WeakPasswordFailure() : super('Le mot de passe est trop faible');
}

class UserNotFoundFailure extends AuthFailure {
  const UserNotFoundFailure() : super('Aucun utilisateur trouvé avec cette adresse email');
}

class WrongPasswordFailure extends AuthFailure {
  const WrongPasswordFailure() : super('Mot de passe incorrect');
}

class UserDisabledFailure extends AuthFailure {
  const UserDisabledFailure() : super('Ce compte utilisateur a été désactivé');
}

class TooManyRequestsFailure extends AuthFailure {
  const TooManyRequestsFailure() : super('Trop de tentatives de connexion, veuillez réessayer plus tard');
}