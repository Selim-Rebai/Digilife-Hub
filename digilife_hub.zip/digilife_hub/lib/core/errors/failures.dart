import 'package:equatable/equatable.dart';

abstract class Failure extends Equatable {
  final String message;

  const Failure(this.message);

  @override
  List<Object> get props => [message];
}

// Failures génériques
class ServerFailure extends Failure {
  const ServerFailure(super.message);
}

class CacheFailure extends Failure {
  const CacheFailure(super.message);
}

class NetworkFailure extends Failure {
  const NetworkFailure([String message = 'Problème de connexion réseau']) : super(message);
}

class UnknownFailure extends Failure {
  const UnknownFailure(super.message);
}

// Failures spécifiques aux abonnements
class SubscriptionNotFoundFailure extends Failure {
  const SubscriptionNotFoundFailure([String message = 'Abonnement non trouvé']) : super(message);
}

class InvalidSubscriptionDataFailure extends Failure {
  const InvalidSubscriptionDataFailure([String message = 'Données d\'abonnement invalides']) : super(message);
}

class SubscriptionLimitReachedFailure extends Failure {
  const SubscriptionLimitReachedFailure([String message = 'Limite d\'abonnements atteinte']) : super(message);
}

// Ajout des nouvelles failures pour la fonctionnalité d'annulation
class NotFoundFailure extends Failure {
  const NotFoundFailure([String message = 'Ressource non trouvée']) : super(message);
}

class NotSupportedFailure extends Failure {
  const NotSupportedFailure([String message = 'Fonctionnalité non supportée']) : super(message);
}

class ProcessingFailure extends Failure {
  const ProcessingFailure([String message = 'Erreur lors du traitement']) : super(message);
}