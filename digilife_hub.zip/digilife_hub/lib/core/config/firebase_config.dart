import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class FirebaseConfig {
  static Future<void> initialize() async {
    try {
      await Firebase.initializeApp(
        // options: DefaultFirebaseOptions.currentPlatform, // Vous devrez générer ces options avec flutterfire
      );
      debugPrint('Firebase initialized successfully');
    } catch (e) {
      debugPrint('Error initializing Firebase: $e');
      rethrow;
    }
  }
}

// Note: Vous devrez exécuter la commande suivante pour configurer Firebase:
// flutterfire configure