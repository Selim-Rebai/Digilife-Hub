// lib/core/usecases/usecase.dart

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:digilife_hub/core/errors/failures.dart';

/// Interface générique pour tous les cas d'utilisation (use cases)
///
/// [Type] est le type de retour du cas d'utilisation
/// [Params] sont les paramètres nécessaires pour exécuter le cas d'utilisation
abstract class UseCase<Type, Params> {
  Future<Either<Failure, Type>> call(Params params);
}

/// Classe pour les cas d'utilisation qui ne nécessitent pas de paramètres
class NoParams extends Equatable {
  @override
  List<Object> get props => [];
}