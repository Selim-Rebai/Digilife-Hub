// lib/data/models/subscription_model.dart

import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';

class SubscriptionModel extends Subscription {
  const SubscriptionModel({
    required super.id,
    required super.name,
    required super.amount,
    required super.periodicity,
    required super.nextPaymentDate,
    required super.category,
    super.description,
    super.logoUrl,
    required super.status,
    required super.startDate,
    required super.hasReminder,
    super.reminderDays,
  });

  /// Crée un SubscriptionModel à partir d'un Map (JSON)
  factory SubscriptionModel.fromJson(Map<String, dynamic> json) {
    try {
      return SubscriptionModel(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? '',
        amount: (json['amount'] is num) ? (json['amount'] as num).toDouble() : 0.0,
        periodicity: _periodicityFromString(json['periodicity']?.toString() ?? ''),
        nextPaymentDate: json['nextPaymentDate'] != null
            ? DateTime.parse(json['nextPaymentDate'].toString())
            : DateTime.now(),
        category: _categoryFromString(json['category']?.toString() ?? ''),
        description: json['description']?.toString(),
        logoUrl: json['logoUrl']?.toString(),
        status: _statusFromString(json['status']?.toString() ?? ''),
        startDate: json['startDate'] != null
            ? DateTime.parse(json['startDate'].toString())
            : DateTime.now(),
        hasReminder: json['hasReminder'] == true,
        reminderDays: json['reminderDays'] is int ? json['reminderDays'] as int : null,
      );
    } catch (e) {
      print('Erreur lors de la conversion du JSON en SubscriptionModel: $e');
      return SubscriptionModel.empty();
    }
  }

  /// Convertit le modèle en Map (JSON)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'amount': amount,
      'periodicity': periodicity.toString().split('.').last,
      'nextPaymentDate': nextPaymentDate.toIso8601String(),
      'category': category.toString().split('.').last,
      'description': description,
      'logoUrl': logoUrl,
      'status': status.toString().split('.').last,
      'startDate': startDate.toIso8601String(),
      'hasReminder': hasReminder,
      'reminderDays': reminderDays,
    };
  }

  /// Crée un SubscriptionModel vide
  factory SubscriptionModel.empty() => SubscriptionModel(
    id: '',
    name: '',
    amount: 0.0,
    periodicity: SubscriptionPeriodicity.monthly,
    nextPaymentDate: DateTime.now(),
    category: SubscriptionCategory.other,
    status: SubscriptionStatus.inactive,
    startDate: DateTime.now(),
    hasReminder: false,
  );

  /// Convertit une chaîne en SubscriptionPeriodicity
  static SubscriptionPeriodicity _periodicityFromString(String value) {
    return SubscriptionPeriodicity.values.firstWhere(
          (e) => e.toString().split('.').last == value,
      orElse: () => SubscriptionPeriodicity.monthly,
    );
  }

  /// Convertit une chaîne en SubscriptionCategory
  static SubscriptionCategory _categoryFromString(String value) {
    return SubscriptionCategory.values.firstWhere(
          (e) => e.toString().split('.').last == value,
      orElse: () => SubscriptionCategory.other,
    );
  }

  /// Convertit une chaîne en SubscriptionStatus
  static SubscriptionStatus _statusFromString(String value) {
    return SubscriptionStatus.values.firstWhere(
          (e) => e.toString().split('.').last == value,
      orElse: () => SubscriptionStatus.inactive,
    );
  }
}