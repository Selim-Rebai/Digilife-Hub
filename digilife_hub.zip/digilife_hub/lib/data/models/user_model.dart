import 'package:digilife_hub/domain/entities/user.dart';
import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;

class UserModel extends User {
  const UserModel({
    required super.id,
    required super.email,
    super.displayName,
    super.photoUrl,
    required super.emailVerified,
    required super.createdAt,
    required super.lastLogin,
  });

  // Conversion depuis Firebase User
  factory UserModel.fromFirebaseUser(firebase_auth.User firebaseUser) {
    return UserModel(
      id: firebaseUser.uid,
      email: firebaseUser.email ?? '',
      displayName: firebaseUser.displayName,
      photoUrl: firebaseUser.photoURL,
      emailVerified: firebaseUser.emailVerified,
      createdAt: firebaseUser.metadata.creationTime ?? DateTime.now(),
      lastLogin: firebaseUser.metadata.lastSignInTime ?? DateTime.now(),
    );
  }

  // Conversion depuis PigeonUserDetails (ajout pour traiter le cas d'erreur)
  factory UserModel.fromPigeonUserDetails(dynamic pigeonUserDetails) {
    // Si null, retourner un utilisateur vide
    if (pigeonUserDetails == null) {
      return UserModel.empty();
    }

    try {
      // Tenter de convertir l'objet en utilisant une approche sécurisée
      // Cette méthode évite les erreurs de transtypage
      return UserModel(
        id: _safeGetString(pigeonUserDetails, 'id') ?? '',
        email: _safeGetString(pigeonUserDetails, 'email') ?? '',
        displayName: _safeGetString(pigeonUserDetails, 'displayName'),
        photoUrl: _safeGetString(pigeonUserDetails, 'photoUrl'),
        emailVerified: _safeGetBool(pigeonUserDetails, 'emailVerified') ?? false,
        createdAt: DateTime.now(), // Valeur par défaut
        lastLogin: DateTime.now(), // Valeur par défaut
      );
    } catch (e) {
      print('Erreur lors de la conversion PigeonUserDetails: $e');
      // En cas d'erreur, retourner un utilisateur vide
      return UserModel.empty();
    }
  }

  // Méthodes utilitaires pour l'accès sécurisé aux propriétés
  static String? _safeGetString(dynamic obj, String property) {
    try {
      if (obj is Map) {
        return obj[property]?.toString();
      } else if (obj != null) {
        final value = obj[property];
        return value?.toString();
      }
      return null;
    } catch (e) {
      print('Erreur lors de l\'accès à la propriété $property: $e');
      return null;
    }
  }

  static bool? _safeGetBool(dynamic obj, String property) {
    try {
      if (obj is Map) {
        return obj[property] == true;
      } else if (obj != null) {
        final value = obj[property];
        return value == true;
      }
      return null;
    } catch (e) {
      print('Erreur lors de l\'accès à la propriété $property: $e');
      return null;
    }
  }

  // Conversion vers et depuis Map pour stockage local
  factory UserModel.fromJson(Map<String, dynamic> json) {
    try {
      return UserModel(
        id: json['id']?.toString() ?? '',
        email: json['email']?.toString() ?? '',
        displayName: json['displayName']?.toString(),
        photoUrl: json['photoUrl']?.toString(),
        emailVerified: json['emailVerified'] == true,
        createdAt: json['createdAt'] != null
            ? DateTime.parse(json['createdAt'].toString())
            : DateTime.now(),
        lastLogin: json['lastLogin'] != null
            ? DateTime.parse(json['lastLogin'].toString())
            : DateTime.now(),
      );
    } catch (e) {
      // Log l'erreur
      print('Erreur lors de la conversion du JSON en UserModel: $e');
      // Retourner un utilisateur vide au lieu de lancer une exception
      return UserModel.empty();
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'emailVerified': emailVerified,
      'createdAt': createdAt.toIso8601String(),
      'lastLogin': lastLogin.toIso8601String(),
    };
  }

  // Copie avec modification
  UserModel copyWith({
    String? id,
    String? email,
    String? displayName,
    String? photoUrl,
    bool? emailVerified,
    DateTime? createdAt,
    DateTime? lastLogin,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      emailVerified: emailVerified ?? this.emailVerified,
      createdAt: createdAt ?? this.createdAt,
      lastLogin: lastLogin ?? this.lastLogin,
    );
  }

  // Utilisateur vide (méthode héritée augmentée pour plus de sécurité)
  factory UserModel.empty() => UserModel(
    id: '',
    email: '',
    emailVerified: false,
    createdAt: DateTime.now(),
    lastLogin: DateTime.now(),
  );
}