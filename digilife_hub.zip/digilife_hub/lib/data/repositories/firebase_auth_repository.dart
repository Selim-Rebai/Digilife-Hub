import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:digilife_hub/core/errors/auth_failures.dart';
import 'package:digilife_hub/core/utils/firebase_error_handler.dart';
import 'package:digilife_hub/data/models/user_model.dart';
import 'package:digilife_hub/domain/entities/user.dart' as domain;
import 'package:digilife_hub/domain/repositories/auth_repository.dart';

import '../../core/errors/failures.dart';

class FirebaseAuthRepository implements AuthRepository {
  final firebase_auth.FirebaseAuth _firebaseAuth;
  final GoogleSignIn _googleSignIn;
  final FlutterSecureStorage _secureStorage;
  final LocalAuthentication _localAuth;
  final SharedPreferences _prefs;

  // Clé pour stocker les credentials de façon sécurisée
  static const String _credentialsKey = 'auth_credentials';
  static const String _biometricEnabledKey = 'biometric_enabled';

  FirebaseAuthRepository({
    required firebase_auth.FirebaseAuth firebaseAuth,
    required GoogleSignIn googleSignIn,
    required FlutterSecureStorage secureStorage,
    required LocalAuthentication localAuth,
    required SharedPreferences prefs,
  })  : _firebaseAuth = firebaseAuth,
        _googleSignIn = googleSignIn,
        _secureStorage = secureStorage,
        _localAuth = localAuth,
        _prefs = prefs;

  @override
  Stream<domain.User?> get user {
    return _firebaseAuth.authStateChanges().map((firebase_auth.User? firebaseUser) {
      return firebaseUser == null
          ? null
          : UserModel.fromFirebaseUser(firebaseUser);
    });
  }

  @override
  Future<bool> isSignedIn() async {
    return _firebaseAuth.currentUser != null;
  }

  @override
  Future<Either<Failure, domain.User>> registerWithEmailAndPassword({
    required String email,
    required String password,
    String? displayName,
  }) async {
    try {
      final credential = await _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      if (credential.user == null) {
        return Left(const AuthFailure('Échec de la création du compte'));
      }

      // Mise à jour du nom d'affichage si fourni
      if (displayName != null && displayName.isNotEmpty) {
        await credential.user!.updateDisplayName(displayName);
        // Actualiser les données utilisateur
        await credential.user!.reload();
      }

      // Envoi d'email de vérification
      await credential.user!.sendEmailVerification();

      // Récupération de l'utilisateur actualisé
      final updatedUser = _firebaseAuth.currentUser;
      if (updatedUser == null) {
        return Left(const AuthFailure('Utilisateur non trouvé après mise à jour'));
      }

      // Conversion directe de l'utilisateur Firebase en UserModel
      final userModel = UserModel.fromFirebaseUser(updatedUser);
      return Right(userModel);
    } catch (e) {
      return Left(FirebaseErrorHandler.handleAuthException(e));
    }
  }

  @override
  Future<Either<Failure, domain.User>> signInWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    try {
      // Connexion avec email et mot de passe
      final credential = await _firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      if (credential.user == null) {
        return Left(const AuthFailure('Échec de la connexion'));
      }

      // Stocker les identifiants si l'utilisateur active la biométrie plus tard
      await _secureStorage.write(
        key: _credentialsKey,
        value: json.encode({
          "email": email,
          "password": password
        }),
      );

      // Conversion directe de l'utilisateur Firebase en UserModel
      final userModel = UserModel.fromFirebaseUser(credential.user!);
      return Right(userModel);
    } catch (e) {
      return Left(FirebaseErrorHandler.handleAuthException(e));
    }
  }

  @override
  Future<Either<Failure, domain.User>> signInWithGoogle() async {
    try {
      // Démarrer le flux de connexion Google
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        return Left(const AuthFailure('Connexion Google annulée'));
      }

      // Obtenir les détails d'authentification de la demande
      final googleAuth = await googleUser.authentication;

      // Créer un nouvel identifiant
      final credential = firebase_auth.GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Connexion à Firebase avec l'identifiant Google
      final userCredential = await _firebaseAuth.signInWithCredential(credential);

      if (userCredential.user == null) {
        return Left(const AuthFailure('Échec de la connexion avec Google'));
      }

      // Conversion directe en UserModel
      final userModel = UserModel.fromFirebaseUser(userCredential.user!);
      return Right(userModel);
    } catch (e) {
      return Left(FirebaseErrorHandler.handleAuthException(e));
    }
  }

  @override
  Future<Either<Failure, domain.User>> signInWithApple() async {
    try {
      // La mise en œuvre réelle nécessitera le package sign_in_with_apple
      // et une configuration spécifique pour iOS/macOS
      // Cette implémentation est simplifiée pour l'exemple

      // Création d'un provider pour Apple
      final appleProvider = firebase_auth.AppleAuthProvider();

      // Connexion avec popup ou redirection selon la plateforme
      final userCredential = await _firebaseAuth.signInWithProvider(appleProvider);

      if (userCredential.user == null) {
        return Left(const AuthFailure('Échec de la connexion avec Apple'));
      }

      // Conversion directe en UserModel
      final userModel = UserModel.fromFirebaseUser(userCredential.user!);
      return Right(userModel);
    } catch (e) {
      return Left(FirebaseErrorHandler.handleAuthException(e));
    }
  }

  @override
  Future<Either<Failure, void>> signOut() async {
    try {
      // Déconnexion de Google si connecté
      await _googleSignIn.signOut();

      // Déconnexion de Firebase
      await _firebaseAuth.signOut();

      return const Right(null);
    } catch (e) {
      return Left(FirebaseErrorHandler.handleAuthException(e));
    }
  }

  @override
  Future<Either<Failure, void>> sendPasswordResetEmail(String email) async {
    try {
      await _firebaseAuth.sendPasswordResetEmail(email: email);
      return const Right(null);
    } catch (e) {
      return Left(FirebaseErrorHandler.handleAuthException(e));
    }
  }

  @override
  Future<Either<Failure, void>> sendEmailVerification() async {
    try {
      final user = _firebaseAuth.currentUser;
      if (user == null) {
        return Left(const AuthFailure('Aucun utilisateur connecté'));
      }

      await user.sendEmailVerification();
      return const Right(null);
    } catch (e) {
      return Left(FirebaseErrorHandler.handleAuthException(e));
    }
  }

  @override
  Future<Either<Failure, domain.User>> updateUserProfile({
    String? displayName,
    String? photoUrl,
  }) async {
    try {
      final user = _firebaseAuth.currentUser;
      if (user == null) {
        return Left(const AuthFailure('Aucun utilisateur connecté'));
      }

      // Mettre à jour les informations du profil
      await user.updateDisplayName(displayName);
      await user.updatePhotoURL(photoUrl);

      // Recharger l'utilisateur pour obtenir les données mises à jour
      await user.reload();
      final updatedUser = _firebaseAuth.currentUser;

      if (updatedUser == null) {
        return Left(const AuthFailure('Utilisateur non trouvé après mise à jour'));
      }

      // Conversion directe en UserModel
      final userModel = UserModel.fromFirebaseUser(updatedUser);
      return Right(userModel);
    } catch (e) {
      return Left(FirebaseErrorHandler.handleAuthException(e));
    }
  }

  @override
  Future<Either<Failure, void>> deleteAccount() async {
    try {
      final user = _firebaseAuth.currentUser;
      if (user == null) {
        return Left(const AuthFailure('Aucun utilisateur connecté'));
      }

      await user.delete();
      return const Right(null);
    } catch (e) {
      return Left(FirebaseErrorHandler.handleAuthException(e));
    }
  }

  @override
  Future<bool> isBiometricAvailable() async {
    try {
      // Vérifier si le matériel prend en charge la biométrie
      final canCheckBiometrics = await _localAuth.canCheckBiometrics;
      final isDeviceSupported = await _localAuth.isDeviceSupported();

      return canCheckBiometrics && isDeviceSupported;
    } catch (e) {
      return false;
    }
  }

  @override
  Future<Either<Failure, bool>> enableBiometricAuth() async {
    try {
      // Vérifier si la biométrie est disponible
      final isBiometricSupported = await isBiometricAvailable();
      if (!isBiometricSupported) {
        return Left(const AuthFailure('La biométrie n\'est pas disponible sur cet appareil'));
      }

      // Vérifier si l'utilisateur est connecté
      final user = _firebaseAuth.currentUser;
      if (user == null) {
        return Left(const AuthFailure('Vous devez être connecté pour activer la biométrie'));
      }

      // Les identifiants devraient déjà être stockés lors de la connexion précédente
      final credentials = await _secureStorage.read(key: _credentialsKey);
      if (credentials == null || credentials.isEmpty) {
        return Left(const AuthFailure('Aucun identifiant trouvé pour configurer la biométrie'));
      }

      // Authentifier l'utilisateur avec la biométrie avant d'activer
      final bool authenticated = await _localAuth.authenticate(
        localizedReason: 'Veuillez vous authentifier pour activer la connexion biométrique',
      );

      if (!authenticated) {
        return Left(const AuthFailure('Authentification biométrique échouée'));
      }

      // Activer la biométrie dans les préférences
      await _prefs.setBool(_biometricEnabledKey, true);

      return const Right(true);
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, domain.User>> signInWithBiometric() async {
    try {
      // Vérifier si la biométrie est activée
      final biometricEnabled = _prefs.getBool(_biometricEnabledKey) ?? false;
      if (!biometricEnabled) {
        return Left(const AuthFailure('L\'authentification biométrique n\'est pas activée'));
      }

      // Authentifier l'utilisateur avec la biométrie
      final bool authenticated = await _localAuth.authenticate(
        localizedReason: 'Veuillez vous authentifier pour vous connecter',
      );

      if (!authenticated) {
        return Left(const AuthFailure('Authentification biométrique échouée'));
      }

      // Récupérer les identifiants stockés
      final credentials = await _secureStorage.read(key: _credentialsKey);
      if (credentials == null || credentials.isEmpty) {
        return Left(const AuthFailure('Aucun identifiant trouvé pour la connexion biométrique'));
      }

      try {
        // Convertir la chaîne JSON en Map
        final Map<String, dynamic> credentialsMap = json.decode(credentials);

        // Vérifier que les clés nécessaires existent
        if (!credentialsMap.containsKey('email') || !credentialsMap.containsKey('password')) {
          return Left(const AuthFailure('Format des identifiants stockés invalide'));
        }

        // Extraction des informations avec vérification de type
        final email = credentialsMap['email']?.toString() ?? '';
        final password = credentialsMap['password']?.toString() ?? '';

        if (email.isEmpty || password.isEmpty) {
          return Left(const AuthFailure('Identifiants stockés incomplets'));
        }

        // Se connecter avec les identifiants stockés
        final result = await signInWithEmailAndPassword(
          email: email,
          password: password,
        );

        return result;
      } catch (e) {
        return Left(UnknownFailure('Erreur lors du décodage des identifiants: ${e.toString()}'));
      }
    } catch (e) {
      return Left(UnknownFailure(e.toString()));
    }
  }
}