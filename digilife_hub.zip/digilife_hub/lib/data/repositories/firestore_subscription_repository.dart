// lib/data/repositories/firestore_subscription_repository.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dartz/dartz.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:digilife_hub/core/errors/failures.dart';
import 'package:digilife_hub/data/models/subscription_model.dart';
import 'package:digilife_hub/domain/entities/subscription.dart';
import 'package:digilife_hub/domain/entities/subscription_enums.dart';
import 'package:digilife_hub/domain/repositories/subscription_repository.dart';

class FirestoreSubscriptionRepository implements SubscriptionRepository {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  FirestoreSubscriptionRepository({
    required FirebaseFirestore firestore,
    required FirebaseAuth auth,
  })  : _firestore = firestore,
        _auth = auth;

  // Collection de référence pour les abonnements
  CollectionReference<Map<String, dynamic>> get _subscriptionsCollection {
    final userId = _auth.currentUser?.uid;
    if (userId == null) {
      throw Exception('Utilisateur non connecté');
    }
    return _firestore.collection('users').doc(userId).collection('subscriptions');
  }

  @override
  Future<Either<Failure, List<Subscription>>> getAllSubscriptions() async {
    try {
      final snapshot = await _subscriptionsCollection.get();

      final subscriptions = snapshot.docs
          .map((doc) => SubscriptionModel.fromJson({
        'id': doc.id,
        ...doc.data(),
      }))
          .toList();

      return Right(subscriptions);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, Subscription>> getSubscriptionById(String id) async {
    try {
      final doc = await _subscriptionsCollection.doc(id).get();

      if (!doc.exists) {
        return Left(ServerFailure('Abonnement non trouvé'));
      }

      final subscription = SubscriptionModel.fromJson({
        'id': doc.id,
        ...doc.data() ?? {},
      });

      return Right(subscription);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, Subscription>> addSubscription(Subscription subscription) async {
    try {
      final subscriptionModel = subscription is SubscriptionModel
          ? subscription
          : SubscriptionModel(
        id: subscription.id,
        name: subscription.name,
        amount: subscription.amount,
        periodicity: subscription.periodicity,
        nextPaymentDate: subscription.nextPaymentDate,
        category: subscription.category,
        description: subscription.description,
        logoUrl: subscription.logoUrl,
        status: subscription.status,
        startDate: subscription.startDate,
        hasReminder: subscription.hasReminder,
        reminderDays: subscription.reminderDays,
      );

      // Supprimer l'ID du modèle car Firestore le génère automatiquement
      final subscriptionData = subscriptionModel.toJson()..remove('id');

      final docRef = await _subscriptionsCollection.add(subscriptionData);

      // Récupérer l'abonnement créé avec le nouvel ID
      return getSubscriptionById(docRef.id);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, Subscription>> updateSubscription(Subscription subscription) async {
    try {
      final subscriptionModel = subscription is SubscriptionModel
          ? subscription
          : SubscriptionModel(
        id: subscription.id,
        name: subscription.name,
        amount: subscription.amount,
        periodicity: subscription.periodicity,
        nextPaymentDate: subscription.nextPaymentDate,
        category: subscription.category,
        description: subscription.description,
        logoUrl: subscription.logoUrl,
        status: subscription.status,
        startDate: subscription.startDate,
        hasReminder: subscription.hasReminder,
        reminderDays: subscription.reminderDays,
      );

      // Supprimer l'ID du modèle car il est déjà dans le chemin du document
      final subscriptionData = subscriptionModel.toJson()..remove('id');

      await _subscriptionsCollection.doc(subscription.id).update(subscriptionData);

      return Right(subscription);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, void>> deleteSubscription(String id) async {
    try {
      await _subscriptionsCollection.doc(id).delete();
      return const Right(null);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<Subscription>>> getSubscriptionsByCategory(SubscriptionCategory category) async {
    try {
      final snapshot = await _subscriptionsCollection
          .where('category', isEqualTo: category.toString().split('.').last)
          .get();

      final subscriptions = snapshot.docs
          .map((doc) => SubscriptionModel.fromJson({
        'id': doc.id,
        ...doc.data(),
      }))
          .toList();

      return Right(subscriptions);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<Subscription>>> getUpcomingSubscriptions(int days) async {
    try {
      final now = DateTime.now();
      final future = now.add(Duration(days: days));

      // Récupérer tous les abonnements puis filtrer côté client
      // car Firestore ne permet pas de faire des comparaisons complexes de dates
      final result = await getAllSubscriptions();

      return result.fold(
            (failure) => Left(failure),
            (subscriptions) {
          final upcomingSubscriptions = subscriptions
              .where((subscription) =>
          subscription.nextPaymentDate.isAfter(now) &&
              subscription.nextPaymentDate.isBefore(future))
              .toList();

          return Right(upcomingSubscriptions);
        },
      );
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<Subscription>>> searchSubscriptions(String query) async {
    try {
      // Firestore ne supporte pas les recherches textuelles complètes
      // Nous devons récupérer tous les abonnements et filtrer côté client
      final result = await getAllSubscriptions();

      return result.fold(
            (failure) => Left(failure),
            (subscriptions) {
          final lowercaseQuery = query.toLowerCase();
          final filteredSubscriptions = subscriptions
              .where((subscription) =>
          subscription.name.toLowerCase().contains(lowercaseQuery) ||
              (subscription.description?.toLowerCase().contains(lowercaseQuery) ?? false))
              .toList();

          return Right(filteredSubscriptions);
        },
      );
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, double>> calculateTotalMonthlyCost() async {
    final result = await getAllSubscriptions();

    return result.fold(
          (failure) => Left(failure),
          (subscriptions) {
        final totalCost = subscriptions.fold<double>(
          0,
              (sum, subscription) => sum + subscription.monthlyCost,
        );

        return Right(totalCost);
      },
    );
  }

  @override
  Future<Either<Failure, double>> calculateTotalAnnualCost() async {
    final result = await getAllSubscriptions();

    return result.fold(
          (failure) => Left(failure),
          (subscriptions) {
        final totalCost = subscriptions.fold<double>(
          0,
              (sum, subscription) => sum + subscription.annualCost,
        );

        return Right(totalCost);
      },
    );
  }

  @override
  Stream<List<Subscription>> subscriptionsStream() {
    try {
      return _subscriptionsCollection.snapshots().map(
            (snapshot) => snapshot.docs
            .map((doc) => SubscriptionModel.fromJson({
          'id': doc.id,
          ...doc.data(),
        }))
            .toList(),
      );
    } catch (e) {
      // En cas d'erreur, retourner un stream vide
      return Stream.value([]);
    }
  }
}